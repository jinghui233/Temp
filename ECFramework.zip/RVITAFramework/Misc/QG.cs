﻿using QuikGraph;
using QuikGraph.Algorithms.ConnectedComponents;
using System.Collections.Generic;
using System.Linq;

namespace RVITAFramework
{
    /// <summary>
    /// 用于帮助操作块集合分裂，合并，判断是否分裂等操作
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class QG<T>
    {
        UndirectedGraph<T, Edge<T>> graph = new UndirectedGraph<T, Edge<T>>();
        ConnectedComponentsAlgorithm<T, Edge<T>> algorithm;
        public IEnumerable<T> Vertices { get { return graph.Vertices; } }
        public QG()
        {
            algorithm = new ConnectedComponentsAlgorithm<T, Edge<T>>(graph);
        }
        public QG(UndirectedGraph<T, Edge<T>> graph)
        {
            this.graph = graph;
            algorithm = new ConnectedComponentsAlgorithm<T, Edge<T>>(graph);
        }
        public void AddVertex(T vertex)
        {
            graph.AddVertex(vertex);
        }
        public void AddVertexRange(IEnumerable<T> vertices)
        {
            graph.AddVertexRange(vertices);
        }
        public void AddEdge(T sorce, T target)
        {
            graph.AddEdge(new Edge<T>(sorce, target));
        }
        public void AddEdgeRange(IEnumerable<Edge<T>> edges)
        {
            graph.AddEdgeRange(edges);
        }
        public void ClearEdges()
        {
            IEnumerable<Edge<T>> edges = graph.Edges;
            foreach (Edge<T> edge in edges)
            {
                graph.RemoveEdge(edge);
            }
        }
        public IEnumerable<Edge<T>> AdjacentEdges(T vertex)
        {
            return graph.AdjacentEdges(vertex);
        }
        public void RemoveVertex(T vertex)
        {
            graph.RemoveVertex(vertex);
        }
        public List<T> ConnectedVertes(T vertex)//获取与之相连的节点
        {
            List<T> result = new List<T>();
            var edges = graph.AdjacentEdges(vertex);
            if (edges != null)
            {
                foreach (Edge<T> item in edges)
                {
                    if (ReferenceEquals(vertex, item.Source))
                    {
                        result.Add(item.Target);
                    }
                    else
                    {
                        result.Add(item.Source);
                    }
                }
            }
            return result;
        }
        public bool CheckRemoveSplit(T vertex)//检查移除某节点是否导致图分裂
        {
            IEnumerable<Edge<T>> edges = graph.AdjacentEdges(vertex);
            graph.RemoveVertex(vertex);
            algorithm.Compute();
            if (algorithm.ComponentCount > 1)
            {
                graph.AddVertex(vertex);
                graph.AddEdgeRange(edges);
                return true;
            }
            graph.AddVertex(vertex);
            graph.AddEdgeRange(edges);
            return false;
        }
        public List<QG<T>> SplitNew(T vertex)//分裂图，保留vertex所在连通分量，分裂出剩下的连通分量图
        {
            List<QG<T>> result = new List<QG<T>>();
            algorithm.Compute();
            IDictionary<T, int> components = algorithm.Components;//T,int=>顶点,连通分量编号
            IEnumerable<IGrouping<int, KeyValuePair<T, int>>> groups = components.GroupBy(x => x.Value);//int,T,int=>连通分量编号,顶点,连通分量编号
            foreach (IGrouping<int, KeyValuePair<T, int>> component in groups)
            {
                UndirectedGraph<T, Edge<T>> curGraph = new UndirectedGraph<T, Edge<T>>();
                curGraph.AddVertexRange(component.Select(x => x.Key));
                foreach (var edge in graph.Edges)
                {
                    if (curGraph.ContainsVertex(edge.Source) && curGraph.ContainsVertex(edge.Target))
                    {
                        curGraph.AddEdge(edge);
                    }
                }
                if (curGraph.Vertices.Contains(vertex))
                {
                    graph = curGraph;
                }
                else
                {
                    result.Add(new QG<T>(curGraph));
                }
            }
            return result;
        }
        public void BreakEdges(IEnumerable<T> vertices)//打破连接，打破vertices与其余部分的连接
        {
            ICollection<T> vertexSet = vertices.ToHashSet();
            foreach (var vertex in vertices)
            {
                foreach (var edge in graph.AdjacentEdges(vertex))
                {
                    if (!vertexSet.Contains(edge.Source) || !vertexSet.Contains(edge.Target))
                    {
                        graph.RemoveEdge(edge);
                    }
                }
            }
        }
    }
}
