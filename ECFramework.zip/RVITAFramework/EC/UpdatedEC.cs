﻿namespace RVITAFramework
{
    public interface IUpdated
    {
        bool PrepareDel { get; set; }
        bool DrawGizmos { get; set; }
        void Update();
        void OnDrawGizmos();
    }
    public class UpdatedEntity : Entity, IUpdated
    {
        public bool PrepareDel { get; set; }
        public override void OnSpawn()
        {
            base.OnSpawn();
            Updater.Add(this);
        }
        public override void OnUnSpawn()
        {
            base.OnUnSpawn();
            PrepareDel = true;
        }
        public bool DrawGizmos { get; set; }
        public virtual void OnDrawGizmos()
        {
            foreach (var item in Comps)
            {
                if (item is UpdatedComp)
                {
                    (item as UpdatedComp).OnDrawGizmos();
                }
            }
        }
        public virtual void Update()
        {
            foreach (var item in Comps)
            {
                if (item is UpdatedComp)
                {
                    (item as UpdatedComp).Update();
                }
            }
        }
    }
    public class UpdatedComp : Comp, IUpdated
    {
        public bool PrepareDel { get; set; }
        public bool DrawGizmos { get; set; }
        public virtual void OnDrawGizmos()
        {

        }
        public virtual void Update()
        {
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            if (Parent is not UpdatedEntity)
            {
                Updater.Add(this);
            }
        }
        public override void OnUnSpawn()
        {
            base.OnUnSpawn();
            if (Parent is not UpdatedEntity)
            {
                Updater.Remove(this);
            }
        }
    }
}
