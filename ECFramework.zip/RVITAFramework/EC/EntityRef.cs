﻿using UnityEngine;

namespace RVITAFramework
{
    public class EntityRef
    {
        public string DefName { get; set; }
        public Vector3 Offset { get; set; }
        public Entity Entity { get; set; }
    }
}
