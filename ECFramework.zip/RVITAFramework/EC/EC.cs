﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace RVITAFramework
{
    public class EC
    {
        [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true, Inherited = true)]
        public class MenuAssignAttribute : Attribute { }
        public bool Enable { get; set; }
        public int ID { get; set; }
        public string ClassName { get; set; }
        public string DefName { get; set; }
        public void OnDeserialize<T>(T t) where T : EC
        {
            Type type = GetType();
            foreach (PropertyInfo item in type.GetProperties())
            {
                if (item.SetMethod != null)
                    if (item.GetCustomAttribute<MenuAssignAttribute>() == null)
                        item.SetValue(this, item.GetValue(t));
            }
        }
        public virtual T SplitNew<T>() where T : EC
        {
            Type type = GetType();
            object newObj = Activator.CreateInstance(type);
            foreach (PropertyInfo item in type.GetProperties())
            {
                if (item.SetMethod != null)
                    if (item.GetCustomAttribute<MenuAssignAttribute>() == null)
                        item.SetValue(newObj, item.GetValue(this));
            }
            return newObj as T;
        }
        public virtual void Create()
        {
        }
        public virtual void OnSplitNew()
        {
        }
        public virtual void OnSpawn()
        {
        }
        public virtual void OnUnSpawn()
        {
        }
    }
}
