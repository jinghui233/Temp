﻿using System.Collections.Generic;
using UnityEngine;

namespace RVITAFramework
{
    public class Entity : EC
    {
        public string PrefebPath { get; set; }
        private GameObject gameObject;
        [MenuAssign]
        public GameObject GameObject { get { return gameObject; } set { gameObject = value; GameObjectToEC.Add(this); } }
        [MenuAssign]
        public Transform Transform { get { return gameObject == null ? null : gameObject.transform; } }
        [MenuAssign]
        public List<Comp> Comps { get; set; }
        [MenuAssign]
        public List<EntityRef> SubEntities { get; set; }
        public GameObject GetOrCreateGameObject()
        {
            if (GameObject == null)
            {
                GameObject = new GameObject();
                GameObject.SetActive(false);
            }
            return GameObject;
        }
        public void AddComp(Comp comp)
        {
            Comps ??= new List<Comp>();
            Comps.Add(comp);
            comp.Parent = this;
        }
        public void AddSubEntity(EntityRef entity)
        {
            SubEntities ??= new List<EntityRef>();
            SubEntities.Add(entity);
        }
        public override T SplitNew<T>()
        {
            Entity entity = base.SplitNew<Entity>();
            if (Comps != null)
            {
                foreach (var item in Comps)
                {
                    entity.AddComp(item.SplitNew<Comp>());
                }
            }
            if (SubEntities != null)
            {
                foreach (var item in SubEntities)
                {
                    entity.AddSubEntity(new EntityRef() { DefName = item.DefName, Offset = item.Offset });
                }
            }
            if (GameObject != null)
            {
                entity.GameObject = Object.Instantiate(GameObject);
            }
            return entity as T;
        }
        public override void Create()
        {
            base.Create();
            if (Comps != null)
            {
                foreach (var item in Comps)
                {
                    item.Create();
                }
            }
        }
        public override void OnSplitNew()
        {
            base.OnSplitNew();
            if (Comps != null)
            {
                foreach (var item in Comps)
                {
                    item.OnSplitNew();
                }
            }
            if (GameObject != null)
            {
                GameObject.name = DefName;
            }
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            if (Comps != null)
            {
                foreach (var item in Comps)
                {
                    item.OnSpawn();
                }
            }
            if (SubEntities != null)
            {
                foreach (var item in SubEntities)
                {
                    item.Entity.OnSpawn();
                }
            }
            if (GameObject != null)
            {
                GameObject.SetActive(true);
            }
        }
        public override void OnUnSpawn()
        {
            base.OnUnSpawn();
            if (Comps != null)
            {
                foreach (var item in Comps)
                {
                    item.OnUnSpawn();
                }
            }
            if (GameObject != null)
            {
                GameObject.SetActive(false);
            }
        }
        public T GetSubEntity<T>() where T : Entity
        {
            if (!TryGetSubEntity(out T t))
                Debug.LogError($"在{DefName}数据类中未找到类型{typeof(T).Name}的子实体");
            return t;
        }
        public bool TryGetSubEntity<T>(out T t) where T : Entity
        {
            t = null;
            foreach (var item in SubEntities)
            {
                t = item.Entity as T;
                if (t != null)
                    return true;
            }
            return false;
        }
        public T GetComp<T>() where T : Comp
        {
            if (!TryGetComp(out T t))
                Debug.LogError($"在{DefName}数据类中未找到类型{typeof(T).Name}的子控件");
            return t;
        }
        public bool TryGetComp<T>(out T t) where T : Comp
        {
            t = null;
            if (Comps != null)
            {
                foreach (var item in Comps)
                {
                    t = item as T;
                    if (t != null) return true;
                }
            }
            return false;
        }
    }
}
