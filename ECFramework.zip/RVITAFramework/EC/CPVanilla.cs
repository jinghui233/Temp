﻿using UnityEngine;

namespace RVITAFramework
{
    public class CPVanilla<T> : Comp where T : Component
    {
        [MenuAssign]
        public T UnityComp { get; set; }
        public override void OnSplitNew()
        {
            base.OnSplitNew();
            UnityComp = Parent.GetOrCreateGameObject().GetOrCreate<T>();
        }
        public override void Create()
        {
            base.Create();
            UnityComp = Parent.GetOrCreateGameObject().GetOrCreate<T>();
        }
    }
}
