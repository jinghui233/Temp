﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace RVITAFramework
{
    public class ECJsonHelper
    {
        #region
        public static int IDIndex = 1000;
        public static Dictionary<string, Type> ECdic;
        public static void InitDict(Type[] types = null)
        {
            if (types == null || types.Length == 0)
                types = Assembly.GetExecutingAssembly().GetTypes();
            if (ECdic == null)
                ECdic = new Dictionary<string, Type>();
            Type ECType = typeof(EC);
            foreach (Type item in types)
            {
                if (!item.IsClass) continue;
                if (ECType.IsAssignableFrom(item))
                {
                    if (item.Name.StartsWith("ET") || item.Name.StartsWith("CP"))
                    {
                        ECdic.Add(item.Name[2..], item);
                    }
                }
            }
        }
        #endregion
        public static List<Entity> Load(string jsonData)
        {
            JArray jArray = JArray.Parse(jsonData);
            List<Entity> jsonDatas = new();
            foreach (var item in jArray)
            {
                jsonDatas.Add(Deserialize(item));
            }
            return jsonDatas;
        }
        public static Entity Deserialize(JToken jToken)
        {
            string dataName = jToken.Value<string>("ClassName");//类型名
            Type type = ECdic.ContainsKey(dataName) ? ECdic[dataName] : typeof(Entity);//类名对应的类型
            JArray compsJArray = jToken.Value<JArray>("Comps");//临时保存子组件Json数据
            JArray SubEntitiesJArray = jToken.Value<JArray>(" SubEntities");//临时保存子实体Json数据
            if (compsJArray != null) jToken["Comps"].Parent.Remove();//删除子组件Json数据
            if (SubEntitiesJArray != null) jToken["SubEntities"].Parent.Remove();//删除子组件Json数据
            Entity entity = JsonConvert.DeserializeObject(jToken.ToString(), type) as Entity;//创建数据类对象
            entity.ID = IDIndex++;//实体对象ID赋值
            if (!string.IsNullOrEmpty(entity.PrefebPath))
            {
                entity.GameObject = ResorceHelper.LoadResorce<GameObject>(entity.PrefebPath);
            }
            if (compsJArray != null && compsJArray.Count > 0)
            {
                foreach (var compJToken in compsJArray)
                {
                    dataName = compJToken.Value<string>("ClassName");//类型名
                    type = ECdic.ContainsKey(dataName) ? ECdic[dataName] : typeof(Comp);//类名对应的类型
                    Comp comp = JsonConvert.DeserializeObject(compJToken.ToString(), type) as Comp;
                    entity.AddComp(comp);//创建数据类对象
                }
            }
            return entity;
        }
        public static JToken Serialize(Entity entity)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings();

            settings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            JToken jToken = JsonConvert.SerializeObject(entity, settings);
            return jToken;
        }
    }
}
