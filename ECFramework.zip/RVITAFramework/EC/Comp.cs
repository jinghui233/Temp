﻿using UnityEngine;

namespace RVITAFramework
{
    public class Comp : EC
    {
        public Entity Parent { get; set; }
        [MenuAssign]
        public GameObject GameObject { get { return Parent.GameObject; } }
        [MenuAssign]
        public Transform Transform { get { return Parent.GameObject == null ? null : Parent.GameObject.transform; } }
    }

}
