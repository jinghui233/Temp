﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace RVITAFramework
{
    public static class GameObjectToEC
    {
        private static readonly Dictionary<int, Entity> entities = new();
        public static void Add(Entity entity)
        {
            if (entity.GameObject != null)
            {
                if (!entities.ContainsKey(entity.GameObject.GetInstanceID()))
                {
                    entities[entity.GameObject.GetInstanceID()] = entity;
                    return;
                }
                entities.Add(entity.GameObject.GetHashCode(), entity);
            }
        }
        public static Entity Get(GameObject gameObject)
        {
            if (entities.ContainsKey(gameObject.GetInstanceID()))
            {
                return entities[gameObject.GetHashCode()];
            }
            return null;
        }
        public static void Remove(Entity entity)
        {
            entities.Remove(entity.GameObject.GetHashCode());
        }
    }
    public static class GameObjectToECExtension
    {
        public static bool TryGetEntity(this GameObject gameObject, out Entity entity)
        {
            entity = GameObjectToEC.Get(gameObject);
            return entity != null;
        }
        public static bool TryGetEntity<T>(this GameObject gameObject, out T entity) where T : Entity
        {
            entity = GameObjectToEC.Get(gameObject) as T;
            return entity != null;
        }
        public static bool TryGetEntity(this Transform transform, out Entity entity)
        {
            entity = GameObjectToEC.Get(transform.gameObject);
            return entity != null;
        }
        public static bool TryGetEntity<T>(this Transform transform, out T entity) where T : Entity
        {
            entity = GameObjectToEC.Get(transform.gameObject) as T;
            return entity != null;
        }
    }
}
