﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;

namespace RVITAFramework
{
    //public class ECSerializer : JsonConverter
    //{
    //    public override bool CanConvert(Type objectType)
    //    {
    //        return objectType == typeof(EC);
    //    }

    //    public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
    //    {
    //        EC ec = (EC)value;
    //        JObject obj = new JObject();
    //        //obj.Add("name", person.Name);
    //        //obj.Add("age", person.Age);
    //        writer.WriteValue(obj.ToString());
    //    }
    //    public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
    //    {
    //        JObject obj = JObject.Load(reader);
    //        //Person person = new Person();
    //        //person.Name = (string)obj["name"];
    //        //person.Age = (int)obj["age"];
    //        return person;
    //    }
    //}
}
