﻿using UnityEditor;

namespace RVITAFramework
{
    public class ResorceHelper
    {
        public static T LoadResorce<T>(string path) where T : UnityEngine.Object
        {
            return AssetDatabase.LoadAssetAtPath<T>(path);
        }
    }
}
