﻿using UnityEngine;

namespace RVITAFramework
{
    public class FrameUtils
    {
    }
}
