﻿using UnityEngine;
using UnityUtils;

namespace RVITAFramework
{
    public class PoolCmpt : MonoSingleton<PoolCmpt>
    {
        private Pool pool;
        private static Pool Pool { get { return Instance.pool; } }
        protected override void Awake()
        {
            base.Awake();
            pool = new Pool(transform);
            Application.runInBackground = true;
        }
        public static void Create(Entity entity)
        {
            Pool.Create(entity);
        }
        public static void UnSpawn(Entity entity)
        {
            if (entity.SubEntities != null)
            {
                foreach (EntityRef subEntity in entity.SubEntities)
                {
                    UnSpawn(subEntity.Entity);
                }
            } 
            Pool.UnSpawn(entity);
        }
        public static T Spawn<T>(string name) where T : Entity
        {
            return Spawn(name) as T;
        }
        public static Entity Spawn(string name)
        {
            Entity entity = Pool.Spawn(name);
            if (entity.SubEntities != null)
            {
                foreach (var item in entity.SubEntities)
                {
                    item.Entity = Pool.Spawn(item.DefName);
                    if (item.Entity.GameObject != null && entity.GameObject != null)
                    {
                        item.Entity.GameObject.transform.SetParent(entity.GameObject.transform);
                        item.Entity.GameObject.transform.localPosition = item.Offset;
                    }
                }
            }
            entity.OnSpawn();
            return entity;
        }
        public static Entity Spawn(int id)
        {
            Entity entity = Pool.Spawn(id);
            if (entity.SubEntities != null)
            {
                foreach (var item in entity.SubEntities)
                {
                    item.Entity = Pool.Spawn(item.DefName);
                    if (item.Entity.GameObject != null && entity.GameObject != null)
                    {
                        item.Entity.GameObject.transform.SetParent(entity.GameObject.transform);
                    }
                }
            }
            entity.OnSpawn();
            return entity;
        }
    }
}
