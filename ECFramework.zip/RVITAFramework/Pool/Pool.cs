﻿using System.Collections.Generic;
using UnityEngine;

namespace RVITAFramework
{
    public class Pool
    {
        public Dictionary<int, EntityPool> IDPool = new();
        public Dictionary<string, EntityPool> NamePool = new();
        public Transform transform;
        public Pool(Transform transform)
        {
            this.transform = transform;
        }
        public void Create(Entity entity)
        {
            EntityPool entityPool = new(transform, entity);
            IDPool.Add(entity.ID, entityPool);
            NamePool.Add(entity.DefName, entityPool);
        }
        public Entity Spawn(int id)
        {
            return IDPool[id].GetInstance();
        }
        public Entity Spawn(string name)
        {
            return NamePool[name].GetInstance();
        }
        public T Spawn<T>(int id) where T : Entity
        {
            return IDPool[id].GetInstance() as T;
        }
        public T Spawn<T>(string name) where T : Entity
        {
            return NamePool[name].GetInstance() as T;
        }
        public void UnSpawn(Entity entity)
        {
            IDPool[entity.ID].ReturnInstance(entity);
        }
    }
}
