﻿using System.Collections.Generic;
using UnityEngine;

namespace RVITAFramework
{
    public class EntityPool
    {
        private readonly Queue<Entity> instanceQueue = new();
        public Transform transform;
        private readonly Entity originInstance;
        public EntityPool(Transform transform, Entity originInstance)
        {
            originInstance.Create();
            originInstance.OnSplitNew();
            this.originInstance = originInstance;
            this.transform = transform;
            if (originInstance.GameObject != null && string.IsNullOrWhiteSpace(originInstance.PrefebPath))
            {
                originInstance.GameObject.transform.SetParent(transform);
            }
        }
        public Entity GetInstance()
        {
            Entity instance;
            if (instanceQueue.Count > 0)
            {
                instance = instanceQueue.Dequeue();
            }
            else
            {
                instance = originInstance.SplitNew<Entity>();//复制数据
                instance.OnSplitNew();
            }
            return instance;
        }
        public void ReturnInstance(Entity instance)
        {
            instanceQueue.Enqueue(instance);
            if (instance.GameObject != null)
            {
                instance.GameObject.transform.SetParent(transform);
            }
            instance.OnUnSpawn();
        }
    }
}
