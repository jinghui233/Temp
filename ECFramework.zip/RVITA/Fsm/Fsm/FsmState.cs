﻿namespace RVITA
{
    public class FsmState<T>
    {
        Fsm<T> fsm;
        protected internal virtual void OnCreate(Fsm<T> fsm)
        {
            this.fsm = fsm;
        }
        protected internal virtual void OnEnter()
        {

        }
        protected internal virtual void OnUpdate()
        {

        }
        protected internal virtual void OnLeave()
        {

        }
    }
}
