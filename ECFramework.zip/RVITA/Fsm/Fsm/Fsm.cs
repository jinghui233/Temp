﻿using System;
using System.Collections.Generic;

namespace RVITA
{
    public class Fsm<T>
    {
        FsmState<T> curState;
        Dictionary<Type, FsmState<T>> states = new Dictionary<Type, FsmState<T>>();
        public void ChangeState<TState>() where TState : FsmState<T>, new()
        {
            curState.OnLeave();
            if (states.TryGetValue(typeof(TState), out curState))
            {
                curState = new TState();
                states[typeof(TState)] = curState;
                curState.OnCreate(this);
            }
            curState.OnEnter();
        }
        public void Update()
        {
            curState.OnUpdate();
        }
    }
}
