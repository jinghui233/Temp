﻿using RVITAFramework;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class ECJsonTest : MonoBehaviour
    {
        void Load()
        {
            ECJsonHelper.InitDict(Assembly.GetExecutingAssembly().GetTypes());
        }
        void TestProcess()
        {
            List<Entity> entities = ECJsonHelper.Load(File.ReadAllText("Assets/Data/Entities/ElecGtr.json"));
            ECJsonHelper.Serialize(entities[0]);
        }
        private void Start()
        {
            Load();
            TestProcess();
        }
    }
}
