﻿using RVITAFramework;
using System.Reflection;
using UnityEngine.UI;
using UnityUtils;

namespace RVITA
{
    public class DeviceBuildTest : MonoSingleton<DeviceSysTest>
    {
        public GridItems gridItems;
        public Text text;
        public InputCtrl inputCtrl;
        void Load()
        {
            ECJsonHelper.InitDict(Assembly.GetExecutingAssembly().GetTypes());
            EntityManager.Instance.Load("Assets/Data/Entities/ElecGtr.json");
            EntityManager.Instance.Load("Assets/Data/entities-parts.json");
            EntityManager.Instance.Load("Assets/Data/wheels.json");
            EntityManager.Instance.Load("Assets/Data/Core.json");
        }
        void TestProcess()
        {
            foreach (var item in EntityManager.Instance.AllOrigEntities)
            {
                PoolCmpt.Create(item);
            }
        }
        private void Start()
        {
            Load();
            TestProcess();
            foreach (var item in EntityManager.Instance.AllOrigEntities)
            {
                if (item is ETPart)
                {
                    gridItems.AddItem(item.DefName);
                }
            }
            rV = PoolCmpt.Spawn<ETRV>("RV");
            ETPart eTBuildable = PoolCmpt.Spawn<ETPart>("SimplePart2");
            eTBuildable.Transform.position = rV.Transform.position;
            rV.AddBuildable(eTBuildable, null);
            inputCtrl.rv = rV;
            rV.ProdSys.StoreIn("wood", 10000);
            rV.ProdSys.StoreIn("fuel", 40000);
        }
        ETRV rV;
        private void Update()
        {
            text.text = $"{rV.cPElecSys.info}\n{rV.ProdSys.info}";
        }
    }
}
