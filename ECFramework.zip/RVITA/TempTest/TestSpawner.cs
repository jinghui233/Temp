using RVITA;
using UnityEngine;
using ECFramework;
public class TestSpawner : MonoBehaviour
{
    public Camp Camp;
    public string defName;
    void Start()
    {
        timeRemaining = 1;
    }
    float timeRemaining;
    public int mouseKey;
    void Update()
    {
        return;
        if (Input.GetMouseButtonDown(mouseKey))
        {
            timeRemaining = 0;
        }
        timeRemaining -= Time.deltaTime;
        if (timeRemaining <= 0)
        {
            ETCharacter character = EntityAssembler.Spawn<ETCharacter>(defName);
            character.GameObject.transform.position = transform.position;
            character.SetCamp(Camp);
            character.GetComp<CPMove>().MoveTo(new Vector3(0, 0, 0));
            timeRemaining = Random.Range(0.5f, 1.5f);
        }
    }
}
