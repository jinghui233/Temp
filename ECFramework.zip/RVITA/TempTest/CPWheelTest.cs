﻿using RVITAFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class CPWheelTest : MonoSingleton<CPWheelTest>
    {
        void Load()
        {
            ECJsonHelper.InitDict(Assembly.GetExecutingAssembly().GetTypes());
            EntityManager.Instance.Load("Assets/Data/wheels.json");
        }
        void TestProcess()
        {
            foreach (var item in EntityManager.Instance.AllOrigEntities)
            {
                PoolCmpt.Create(item);
            }
        }
        private void Start()
        {
            Load();
            TestProcess();
            ETPart body = PoolCmpt.Spawn<ETPart>("TestBody");
            body.GameObject.transform.position = new Vector3(0, 0, 0);

            //ETBuildable eTBuildable = PoolCmpt.Spawn<ETBuildable>("SimpleWheel");
            //eTBuildable.GameObject.transform.position = new Vector3(0, 2, 0);
            //eTBuildable.GameObject.GetComponent<FixedJoint2D>().connectedBody = body.GameObject.GetComponent<Rigidbody2D>();

            //eTBuildable = PoolCmpt.Spawn<ETBuildable>("SimpleWheel");
            //eTBuildable.GameObject.transform.position = new Vector3(2, 2, 0);
            //eTBuildable.GameObject.GetComponent<FixedJoint2D>().connectedBody = body.GameObject.GetComponent<Rigidbody2D>();

        }
    }
}
