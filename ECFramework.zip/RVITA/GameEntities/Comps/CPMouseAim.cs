﻿using RVITAFramework;
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class CPMouseAim : UpdatedComp
    {
        ETTurret turret;
        ETMeleeWeapon weapon;
        public bool Disable { get; set; }
        public override void OnSplitNew()
        {
            base.OnSplitNew();
            turret = Parent as ETTurret;
            weapon = Parent as ETMeleeWeapon;
        }
        public override void Update()
        {
            if (Disable) return;
            Vector3 vector3 = CoordAndScreen.MousePosition();
            vector3.z = GameObject.transform.position.z;
            if (weapon != null)
            {
                weapon.TakeAim(vector3);
                if (Input.GetAxis("Fire1") == 1)
                {
                    weapon.Attack();
                }
            }
            if (turret != null)
            {
                turret.TakeAim(vector3);
                if (Input.GetAxis("Fire1") == 1)
                {
                    turret.Attack();
                }
            }
        }
    }
}
