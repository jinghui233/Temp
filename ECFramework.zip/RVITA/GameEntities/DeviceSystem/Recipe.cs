﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RVITA
{
    public class Recipe
    {
        public Product[] ProdIn;
        public Product[] Prodout;
        public float TimeUse { get; set; }
    }
}
