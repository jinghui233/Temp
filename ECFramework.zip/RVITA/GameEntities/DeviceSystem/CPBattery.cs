﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace RVITA
{
    public class CPBattery : CPDevice
    {
        public float ElecStorage { get; set; }
        public float CurElecStorage { get; set; }
        public override void Update()
        {
            if (Closed) return;
            base.Update();
            float Power = 0;
            if (CurElecStorage < ElecStorage)
            {
                Power += ElecSys.PoolUseElec(ElecUse);
            }
            if (CurElecStorage > 0)
            {
                Power -= ElecSys.PoolGenElec(ElecGen);
            }
            CurElecStorage += Power * Time.deltaTime;
            CurElecStorage = Mathf.Clamp(CurElecStorage, 0, ElecStorage);
        }
    }
}
