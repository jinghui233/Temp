﻿using RVITAFramework;
using UnityEngine;

namespace RVITA
{
    public enum DeviceState
    {
        Idle,
        Running,
        Close,
    }
    public class CPDevice : UpdatedComp
    {
        public ProdSys prodSys;
        public CPElecSys ElecSys { get; set; }
        public float ElecUse { get; set; }
        public float ElecGen { get; set; }
        public DeviceState State { get; private set; }
        private DeviceState BeforeClosing;
        public void ChangeState(DeviceState state)
        {
            if (state == DeviceState.Close)
            {
                BeforeClosing = State;
            }
            if (State == DeviceState.Close)
            {
                state = BeforeClosing;
            }
            State = state;
        }
        public bool Closed { get => State == DeviceState.Close; set { if (value) ChangeState(DeviceState.Close); else ChangeState(DeviceState.Idle); } }
        public override void Create()
        {
            base.Create();
            GameObject.AddComponent<MonoDevice>();
        }
        public override void OnSplitNew()
        {
            base.OnSplitNew();
            MonoDevice monoDevice = GameObject.GetComponent<MonoDevice>();
            monoDevice.MouseEnter += OnMouseEnter;
            monoDevice.MouseExit += OnMouseExit;
        }
        public virtual void OnMouseEnter()
        {
            Debug.Log("OnMouseEnter");
        }
        public virtual void OnMouseExit()
        {
            Debug.Log("OnMouseExit");
        }
    }
}
