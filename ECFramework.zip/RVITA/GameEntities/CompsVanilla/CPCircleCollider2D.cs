﻿using RVITAFramework;
using UnityEngine;

namespace RVITA
{
    public class CPCircleCollider2D : CPVanilla<CircleCollider2D>
    {
        public override void Create()
        {
            base.Create();
        }
    }
}
