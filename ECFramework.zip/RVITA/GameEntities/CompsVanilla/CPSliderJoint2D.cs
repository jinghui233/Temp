﻿using RVITAFramework;
using UnityEngine;

namespace RVITA
{
    public class CPSliderJoint2D : CPVanilla<SliderJoint2D>
    {
        public float Angle { get; set; }
        public override void Create()
        {
            base.Create();
        }
    }
}
