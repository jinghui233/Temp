﻿using RVITAFramework;
using UnityEngine;

namespace RVITA
{
    public class CPRigidbody2D : CPVanilla<Rigidbody2D>
    {
        public override void Create()
        {
            base.Create();
        }
    }
}
