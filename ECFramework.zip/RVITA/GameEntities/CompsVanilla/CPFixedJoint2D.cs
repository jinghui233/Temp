﻿using RVITAFramework;
using UnityEngine;

namespace RVITA
{
    public class CPFixedJoint2D : CPVanilla<FixedJoint2D>
    {
        public override void Create()
        {
            base.Create();
        }
    }
}
