﻿using RVITAFramework;
using UnityEngine;
using UnityEngine.UI;
using UnityUtils;

namespace RVITA
{
    public class ETHPBar : UpdatedEntity
    {
        public Transform AttachedTransform;
        Slider Slider;
        public override void OnSplitNew()
        {
            base.OnSplitNew();
            Slider = GameObject.GetComponent<Slider>();
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            GameObject.transform.SetParent(UIGaming.Instance.canvas.transform);
        }
        public void SetVal(float val)
        {
            Slider.value = val;
        }
        public override void Update()
        {
            base.Update();
            GameObject.transform.position = CoordAndScreen.ScreenPosition(AttachedTransform.position);
        }
    }
}
