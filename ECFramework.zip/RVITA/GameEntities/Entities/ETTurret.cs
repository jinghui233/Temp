﻿using RVITA;
using RVITAFramework;
using UnityEngine;

namespace RVITA
{
    public class ETTurret : UpdatedEntity
    {
        public float AttackRange { get; set; }
        public float Cooldown { get; set; }
        public string ProjectileName { get; set; }
        float timeRaming;
        public bool Aimed;
        public float rotaSpeed = 10;
        Camp camp;
        public void SetCamp(Camp camp)
        {
            this.camp = camp;
            Layerer.SetLayer(GameObject, Layerer.GetLayer(camp));
            bulletLayer = Layerer.GetProjectileLayer(Layerer.GetLayer(camp));
        }
        LayerEnum bulletLayer;
        public void TakeAim(Vector3 target)
        {
            Vector2 direction = target - GameObject.transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            float angle2 = Vector2.Angle(target - GameObject.transform.rotation.eulerAngles, GameObject.transform.right);
            Aimed = Mathf.Abs(angle2) < 3;
            Quaternion q = Quaternion.AngleAxis(angle, Vector3.forward);
            GameObject.transform.rotation = Quaternion.Slerp(GameObject.transform.rotation, q, rotaSpeed * Time.deltaTime);
        }
        public void Attack()
        {
            if (timeRaming <= 0)
            {
                timeRaming = Cooldown;
                ETBullet bullet = PoolCmpt.Spawn<ETBullet>(ProjectileName);
                Layerer.SetLayer(bullet.GameObject, bulletLayer);
                bullet.Lanch(GameObject.transform, camp);
            }
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            timeRaming = Cooldown;
        }
        public override void Update()
        {
            timeRaming -= Time.deltaTime;
        }
    }
}
