﻿using RVITAFramework;

namespace RVITA
{
    public class ETNormal : UpdatedEntity
    {
    }
}
