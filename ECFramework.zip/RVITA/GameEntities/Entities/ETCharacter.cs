﻿using RVITAFramework;
using System.Collections;
using UnityEngine;

namespace RVITA
{
    public class ETCharacter : Entity
    {
        public ETTurret turret;
        public ETMeleeWeapon weapon;
        public ETHPBar hpBar;
        public CPHealth health;
        public CPAgent agent;
        public bool alive;
        SpriteRenderer spriteRenderer;
        public Camp Camp { get; set; }
        public override void OnSplitNew()
        {
            base.OnSplitNew();
            health = GetComp<CPHealth>();
            health.HealthCleared += OnHealthCleared;
            health.Hitting += OnHitting;
            spriteRenderer = GameObject.GetComponent<SpriteRenderer>();
            GameObject.GetComponent<Rigidbody2D>().freezeRotation = true;
        }
        public void SetCamp(Camp camp)
        {
            Camper.SetCamp(this, camp);
        }
        private void OnHitting(CPHealth health)
        {
            hpBar.SetVal(health.GetHPBarVal());
            Updater.Instance.StartCoroutine(Flash());
        }
        public IEnumerator Flash()
        {
            spriteRenderer.material.SetFloat("_FlashAmount", 0.5f);
            yield return new WaitForSeconds(0.1f);
            spriteRenderer.material.SetFloat("_FlashAmount", 0);
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            TryGetSubEntity(out turret);
            TryGetSubEntity(out weapon);
            TryGetComp(out agent);
            hpBar = GetSubEntity<ETHPBar>();
            hpBar.AttachedTransform = GameObject.transform;
            alive = true;
        }
        private void OnHealthCleared(CPHealth health)
        {
            alive = false;
            PoolCmpt.UnSpawn(this);
            //Debug.Log($"HealthCleared!");
        }
    }
}
