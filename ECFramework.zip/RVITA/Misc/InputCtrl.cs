﻿using RVITAFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class InputCtrl : MonoBehaviour
    {
        public GridItems gridItems;
        public MouseBuilder mouseBuilder;
        public ETRV rv;
        private void Start()
        {
            gridItems.Clicked += OnGridItemClicked;
        }
        private void Update()
        {
            if (Input.GetMouseButtonDown(0))
            {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit2D[] hits = Physics2D.RaycastAll(ray.origin, ray.direction);
                foreach (RaycastHit2D hit in hits)
                {
                    if (hit.collider != null)
                    {
                        GameObject selectedObject = hit.collider.gameObject;
                        Entity entity = GameObjectToEC.Get(selectedObject);
                        if (entity != null)
                        {
                            if (entity.TryGetComp(out CPElecGtr cPElecGtr))
                            {
                                UIElecGtr uIDevice = UIManager.GetUI<UIElecGtr>();
                                uIDevice.CPElecGtr = cPElecGtr;
                                uIDevice.Open();
                            }
                            else if (entity.TryGetComp(out CPProducter cPProducter))
                            {
                                UIProducter uIProducter = UIManager.GetUI<UIProducter>();
                                uIProducter.CPProducter = cPProducter;
                                //uIProducter.Open();
                            }
                        }
                    }
                }
            }
        }
        private void OnGridItemClicked(string entityName)
        {
            mouseBuilder.rV = rv;
            mouseBuilder.SetInBuilding(PoolCmpt.Spawn<ETPart>(entityName));
        }
    }
}
