﻿using ECFramework;
using UnityEngine;

namespace RVITA
{
    public class InputCtrl : MonoBehaviour
    {
        public GridItems gridItems;
        public MouseBuilder mouseBuilder;
        public Entity SelectedEntity;
        private void Start()
        {
            gridItems.Clicked += OnGridItemClicked;
        }
        private void DetectEntity()
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit2D[] hits = Physics2D.RaycastAll(ray.origin, ray.direction);
            SelectedEntity = null;
            foreach (RaycastHit2D hit in hits)
            {
                if (hit.collider != null)
                {
                    GameObject selectedObject = hit.collider.gameObject;
                    SelectedEntity = GameObjectToEC.Get(selectedObject);
                    break;
                }
            }
        }
        private void Update()
        {
            DetectEntity();
            if (Input.GetMouseButtonDown(0) && SelectedEntity != null)
            {
                if (SelectedEntity is ETPart && !(SelectedEntity as ETPart).BlueprintMod)
                {
                    if (SelectedEntity.TryGetComp(out CPElecGtr elecGtr))
                    {
                        UIManager.Instance.UIElecGtr.SetElecGtr(elecGtr);
                        UIManager.Instance.UIElecGtr.Open();
                    }
                    else if (SelectedEntity.TryGetComp(out CPProducter producter))
                    {
                        UIManager.Instance.UIProducter.SetProducter(producter);
                        UIManager.Instance.UIProducter.Open();
                    }
                }
            }
        }
        private void OnGridItemClicked(string entityName)
        {
            mouseBuilder.SetInBuilding(EntityAssembler.Spawn<ETPart>(entityName));
        }
    }
}
