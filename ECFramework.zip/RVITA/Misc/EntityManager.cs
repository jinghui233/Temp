﻿using RVITAFramework;
using System.Collections.Generic;
using System.IO;
using UnityUtils;

namespace RVITA
{
    public class EntityManager : MonoSingleton<EntityManager>
    {
        public List<Entity> AllOrigEntities { get; set; }
        public void Load(string path = null)
        {
            if (AllOrigEntities is null || AllOrigEntities.Count == 0)
            {
                AllOrigEntities = new List<Entity>();
                ECJsonHelper.InitDict();
            }
            AllOrigEntities.AddRange(ECJsonHelper.Load(File.ReadAllText(path)));
        }
    }
}
