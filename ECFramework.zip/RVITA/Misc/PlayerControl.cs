﻿using RVITAFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class PlayerControl : MonoSingleton<PlayerControl>
    {
        enum ControlState
        {
            Main,
            Driving,
            UI
        }
        ControlState controlState;
        ETRV rv;
        public Entity CursoredEntity { get; private set; }
        private void Update()
        {
            CursoredItem();
            switch (controlState)
            {
                case ControlState.UI:
                    ProcUI();
                    break;
                case ControlState.Main:
                    ProcMain();
                    break;
                case ControlState.Driving:
                    ProcDriving();
                    break;
                default:
                    break;
            }
        }
        private void CursoredItem()
        {
            RaycastHit2D raycastHit2D = Physics2D.Raycast(CoordAndScreen.MousePosition(), Vector2.zero);
            if (raycastHit2D.collider != null)
            {
                raycastHit2D.collider.gameObject.TryGetEntity(out Entity CursoredEntity);
                this.CursoredEntity = CursoredEntity;
            }
        }
        private void ProcMain()
        {
            if (Input.GetKeyDown(KeyCode.F) && CursoredEntity is ETPart)
            {
                rv = (CursoredEntity as ETPart).RV;
                controlState = ControlState.Driving;
            }
        }
        private void ProcDriving()
        {
            if (rv != null)
            {
                float Horizontal = Input.GetAxis("Horizontal");
                if (Horizontal != 0)
                {
                    rv.RVDrive.SetWheelMotor(Horizontal > 0 ? 100 : -100);
                }
                if (Input.GetKeyDown(KeyCode.P))
                {
                    rv.RVDrive.Park();
                }
                if (Input.GetKeyDown(KeyCode.F))
                {
                    controlState = ControlState.Main;
                }
            }
        }
        private void ProcUI()
        {

        }
    }
}
