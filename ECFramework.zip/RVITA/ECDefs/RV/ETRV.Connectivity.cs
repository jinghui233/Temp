﻿using ECFramework;
using System.Collections.Generic;
using UnityUtils;

namespace RVITA
{
    public partial class ETRV : UpdatedEntity
    {
        private QG<ETPart> qg;
        public List<ETPart> Connected(ETPart part)
        {
            return qg.ConnectedVertes(part);
        }
        public List<ETRV> SplitNew(ETPart part)
        {
            List<ETRV> newRVs = new List<ETRV>();
            List<QG<ETPart>> qgs = qg.SplitNew(part);
            foreach (QG<ETPart> qg in qgs)
            {
                ETRV rv = EntityAssembler.Spawn<ETRV>("RV");
                rv.qg = qg;
                foreach (ETPart item in qg.Vertices)
                {
                    rv.ProcessFunctionPart(item);
                }
                newRVs.Add(rv);
            }
            return newRVs;
        }
        public void FromSave()
        {
            if (SubEntities?.Count > 0)
            {
                foreach (ETPart part in SubEntities)
                {
                    qg.AddVertex(part);
                }
                foreach (ETPart part in SubEntities)
                {
                    List<ETPart> connectedParts = BuildHelper.Connected(part);
                    connectedParts?.ForEach(p => qg.AddEdge(part, p));
                }
                foreach (ETPart part in SubEntities)
                {
                    ProcessFunctionPart(part);
                }
            }
        }
    }
}
