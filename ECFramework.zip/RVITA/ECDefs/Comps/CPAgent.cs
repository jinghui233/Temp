﻿using ECFramework;
using RVITA;
using UnityEngine;

namespace RVITA
{
    public class CPAgent : UpdatedComp
    {
        public float AlertRange { get; set; }
        public Camp camp;
        public LayerEnum rivalCampLayer;
        ETCharacter target;
        ETTurret turret;
        ETMeleeWeapon meleeWeapon;
        CPMove move;
        public override void SetReferences()
        {
            base.SetReferences();
            move = Entity.GetComp<CPMove>();
            if (Entity.TryGetComp(out CPKeyMove cPKeyMove))
            {
                cPKeyMove.Disabled = true;
            }
        }
        public void SetCamp(Camp camp)
        {
            this.camp = camp;
            rivalCampLayer = Camper.GetRivalCampLayer(camp);
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            Entity.TryGetSubEntity(out turret);
            if (Entity.TryGetSubEntity(out turret))
            {
                if (turret.TryGetComp(out CPMouseAim cPMouseAim))
                {
                    cPMouseAim.Disable = true;
                }
            }
            if (Entity.TryGetSubEntity(out meleeWeapon))
            {
                if (meleeWeapon.TryGetComp(out CPMouseAim cPMouseAim))
                {
                    cPMouseAim.Disable = true;
                }
            }
        }
        float timeRemaining;
        public void RandumJump()
        {
            timeRemaining -= Time.deltaTime;
            if (timeRemaining <= 0 && move.GameObject.transform.position.y < 5)
            {
                timeRemaining = Random.Range(2, 4);
                move.Jump(Random.Range(4, 8));
            }
        }
        public override void Update()
        {
            RandumJump();
            if (target != null && target.alive)
            {
                if (meleeWeapon != null)
                {
                    move.ApproachTo(target.GameObject.transform.position, meleeWeapon.AttackRange * 0.6f);
                    meleeWeapon.TakeAim(target.GameObject.transform.position);
                    meleeWeapon.Attack();
                }
                else if (turret != null)
                {
                    move.ApproachTo(target.GameObject.transform.position, turret.AttackRange * 0.7f);
                    turret.TakeAim(target.GameObject.transform.position);
                    turret.Attack();
                }
            }
            else
            {
                Collider2D[] colliders = Physics2D.OverlapCircleAll(GameObject.transform.position, AlertRange, 1 << (int)rivalCampLayer);
                foreach (var collider in colliders)
                {
                    if (collider.transform.TryGetEntity(out Entity entity) && entity is ETCharacter)
                    {
                        target = entity as ETCharacter;
                    }
                }
            }
        }
    }
}
