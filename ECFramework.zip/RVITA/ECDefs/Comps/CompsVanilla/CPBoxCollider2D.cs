﻿using ECFramework;
using UnityEngine;
namespace RVITA
{
    public class CPBoxCollider2D : CPVanilla<BoxCollider2D>
    {
    }
}
