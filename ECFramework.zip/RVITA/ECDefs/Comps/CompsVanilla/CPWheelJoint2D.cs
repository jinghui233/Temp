﻿using ECFramework;
using UnityEngine;

namespace RVITA
{
    /// <summary>
    /// 弹簧在对象之间施力时，往往会超过对象之间设定的距离，然后反复反弹，产生连续振荡。
    /// Damping Ratio 用于设置对象在多长时间内停止移动。Frequency 用于设置对象在目标距离的任何一侧振荡的速度。
    /// </summary>
    public class CPWheelJoint2D : CPVanilla<WheelJoint2D>
    {
        /// <summary>
        /// 0-1(几乎不动的弹簧)
        /// </summary>
        public float DampingRatio { get; set; } = 1;
        /// <summary>
        /// 0(柔软)-1,000,000(僵硬)Frequency 为零是特殊情况：这种情况下会产生最大刚度的弹簧（实测并不会）
        /// </summary>
        public float Frequency { get; set; } = 1000000;
        public float Angle { get; set; }
        public bool UseMotor { get; set; }
        public float MotorSpeed { get; set; }
        public override void InitUnityComponent()
        {
            base.InitUnityComponent();
            JointSuspension2D jointSuspension2D = UnityComp.suspension;
            jointSuspension2D.dampingRatio = DampingRatio;
            jointSuspension2D.frequency = Frequency;
            UnityComp.suspension = jointSuspension2D;
        }
    }
}
