﻿using ECFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace RVITA
{
    public class CPStorage : Comp, ILogisticsInterface
    {
        public StorageDomain StorageDomain { get; set; }
        public Dictionary<string, ThingContainer> Things = new Dictionary<string, ThingContainer>();
        public bool IsChest { get; set; }
        public float ItemCount(string name)
        {
            if (Things.TryGetValue(name, out ThingContainer thingContainer))
            {
                return thingContainer.Count;
            }
            return 0;
        }
        public float In(string name, float count)
        {
            if (Things.TryGetValue(name, out ThingContainer thingContainer))
            {
                return thingContainer.In(count);
            }
            else
            {
                thingContainer = new ThingContainer() { Name = name };
                Things.Add(name, thingContainer);
                return thingContainer.In(count);
            }
        }
        public float Out(string name, float count)
        {
            if (Things.TryGetValue(name, out ThingContainer thingContainer))
            {
                if (thingContainer.Count <= count)
                {
                    Things.Remove(name);
                }
                return thingContainer.Out(count);
            }
            return 0;
        }
        public float Empty(string name)
        {
            if (Things.TryGetValue(name, out ThingContainer thingContainer))
            {
                return thingContainer.Empty();
            }
            return 0;
        }
    }
}
