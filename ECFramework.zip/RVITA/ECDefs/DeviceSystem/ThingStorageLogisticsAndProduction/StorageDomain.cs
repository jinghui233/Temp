﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RVITA
{
    public class StorageDomain
    {
        public List<ILogisticsInterface> Endpoints = new List<ILogisticsInterface>();
        public void AddStorage(ILogisticsInterface endpoint)
        {
            Endpoints.Add(endpoint);
            endpoint.StorageDomain = this;
        }
        public StorageDomain Combine(StorageDomain storageDomain)
        {
            foreach (CPStorage item in storageDomain.Endpoints)
            {
                if (!Endpoints.Contains(item))
                {
                    Endpoints.Add(item);
                }
            }
            storageDomain.Endpoints.Clear();
            return this;
        }
        public float In(string name, float count)
        {
            foreach (ILogisticsInterface item in Endpoints)
            {
                if (item is CPStorage)
                {
                    count = item.In(name, count);
                    if (count <= 0)
                    {
                        break;
                    }
                }
            }
            return count;
        }
        public float Out(string name, float count)
        {
            float tmpCount = 0;
            foreach (ILogisticsInterface item in Endpoints)
            {
                if (item is CPStorage)
                {
                    tmpCount += item.Out(name, count - tmpCount);
                    if (tmpCount == count)
                    {
                        break;
                    }
                }
            }
            return tmpCount;
        }
    }
}
