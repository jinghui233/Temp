﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RVITA
{
    public struct Thing
    {
        public string Name;
        public float Weight;
    }
    public class ThingInfo
    {
        public static Dictionary<string, Thing> ThingDic = new Dictionary<string, Thing>();
    }
    public struct ThingContainer
    {
        public string Name;
        public float Count;
        public float MaxCount;
        public float In(float count)
        {
            if (MaxCount > 0 && count + Count >= MaxCount)
            {
                count -= MaxCount - Count;
                Count = MaxCount;
                return count;
            }
            else
            {
                Count += count;
                return 0;
            }
        }
        public float Out(float count)
        {
            if (Count >= count)
            {
                Count -= count;
                return count;
            }
            else
            {
                count = Count;
                Count = 0;
                return count;
            }
        }
        public float Empty()
        {
            float count = Count;
            Count = 0;
            return count;
        }
    }
}
