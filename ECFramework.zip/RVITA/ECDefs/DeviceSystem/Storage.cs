﻿using UnityEngine;

namespace RVITA
{
    public class Storage
    {
        public Product product;
        public string Name { get { return product.Name; } set { product.Name = value; } }
        public float Max { get; set; }
        public float In(float value)
        {
            float last;
            if (product.Count + value > Max)
            {
                last = product.Count + value - Max;
                product.Count = Max;
            }
            else
            {
                last = 0;
                product.Count += value;
            }
            return last;
        }
        public float Out(float value)
        {
            if (value > product.Count)
            {
                value = product.Count;
                product.Count = 0;
            }
            else
            {
                product.Count -= value;
            }
            return value;
        }
    }
}
