﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RVITA
{
    public struct Product
    {
        public string Name;
        public float Count;
    }
}
