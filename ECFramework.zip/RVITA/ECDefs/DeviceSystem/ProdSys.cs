﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RVITA
{
    public class ProdSys
    {
        Dictionary<string, Storage> AllStorages = new Dictionary<string, Storage>
            {
                { "power", new Storage() },
                { "iron", new Storage() },
                { "wood", new Storage(){ Max=10000} },
                { "coal", new Storage(){ Max=10000} },
                { "plastic", new Storage() },
                { "fuel", new Storage(){ Max=10000} }
            };
        public string info { get { return $"fuel:{AllStorages["fuel"].product.Count}\nwood:{AllStorages["wood"].product.Count}\ncoal:{AllStorages["coal"].product.Count}"; } }
        public float StoreIn(string name, float value)
        {
            return AllStorages[name].In(value);
        }
        public float StoreOut(string name, float value)
        {
            return AllStorages[name].Out(value);
        }
    }
}
