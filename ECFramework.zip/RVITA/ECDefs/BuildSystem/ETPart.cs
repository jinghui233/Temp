﻿using ECFramework;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class ETPart : UpdatedEntity
    {
        public LayerEnum LayerEnum { get; set; }
        public bool BlueprintMod { get; set; }
        public string ConnAreaDef { get; set; }//LRTD分别代表上下左右
        [XmlIgnore] public ETRV RV { get; private set; }
        [XmlIgnore] public CPSpriteRenderer CPSpriteRenderer { get; private set; }
        public Recipe Recipe { get; set; }
        public bool Construct(ILogisticsInterface logisticsInterface, float workQuantity)
        {
            if (!BlueprintMod || Recipe == null || Recipe.ProductionDone)
            {
                return true;
            }
            if (!Recipe.MaterialDone())
            {
                foreach (RecipeItem item in Recipe.MaterialInfo)
                {
                    float materialCount = Recipe.Material.ItemCount(item.Name);
                    if (materialCount < item.Amount)
                    {
                        Recipe.Material.In(item.Name, logisticsInterface.Out(item.Name, item.Amount - materialCount));
                    }
                }
            }
            if(Recipe.MaterialDone())
            {
                Recipe.Work(workQuantity);
                if (Recipe.ProductionDone)
                {
                    DisableGhosting();
                    return true;
                }
            }
            return false;
        }
        public virtual void OnBuiltTo(ETRV rV)
        {
            RV = rV;
        }
        public override void Update()
        {
            if (BlueprintMod)
            {
                return;
            }
            base.Update();
        }
        public override void InitUnityComponent()
        {
            base.InitUnityComponent();
            Layerer.SetLayer(GetOrCreateGameObject(), LayerEnum);
        }
        public override void SetReferences()
        {
            base.SetReferences();
            CPSpriteRenderer = GetComp<CPSpriteRenderer>();
            DrawGizmos = true;
        }
        public virtual void EnableGhosting()
        {
            BlueprintMod = true;
            Joint2D[] joint2Ds = GameObject.GetComponentsInChildren<Joint2D>();
            foreach (Joint2D joint in joint2Ds)
            {
                joint.enabled = false;
            }
            Rigidbody2D[] rigidbody2Ds = GameObject.GetComponentsInChildren<Rigidbody2D>();
            foreach (var item in rigidbody2Ds)
            {
                item.isKinematic = true;
            }
        }
        public virtual void DisableGhosting()
        {
            Joint2D[] joint2Ds = GameObject.GetComponentsInChildren<Joint2D>();
            foreach (Joint2D joint in joint2Ds)
            {
                joint.enabled = true;
            }
            Rigidbody2D[] rigidbody2Ds = GameObject.GetComponentsInChildren<Rigidbody2D>();
            foreach (var item in rigidbody2Ds)
            {
                item.isKinematic = false;
            }
            BlueprintMod = false;
        }
        public override void OnDrawGizmos()
        {
            if (!Application.isPlaying)
            {
                return;
            }
            base.OnDrawGizmos();
            Gizmos.color = Color.yellow;
            BoxCollider2D collider = GameObject.GetComponent<BoxCollider2D>();
            GizmosHelper.DrawRotatedWireRect((Vector2)Transform.position + collider.offset, collider.size.x, collider.size.y, Transform.rotation.eulerAngles.z);
            foreach (var rect in BuildHelper.CalcRects(this))
            {
                GizmosHelper.DrawRotatedWireRect(new Vector2(rect.x, rect.y), rect.z, rect.w, Transform.rotation.eulerAngles.z);
                Gizmos.DrawSphere(new Vector2(rect.x, rect.y), 0.02f);
            }
            Gizmos.color = Color.white;
        }
    }
}
