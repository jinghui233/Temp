﻿
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class UIGaming : MonoSingleton<UIGaming>
    {
        public Canvas canvas;
    }
}
