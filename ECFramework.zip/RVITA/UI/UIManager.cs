﻿using UnityUtils;
using UnityEngine;
namespace RVITA
{
    public class UIManager : MonoSingleton<UIManager>
    {
        public UIElecGtr UIElecGtr;
        public UIProducter UIProducter;
    }
}
