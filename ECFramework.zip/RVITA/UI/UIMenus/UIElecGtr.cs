using RVITA;
using UnityEngine;
using UnityEngine.UI;

public class UIElecGtr : MonoBehaviour
{
    public ProgressBar ProgressBar;
    public Text Titel;
    public Text Info;   
    public CPElecGtr CPElecGtr;
    public void Close()
    {
        if (gameObject.activeSelf)
        {
            CPElecGtr = null;
            gameObject.SetActive(false);
        }
    }
    void UI()
    {
        if (CPElecGtr != null)
        {
            ProgressBar.SetValue(CPElecGtr.TimeRemaining / CPElecGtr.TimeUsage);
            Titel.text = "�����";
            Info.text = "";
        }
    }
    public void Open()
    {
        if (!gameObject.activeSelf)
        {
            gameObject.SetActive(true);
        }
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Close();
        }
        UI();
    }
}
