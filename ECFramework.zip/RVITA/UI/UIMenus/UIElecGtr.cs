using RVITA;
using UnityEngine;
using UnityEngine.UI;

public class UIElecGtr : SimpleWindow
{
    public ProgressBar ProgressBar;
    public Text Info;
    private CPElecGtr elecGtr;
    public void SetElecGtr(CPElecGtr elecGtr)
    {
        this.elecGtr = elecGtr;
        ProgressBar.SetValue(elecGtr.TimeRemaining / elecGtr.TimeUsage);
        Title.text = elecGtr.Entity.DefName;
        Info.text = "";
    }
    void Update()
    {
        if (Closed) return;
        if (elecGtr != null)
        {
            ProgressBar.SetValue(elecGtr.TimeRemaining / elecGtr.TimeUsage);
        }
    }
}
