﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace SimpleUI
{
    public class SimpleInventoryItem : MonoBehaviour
    {
        public SimpleInventory SimpleInventory;
        public string TexterPath;
        public Text TextName;
        public Text TextCount;
    }
}
