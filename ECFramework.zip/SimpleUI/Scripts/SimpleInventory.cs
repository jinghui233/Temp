﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace SimpleUI
{
    public class SimpleInventory : MonoBehaviour, IPointerClickHandler
    {//操作类型：1.快速移动 鼠标右键，快速移动一半物品 Ctrl+鼠标右键，拿起/放下物品 鼠标左键，拿起/放下一半物品Ctrl+鼠标左键，如果已经有拿起的物品 Ctrl+鼠标左键放下已经拿起的物品的一半
        public float GridSize = 100;
        [SerializeField]
        private GridLayoutGroup GridLayoutGroup;//背包格子容器
        private SimpleInventoryItem ItemPickedUp;

        public void OnPointerClick(PointerEventData eventData)
        {
            // 将点击的屏幕坐标转换为背包格子内的本地坐标  
            Vector2 clickPosition;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(GridLayoutGroup.transform as RectTransform, eventData.position, eventData.pressEventCamera, out clickPosition);

            // 根据GridLayoutGroup的属性和点击的本地坐标计算格子索引  
            int columnIndex = Mathf.FloorToInt(clickPosition.x / GridLayoutGroup.cellSize.x);
            int rowIndex = Mathf.FloorToInt(clickPosition.y / GridLayoutGroup.cellSize.y);

            // 根据GridLayoutGroup的排列方式调整索引  
            // 假设是从左到右，从上到下的排列方式  
            int index = rowIndex * GridLayoutGroup.constraintCount + columnIndex;
            if (eventData.button == PointerEventData.InputButton.Left)
            {
                if (Input.GetKey(KeyCode.LeftControl))
                {

                }
                else
                {

                }
            }
            else if (eventData.button == PointerEventData.InputButton.Right)
            {
                if (Input.GetKey(KeyCode.LeftControl))
                {

                }
                else
                {

                }
            }
        }
    }
}
