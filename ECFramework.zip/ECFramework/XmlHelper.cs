﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ECFramework
{
    public class XmlHelper
    {
        public static Dictionary<string, Type> typeDic = new Dictionary<string, Type>();
        public static XmlDocument Serialize(object obj)
        {
            XmlDocument xmlDoc = new XmlDocument();
            XmlNode xmlNode = Serialize(obj, "root", xmlDoc);
            xmlDoc.AppendChild(xmlNode);
            return xmlDoc;
        }
        public static XmlNode Serialize(object obj, string name, XmlDocument xmlDoc)
        {
            if (obj == null)
                return null;
            Type type = obj.GetType();
            XmlNode xmlNode = null;
            if (type.IsGenericType)
            {
                if (type.GetGenericTypeDefinition() == typeof(Dictionary<,>))
                {//--------------------------------字典--------------------------------
                }
                else if (type.GetGenericTypeDefinition() == typeof(List<>))
                {//--------------------------------列表--------------------------------
                    xmlNode = xmlDoc.CreateElement(name);
                    string GenericTypeName = type.GenericTypeArguments[0].Name;
                    foreach (var item in obj as IEnumerable)
                    {
                        XmlNode childNode = Serialize(item, GenericTypeName, xmlDoc);
                        if (childNode != null) xmlNode.AppendChild(childNode);
                    }
                }
            }
            else if (type == typeof(string))
            {//--------------------------------字符串--------------------------------
                xmlNode = xmlDoc.CreateElement(name);
                xmlNode.InnerText = obj.ToString();
            }
            else if (type.IsValueType)
            {
                if (type == typeof(int) || type == typeof(float) || type == typeof(bool) || type == typeof(double))
                {//--------------------------------普通值--------------------------------
                    xmlNode = xmlDoc.CreateElement(name);
                    xmlNode.InnerText = obj.ToString();
                }
                else
                {//--------------------------------结构体--------------------------------
                    xmlNode = xmlDoc.CreateElement(name);
                    FieldInfo[] fieldInfos = type.GetFields();
                    foreach (FieldInfo fieldInfo in fieldInfos)
                    {
                        if (!fieldInfo.IsLiteral)
                        {
                            XmlNode childNode = Serialize(fieldInfo.GetValue(obj), fieldInfo.Name, xmlDoc);
                            if (childNode != null) xmlNode.AppendChild(childNode);
                        }
                    }
                }
            }
            else if (type.IsClass)
            {//--------------------------------类--------------------------------
                xmlNode = xmlDoc.CreateElement(name);
                foreach (PropertyInfo propertyInfo in obj.GetType().GetProperties())
                {
                    XmlNode childNode = Serialize(propertyInfo.GetValue(obj), propertyInfo.Name, xmlDoc);
                    if (childNode != null) xmlNode.AppendChild(childNode);
                }
            }
            return xmlNode;
        }
        public static object Deserialize(XmlNode xmlNode, Type type)
        {
            object obj;
            if (type.IsValueType)
            {
                if (type == typeof(int))
                {
                    obj = Convert.ToInt32(obj);
                }
            }
        }
        public static object ManualDeserialize(Type type, XmlNode xmlNode)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(type);
            xmlSerializer.Deserialize(xmlNode.ToString());
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlNode.OuterXml);
            object obj = Activator.CreateInstance(type);
            foreach (var property in type.GetProperties())
            {
                XmlNode propertyNode = xmlDoc.SelectSingleNode($"//{property.Name}");
                property.SetValue(obj, Convert.ChangeType(propertyNode.InnerText, property.PropertyType));
            }
            return obj;
        }
    }
}
