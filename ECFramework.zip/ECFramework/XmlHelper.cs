﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;

namespace ECFramework
{
    [XmlRoot("Entities")]
    public struct XmlWrapper
    {
        [XmlElement("Entity")]
        public List<Entity> Entities { get; set; }
    }
    public class XmlHelper
    {
        public static Dictionary<string, string> XmlPool = new();
        public static XmlSerializer XmlSerializer { get; private set; }
        public static List<Type> Types { get; private set; } = new List<Type>();
        public static void InitTypes(Type[] types = null)
        {
            if (types == null || types.Length == 0)
                types = Assembly.GetExecutingAssembly().GetTypes();
            Type ECType = typeof(IEC);
            foreach (Type item in types)
            {
                if (!item.IsClass) continue;
                if (item.IsGenericType) continue;
                if (ECType.IsAssignableFrom(item))
                {
                    Types.Add(item);
                }
            }
        }
        public static void Load(string path)
        {
            List<Entity> entities = DeserializeFromFile(path);
            foreach (Entity entity in entities)
            {
                XmlPool.Add(entity.DefName, Serialize(new List<Entity>() { entity }));
            }
        }
        public static Entity GetEntity(string defName)
        {
            return Deserialize(XmlPool[defName]).First();
        }
        public static void InitXmlSerializer()
        {
            XmlSerializer = new XmlSerializer(typeof(XmlWrapper), Types.ToArray());
        }
        public static void SerializeToFile(List<Entity> obj, string path)
        {
            XmlWrapper xmlWrapper = new() { Entities = obj };
            using FileStream fileStream = new(path, FileMode.Create);
            XmlSerializer.Serialize(fileStream, xmlWrapper);
        }
        public static string Serialize(List<Entity> obj)
        {
            XmlWrapper xmlWrapper = new() { Entities = obj };
            using StringWriter stringWriter = new();
            XmlSerializer.Serialize(stringWriter, xmlWrapper);
            return stringWriter.ToString();
        }
        public static List<Entity> DeserializeFromFile(string path)
        {
            using FileStream fileStream = new(path, FileMode.Open);
            XmlWrapper xmlWrapper = (XmlWrapper)XmlSerializer.Deserialize(fileStream);
            return xmlWrapper.Entities;
        }
        public static List<Entity> Deserialize(string xmlText)
        {
            using StringReader stringReader = new(xmlText);
            XmlWrapper xmlWrapper = (XmlWrapper)XmlSerializer.Deserialize(stringReader);
            return xmlWrapper.Entities;
        }
    }
}
