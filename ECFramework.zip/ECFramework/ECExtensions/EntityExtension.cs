﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ECFramework
{
    public static class EntityExtension
    {
        public static Dictionary<string, Type> ECdic;
        public static void InitDict(Type[] types = null)
        {
            if (types == null || types.Length == 0)
                types = Assembly.GetExecutingAssembly().GetTypes();
            if (ECdic == null)
                ECdic = new Dictionary<string, Type>();
            Type ECType = typeof(IEC);
            foreach (Type item in types)
            {
                if (!item.IsClass) continue;
                if (ECType.IsAssignableFrom(item))
                {
                    if (item.Name.StartsWith("ET") || item.Name.StartsWith("CP"))
                    {
                        ECdic.Add(item.Name[2..], item);
                    }
                }
            }
        }
        public static Entity Deserialize(XmlNode node)
        {
            foreach (XmlNode subNode in node.ChildNodes)
            {

            }
            return null;
        }
        public static XmlNode Serialize(this Entity entity)
        {
            return null;
        }
    }
}
