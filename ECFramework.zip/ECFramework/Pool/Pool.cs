﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace ECFramework
{
    public class Pool
    {
        public Dictionary<string, EntityPool> NamePool = new();
        public Transform transform;
        public Pool(Transform transform)
        {
            this.transform = transform;
        }
        public void Create(string defName)
        {
            EntityPool entityPool = new(defName, transform);
            NamePool.Add(defName, entityPool);
        }
        public bool Exist(string defName)
        {
            return NamePool.ContainsKey(defName);
        }
        public Entity Spawn(string defName)
        {
            Entity entity = NamePool[defName].GetInstance();
            return entity;
        }
        public T Spawn<T>(string defName) where T : Entity
        {
            return Spawn(defName) as T;
        }
        public void UnSpawn(Entity entity)
        {
            NamePool[entity.DefName].ReturnInstance(entity);
        }
    }
}
