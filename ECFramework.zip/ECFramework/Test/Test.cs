﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using UnityEngine;

namespace ECFramework
{
    public class Test : MonoBehaviour
    {
        private void Start()
        {
            EntityExtension.InitDict(Assembly.GetExecutingAssembly().GetTypes());
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("Assets/ECFramework/Test/TestData/XMLFile1.xml");
            EntityExtension.Deserialize(xmlDoc);
            Test1();
        }
        void Test1()
        {
            ETCharacter newcharacter()
            {
                ETCharacter character = new ETCharacter();
                character.CPSpriteRenderer = new CPSpriteRenderer() { GraphicsPath="fewafo"};
                character.CPBoxeCollider2D = new CPBoxCollider2D();
                character.Comps = new List<Comp>();
                character.Comps.Add(character.CPSpriteRenderer);
                character.Comps.Add(character.CPBoxeCollider2D);
                return character;
            }
            string path = "Assets/ECFramework/Test/TestData/XMLFile2.xml";
            ETCharacter eTCharacter = newcharacter();
            eTCharacter.Children = new List<Entity>();
            eTCharacter.Children.Add(newcharacter());
            eTCharacter.Children.Add(newcharacter());
            eTCharacter.CPSpriteIDs.Add("fewaf", 12);
            eTCharacter.CPSpriteIDs.Add("few", 13);
            //XmlSerializer xmlSerializer = new XmlSerializer(typeof(ETCharacter));
            //FileStream writer = File.Open(path, FileMode.OpenOrCreate);
            //xmlSerializer.Serialize(writer, eTCharacter);
            XmlDocument xmlDocument = XmlHelper.Serialize(eTCharacter);
            xmlDocument.Save(path);
        }
    }
}
