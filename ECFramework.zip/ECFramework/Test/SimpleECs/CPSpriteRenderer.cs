﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECFramework
{
    public class CPSpriteRenderer : Comp
    {
        public string GraphicsPath { get; set; }
        public string MaterialPath { get; set; }
    }
}
