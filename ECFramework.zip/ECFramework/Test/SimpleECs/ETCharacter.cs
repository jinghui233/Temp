﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECFramework
{
    public class ETCharacter : Entity
    {
        public int Tmp { get; set; } = 0;
        public float Tmpf { get; set; } = 0.2f;
        public CPBoxCollider2D CPBoxeCollider2D { get; set; }
        public CPSpriteRenderer CPSpriteRenderer { get; set; }
        public Dictionary<string, int> CPSpriteIDs { get; set; } = new Dictionary<string, int>();
    }
}
