﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECFramework
{
    public class Comp : IEC
    {
        public Entity Entity { get; set; }

        public void Create()
        {
        }

        public void SetReferences()
        {
        }
    }
}
