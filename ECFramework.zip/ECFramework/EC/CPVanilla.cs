﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using UnityEngine;

namespace ECFramework
{
    public class CPVanilla<T> : Comp where T : Component
    {
        [XmlIgnore]
        public T UnityComp { get; set; }
        public override void InitUnityComponent()
        {
            base.InitUnityComponent();
            UnityComp = Entity.GetOrCreateGameObject().GetOrCreate<T>();
        }
    }
}
