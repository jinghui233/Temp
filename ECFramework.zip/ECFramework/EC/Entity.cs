﻿using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;

namespace ECFramework
{
    public class Entity : IEC
    {
        [XmlIgnore]
        public GameObject GameObject { get; set; }
        public Vector3 LocalPosition { get; set; }
        public List<Comp> Comps { get; set; }
        public List<Entity> Children { get; set; }
        public void Create()
        {
        }

        public void SetReferences()
        {
        }
    }
}
