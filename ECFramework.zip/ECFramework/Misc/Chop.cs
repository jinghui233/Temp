﻿using System;
using UnityEngine;

namespace ECFramework
{
    public class Chop
    {
        public float startAngle;
        public float endAngle;
        public Vector3 curAngle;
        float currentVelocity;
        float smoothTime = 0.04f;
        Transform handledTransform;
        bool toEndAngle;
        public event Action Finished;
        public bool Finish { get; private set; } = true;
        public void Start(Transform transform, float deltaAngle)
        {
            handledTransform = transform;
            curAngle = transform.rotation.eulerAngles;
            startAngle = curAngle.z;
            endAngle = curAngle.z + deltaAngle;
            currentVelocity = 0;
            toEndAngle = true;
            Finish = false;
        }
        public void Start(Transform transform)
        {
            if (90 < transform.rotation.eulerAngles.z && transform.rotation.eulerAngles.z < 270)
                Start(transform, 120);
            else
                Start(transform, -120);
        }
        public void Update(float deltaTime)
        {
            if (Finish)
                return;
            if (toEndAngle)
            {
                curAngle.z = Mathf.SmoothDampAngle(curAngle.z, endAngle, ref currentVelocity, smoothTime, 10000, deltaTime: deltaTime);
                if (Mathf.Abs(curAngle.z - endAngle) < 1)
                {
                    curAngle.z = endAngle;
                    toEndAngle = false;
                }
            }
            else
            {
                curAngle.z = Mathf.SmoothDampAngle(curAngle.z, startAngle, ref currentVelocity, smoothTime, 10000, deltaTime: deltaTime);
                if (Mathf.Abs(curAngle.z - startAngle) < 1)
                {
                    curAngle.z = startAngle;
                    Finish = true;
                    Finished?.Invoke();
                }
            }
            handledTransform.rotation = Quaternion.Euler(curAngle);
        }
    }
}
