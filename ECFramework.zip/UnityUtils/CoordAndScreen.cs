﻿using UnityEngine;

namespace UnityUtils
{
    public class CoordAndScreen
    {
        public static Vector3 MousePosition()
        {
            return Camera.main.ScreenToWorldPoint(Input.mousePosition);
        }
        public static Vector3 ScreenPosition(Vector3 worldPosition)
        {
            return Camera.main.WorldToScreenPoint(worldPosition);
        }
    }
}
