﻿using System.Collections.Generic;
using UnityEngine;
using UnityUtils;

namespace ECFramework
{
    public class EntityAssembler : MonoSingleton<EntityAssembler>
    {
        public Pool Pool;
        protected override void Awake()
        {
            base.Awake();
            Pool = new Pool(transform);
            Application.runInBackground = true;
        }
        public static void Create(string defName)
        {
            Instance.Pool.Create(defName);
        }
        public static T Spawn<T>(string defName) where T : Entity
        {
            return Instance.SpawnInternal(defName) as T;
        }
        public static void UnSpawn(Entity entity)
        {
            Instance.UnSpawnInternal(entity);
        }
        private Entity SpawnInternal(string defName)
        {
            Entity entity = Pool.Spawn(defName);
            AssembleSubEntities(entity);
            CallSetRefenences(entity);
            CallOnSpawn(entity);
            return entity;
        }
        private void UnSpawnInternal(Entity entity)
        {
            DisassembleSubEntities(entity);
            Pool.UnSpawn(entity);
        }
        private void CallSetRefenences(Entity entity)
        {
            entity.Comps?.ForEach(c => c.SetReferences());
            entity.SubEntities?.ForEach(e => CallSetRefenences(e));
            entity.SetReferences();
        }
        private void CallOnSpawn(Entity entity)
        {
            entity.Comps?.ForEach(c => c.OnSpawn());
            entity.SubEntities?.ForEach(e => CallOnSpawn(e));
            entity.OnSpawn();
        }
        private void AssembleSubEntities(Entity entity)
        {
            if (entity.SubEntities != null)
            {
                for (int i = 0; i < entity.SubEntities.Count; i++)
                {
                    Entity subEntity = Pool.Spawn(entity.SubEntities[i].DefName);
                    subEntity.Transform.parent = entity.Transform;
                    subEntity.LocalPosition = entity.SubEntities[i].LocalPosition;
                    entity.SubEntities[i] = subEntity;
                }
                for (int i = 0; i < entity.SubEntities.Count; i++)
                {
                    AssembleSubEntities(entity.SubEntities[i]);
                }
            }
        }
        private void DisassembleSubEntities(Entity entity)
        {
            if (entity.SubEntities != null)
            {
                for (int i = 0; i < entity.SubEntities.Count; i++)
                {
                    DisassembleSubEntities(entity.SubEntities[i]);
                }
                for (int i = 0; i < entity.SubEntities.Count; i++)
                {
                    Pool.UnSpawn(entity.SubEntities[i]);
                    entity.SubEntities[i] = new Entity() { DefName = entity.SubEntities[i].DefName, LocalPosition = entity.SubEntities[i].LocalPosition };
                }
            }
        }
    }
}
