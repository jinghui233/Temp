﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace ECFramework
{
    public class Pool
    {
        public Dictionary<string, EntityPool> NamePool = new();
        public Transform transform;
        public Pool(Transform transform)
        {
            this.transform = transform;
        }
        public void Create(string defName)
        {
            EntityPool entityPool = new(defName, transform);
            NamePool.Add(defName, entityPool);
        }
        public Entity Spawn(string name)
        {
            Entity entity = NamePool[name].GetInstance();
            return entity;
        }
        public T Spawn<T>(string name) where T : Entity
        {
            return Spawn(name) as T;
        }
        public void UnSpawn(Entity entity)
        {
            NamePool[entity.DefName].ReturnInstance(entity);
        }
    }
}
