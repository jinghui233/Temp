﻿using System.Collections.Generic;
using UnityEngine;

namespace ECFramework
{
    public class EntityPool
    {
        private readonly Queue<Entity> instanceQueue = new();
        public Transform transform;
        public string DefName { get; private set; }
        public int InstanceCount { get => instanceQueue.Count; }
        public EntityPool(string defName, Transform transform)
        {
            this.DefName = defName;
            this.transform = transform;
        }
        public Entity GetInstance()
        {
            Entity entity;
            if (instanceQueue.Count > 0)
            {
                entity = instanceQueue.Dequeue();
            }
            else
            {
                entity = XmlHelper.GetEntity(DefName);
                if (!string.IsNullOrWhiteSpace(entity.PrefebPath))
                {
                    entity.GameObject = ResorceHelper.LoadResorce<GameObject>(entity.PrefebPath);
                }
                entity.Comps?.ForEach(c => { c.Entity = entity; c.InitUnityComponent(); });
                entity.InitUnityComponent();
            }
            return entity;
        }
        public void ReturnInstance(Entity instance)
        {
            instanceQueue.Enqueue(instance);
            if (instance.GameObject != null)
            {
                instance.GameObject.transform.SetParent(transform);
            }
            instance.OnUnSpawn();
        }
    }
}
