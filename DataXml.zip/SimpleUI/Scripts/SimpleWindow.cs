using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class SimpleWindow : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerClickHandler
{
    [SerializeField]
    CanvasGroup canvasGroup;
    [SerializeField]
    RectTransform WinBarRectTransform;
    public bool Closed { get; private set; }
    public void Close()
    {
        canvasGroup.alpha = 0;
        canvasGroup.interactable = false;
        canvasGroup.blocksRaycasts = false;
        Closed = true;
    }
    public void Open()
    {
        canvasGroup.alpha = 1;
        canvasGroup.interactable = true;
        canvasGroup.blocksRaycasts = true;
        Closed = false;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        transform.SetAsLastSibling();
        if (RectTransformUtility.RectangleContainsScreenPoint(WinBarRectTransform, Input.mousePosition))
        {
            _isDragging = true;
        }
    }
    bool _isDragging;
    public void OnDrag(PointerEventData eventData)
    {
        if (_isDragging)
        {
            transform.position += (Vector3)eventData.delta;
        }
    }
    public void OnEndDrag(PointerEventData eventData)
    {
        _isDragging = false;
    }
    public void OnPointerClick(PointerEventData eventData)
    {
        transform.SetAsLastSibling();
    }
}