﻿using UnityEngine;
using UnityUtils;

namespace UnityUtils
{
    /// <summary>
    /// 未开发完，待完善（移动组件，平滑加减速，目标移动和直接移动，最大速度可控）
    /// </summary>
    public class Rigidbody2DMovement : MonoBehaviour
    {
        public float a = 50;
        public float stopa = 100;
        public float maxSpeed = 5f; // 最大速度
        private Rigidbody2D rb; // 刚体组件
        public float? target;
        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
        }
        public void Move(float value)
        {
            Vector2 speed = rb.velocity;
            if (value > 0)
            {
                speed.x += a * Time.deltaTime;
            }
            else if (value < 0)
            {
                speed.x -= a * Time.deltaTime;
            }
            rb.velocity = LimitMaxSpeed(speed);
        }
        public void SetTarget(float target)
        {
            this.target = target;
            Stopping = false;
        }
        private void Update()
        {
            float Horizontal = Input.GetAxis("Horizontal");
            if (Horizontal != 0)
            {
                Move(Horizontal);
            }
            if (Input.GetMouseButtonDown(1))
            {
                SetTarget(CoordAndScreen.MousePosition().x);
            }
        }
        public bool Stopping;

        private void FixedUpdate()
        {
            if (target == null)
            {
                Stopping = false;
                return;
            }
            if (Mathf.Abs(target.Value - transform.position.x) < 0.1f)
            {
                target = null;
                rb.velocity = new Vector2(0, rb.velocity.y);
            }
            if (target != null)
            {
                Vector2 speed = rb.velocity;
                if (!Stopping)
                {
                    Stopping = SVA.NeedStop(transform.position.x, speed.x, stopa, target.Value);
                }
                if (Stopping)
                {
                    if (Mathf.Abs(rb.velocity.x) > stopa * Time.fixedDeltaTime)
                    {
                        if (speed.x > 0)
                        {
                            speed.x -= stopa * Time.fixedDeltaTime;
                        }
                        else
                        {
                            speed.x += stopa * Time.fixedDeltaTime;
                        }
                    }
                    else
                    {
                        speed.x = 0;
                        target = null;
                    }
                }
                else
                {
                    if (target > transform.position.x)
                    {
                        speed.x += a * Time.fixedDeltaTime;
                    }
                    else
                    {
                        speed.x -= a * Time.fixedDeltaTime;
                    }
                    speed = LimitMaxSpeed(speed);
                }
                rb.velocity = speed;
            }
        }
        Vector2 LimitMaxSpeed(Vector2 speed)
        {
            if (speed.x > 0)
            {
                speed.x = Mathf.Clamp(speed.x, 0, maxSpeed);
            }
            else
            {
                speed.x = Mathf.Clamp(speed.x, -maxSpeed, 0);
            }
            return speed;
        }
    }
}
