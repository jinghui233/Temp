using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
[RequireComponent(typeof(GridLayoutGroup))]
public class GridItems : MonoBehaviour
{
    public List<GridItem> items;
    public event Action<string> Clicked;
    private void Awake()
    {
        items = new List<GridItem>();
        for (int i = 0; i < transform.childCount; i++)
        {
            var item = new GridItem(transform.GetChild(i).gameObject, "");
            item.SetActive(false);
            items.Add(item);
        }
    }
    public void AddItem(string txt)
    {
        foreach (var item in items)
        {
            if (!item.Enabled)
            {
                item.SetActive(true);
                item.text = txt;
                item.Text.text = txt;
                item.Button.onClick.AddListener(() => OnClicked(txt));
                break;
            }
        }
    }
    public void RemoveItem(string txt)
    {
        foreach (var item in items)
        {
            if (item.text == txt)
            {
                item.Button.onClick.RemoveAllListeners();
                item.SetActive(false);
            }
        }
    }
    public void OnClicked(string txt)
    {
        Clicked?.Invoke(txt);
    }

}
public class GridItem
{
    public GameObject gameObject;
    public Button Button;
    public string text;
    public Text Text;
    public bool Enabled { get; private set; }
    public GridItem(GameObject gameObject, string text)
    {
        this.gameObject = gameObject;
        Button = gameObject.GetComponent<Button>();
        Text = gameObject.GetComponent<Text>();
        this.text = text;
        Text.text = text;
    }
    public void SetActive(bool active)
    {
        Enabled = active;
        gameObject.SetActive(active);
    }
}