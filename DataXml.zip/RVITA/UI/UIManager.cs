﻿using UnityUtils;
using UnityEngine;
namespace RVITA
{
    public class UIManager : MonoSingleton<UIManager>
    {
        [SerializeField]
        UIElecGtr UIDevice;
        public static void Close()
        {
            Instance.UIDevice.Close();
        }
        public static T GetUI<T>() where T : class
        {
            if (Instance.UIDevice is T)
            {
                return Instance.UIDevice as T;
            }
            return null;
        }
        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Close();
            }
        }
    }
}
