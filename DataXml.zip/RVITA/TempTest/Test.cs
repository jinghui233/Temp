﻿using ECFramework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RVITA
{
    public class Test
    {
        public static void Test1()
        {
            XmlHelper.InitTypes();
            XmlHelper.InitXmlSerializer();
            XmlHelper.Load(Path.Combine(@"E:\users\SuD02\source\repos\WindowsFormsApp1\ConsoleApp1\RVITA\DataXml", "test-character.xml"));
            foreach (string item in XmlHelper.XmlPool.Keys)
            {
                EntityAssembler.Create(item);
            }
            ETCharacter character = EntityAssembler.Spawn<ETCharacter>("SimplePlayer");
        }
        public static void Test2()
        {

        }
    }
}
