﻿using ECFramework;
using System.Collections.Generic;
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class BuildHelper
    {
        public static bool BuildingOverLap(ETPart part)
        {
            Collider2D[] collider2Ds1 = Physics2D.OverlapBoxAll(part.GameObject.GetComponent<BoxCollider2D>().bounds.center, part.CPSpriteRenderer.SizeScale / 2, part.GameObject.transform.rotation.eulerAngles.z, LayerEnum.Building.Mask());
            foreach (var item in collider2Ds1)
            {
                if (item.gameObject.GetInstanceID() != part.GameObject.GetInstanceID())
                {
                    return true;
                }
            }
            return false;
        }
        public static List<ETPart> Connected(ETPart part)
        {
            List<ETPart> result = Surrounded(part);
            for (int i = result.Count - 1; i >= 0; i--)
            {
                List<ETPart> temp = Surrounded(result[i]);
                if (!temp.Contains(part))
                {
                    result.RemoveAt(i);
                }
            }
            return result;
        }
        public static List<ETPart> Surrounded(ETPart part)
        {
            List<ETPart> result = new List<ETPart>();
            foreach (Vector4 connInBuilding in CalcRects(part))
            {
                Collider2D[] collider2Ds = Physics2D.OverlapBoxAll(new Vector2(connInBuilding.x, connInBuilding.y), new Vector2(connInBuilding.z, connInBuilding.w) / 2, part.Transform.rotation.eulerAngles.z, LayerEnum.Building.Mask());
                foreach (var collider in collider2Ds)//遍历要建造的物体所有连接区域
                {
                    if (collider.gameObject.TryGetEntity(out ETPart connected))
                    {
                        result.Add(connected);
                    }
                }
            }
            return result;
        }
        public static Vector4[] CalcRects(ETPart part, float rectThickness = 0.1f, float rectInset = 0.02f)
        {
            Vector4[] vector4s = new Vector4[part.ConnAreaDef.Length];
            for (int i = 0; i < part.ConnAreaDef.Length; i++)
            {
                if (part.ConnAreaDef[i] == 'L')
                    vector4s[i] = CalcRectL(part, rectThickness, rectInset);
                if (part.ConnAreaDef[i] == 'R')
                    vector4s[i] = CalcRectR(part, rectThickness, rectInset);
                if (part.ConnAreaDef[i] == 'T')
                    vector4s[i] = CalcRectT(part, rectThickness, rectInset);
                if (part.ConnAreaDef[i] == 'D')
                    vector4s[i] = CalcRectD(part, rectThickness, rectInset);
            }
            return vector4s;
        }
        public static Vector4 CalcRectL(ETPart part, float rectThickness = 0.1f, float rectInset = 0.02f)
        {
            CPSpriteRenderer cPSpriteRenderer = part.GetComp<CPSpriteRenderer>();
            return CalcRectL(cPSpriteRenderer.SizeNoScale, cPSpriteRenderer.Pivot, part.Transform.position, part.GameObject.transform.rotation.eulerAngles.z, rectThickness, rectInset);
        }
        public static Vector4 CalcRectR(ETPart part, float rectThickness = 0.1f, float rectInset = 0.02f)
        {
            CPSpriteRenderer cPSpriteRenderer = part.GetComp<CPSpriteRenderer>();
            return CalcRectR(cPSpriteRenderer.SizeNoScale, cPSpriteRenderer.Pivot, part.Transform.position, part.GameObject.transform.rotation.eulerAngles.z, rectThickness, rectInset);
        }
        public static Vector4 CalcRectT(ETPart part, float rectThickness = 0.1f, float rectInset = 0.02f)
        {
            CPSpriteRenderer cPSpriteRenderer = part.GetComp<CPSpriteRenderer>();
            return CalcRectT(cPSpriteRenderer.SizeNoScale, cPSpriteRenderer.Pivot, part.Transform.position, part.GameObject.transform.rotation.eulerAngles.z, rectThickness, rectInset);
        }
        public static Vector4 CalcRectD(ETPart part, float rectThickness = 0.1f, float rectInset = 0.02f)
        {
            CPSpriteRenderer cPSpriteRenderer = part.GetComp<CPSpriteRenderer>();
            return CalcRectD(cPSpriteRenderer.SizeNoScale, cPSpriteRenderer.Pivot, part.Transform.position, part.GameObject.transform.rotation.eulerAngles.z, rectThickness, rectInset);
        }
        public static Vector4 CalcRectL(Vector2 blockSize, Vector2 blockPivot, Vector2 blockPosition, float angle, float rectThickness = 0.1f, float rectInset = 0.02f)
        {
            rectInset = (rectInset < rectThickness / 1.5f) ? rectInset : rectThickness / 1.5f;
            float width = rectThickness - rectInset;
            float height = blockSize.y - rectInset;
            Vector2 blockLD = new Vector2(blockPosition.x - blockPivot.x * blockSize.x, blockPosition.y - blockPivot.y * blockSize.y);//左下角世界坐标
            Vector2 center = blockLD;
            center.y += blockSize.y / 2;
            center.x -= rectThickness / 2;
            center = AG.RotatePointAroundPivot(center, blockPosition, angle);
            return new Vector4(center.x, center.y, width, height);
        }
        public static Vector4 CalcRectR(Vector2 blockSize, Vector2 blockPivot, Vector2 blockPosition, float angle, float rectThickness = 0.1f, float rectInset = 0.02f)
        {
            rectInset = (rectInset < rectThickness / 1.5f) ? rectInset : rectThickness / 1.5f;
            float width = rectThickness - rectInset;
            float height = blockSize.y - rectInset;
            Vector2 blockLD = new Vector2(blockPosition.x - blockPivot.x * blockSize.x, blockPosition.y - blockPivot.y * blockSize.y);//左下角世界坐标
            Vector2 center = blockLD;
            center.x += blockSize.x + rectThickness / 2;
            center.y += blockSize.y / 2;
            center = AG.RotatePointAroundPivot(center, blockPosition, angle);
            return new Vector4(center.x, center.y, width, height);
        }
        public static Vector4 CalcRectT(Vector2 blockSize, Vector2 blockPivot, Vector2 blockPosition, float angle, float rectThickness = 0.1f, float rectInset = 0.02f)
        {
            rectInset = (rectInset < rectThickness / 1.5f) ? rectInset : rectThickness / 1.5f;
            float width = blockSize.x - rectInset;
            float height = rectThickness - rectInset;
            Vector2 blockLD = new Vector2(blockPosition.x - blockPivot.x * blockSize.x, blockPosition.y - blockPivot.y * blockSize.y);//左下角世界坐标
            Vector2 center = blockLD;
            center.x += blockSize.x / 2;
            center.y += blockSize.y + rectThickness / 2;
            center = AG.RotatePointAroundPivot(center, blockPosition, angle);
            return new Vector4(center.x, center.y, width, height);
        }
        public static Vector4 CalcRectD(Vector2 blockSize, Vector2 blockPivot, Vector2 blockPosition, float angle, float rectThickness = 0.1f, float rectInset = 0.02f)
        {
            rectInset = (rectInset < rectThickness / 1.5f) ? rectInset : rectThickness / 1.5f;
            float width = blockSize.x - rectInset;
            float height = rectThickness - rectInset;
            Vector2 blockLD = new Vector2(blockPosition.x - blockPivot.x * blockSize.x, blockPosition.y - blockPivot.y * blockSize.y);//左下角世界坐标
            Vector2 center = blockLD;
            center.x += blockSize.x / 2;
            center.y -= rectThickness / 2;
            center = AG.RotatePointAroundPivot(center, blockPosition, angle);
            return new Vector4(center.x, center.y, width, height);
        }
    }
}
