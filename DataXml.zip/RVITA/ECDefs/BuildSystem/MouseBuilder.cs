﻿using UnityEngine;
using UnityUtils;
using ECFramework;
using System.Collections.Generic;

namespace RVITA
{
    public class MouseBuilder : MonoSingleton<MouseBuilder>
    {
        ETPart buildingPart;
        public ETRV rV;
        public float rotate;
        private void Update()
        {
            if (buildingPart != null)
            {
                if (FollowMouse(buildingPart))
                {
                    CanBuild(buildingPart);
                }
                if (canbuild && Input.GetMouseButtonDown(0))
                {
                    rV.AddBuildable(buildingPart, conns);
                    buildingPart.DisableGhosting();
                    buildingPart = null;
                }
            }
            if (Input.GetKeyDown(KeyCode.R))
                rotate += 90;
            if (Input.GetKeyDown(KeyCode.X))
            {
                RaycastHit2D raycastHit2D = Physics2D.Raycast(CoordAndScreen.MousePosition(), Vector2.zero);
                if (raycastHit2D.collider != null)
                {
                    if (raycastHit2D.collider.gameObject.TryGetEntity(out ETPart part))
                    {
                        part.RV.RemoveBuildable(part);
                        EntityAssembler.UnSpawn(part);
                    }
                }
            }
        }
        public void SetInBuilding(ETPart part)
        {
            this.buildingPart = part;
            gameObject.transform.SetParent(rV.Transform);
            if (part.TryGetComp(out CPDevice cPDevice))
            {
                cPDevice.Closed = true;
            }
            part.EnableGhosting();
        }
        public float CoordTransfer(float pivot, float size, float coord, float step)
        {
            float left = coord - pivot * size;
            int times = (int)(left / step);
            float leftcoord1 = step * times;
            float leftcoord2 = step * (times + 1);
            if (Mathf.Abs(left - leftcoord1) < Mathf.Abs(left - leftcoord2))
            {
                return leftcoord1 + pivot * size;
            }
            else
            {
                return leftcoord2 + pivot * size;
            }
        }
        private Vector2 preCoord;
        private float preRotate;
        public bool FollowMouse(ETPart part)
        {
            Vector2 coord = CoordAndScreen.MousePosition();
            coord = rV.Transform.InverseTransformPoint(coord);
            coord.x = CoordTransfer(part.CPSpriteRenderer.Pivot.x, part.CPSpriteRenderer.SizeScale.x, coord.x, 0.1f);
            coord.y = CoordTransfer(part.CPSpriteRenderer.Pivot.y, part.CPSpriteRenderer.SizeScale.y, coord.y, 0.1f);
            if (preCoord != coord || preRotate != rotate)
            {
                transform.localPosition = coord;
                transform.localRotation = Quaternion.Euler(0, 0, rotate);
                part.GameObject.transform.position = transform.position;
                part.GameObject.transform.rotation = transform.rotation;
                return true;
            }
            return false;
        }
        private void OnDrawGizmos()
        {
            if (canbuild && buildingPart != null)
            {
                foreach (ETPart item in conns)
                {
                    Gizmos.DrawLine(buildingPart.Transform.position, item.Transform.position);
                }
            }
        }
        private bool canbuild = false;
        List<ETPart> conns;
        private bool CanBuild(ETPart buildingPart)
        {
            canbuild = false;
            conns = BuildHelper.Connected(buildingPart);
            canbuild = conns.Count > 0 && !BuildHelper.BuildingOverLap(buildingPart);
            if (canbuild)
            {
                //视觉展示
            }
            else
            {
                //视觉展示
            }
            return canbuild;
        }
    }
}
