﻿using ECFramework;
using System.Xml.Serialization;
using UnityEngine;

namespace RVITA
{
    public class CPSpriteRenderer : CPVanilla<SpriteRenderer>
    {
        public string GraphicsPath { get; set; }
        public string MaterialPath { get; set; }
        public Vector2 Pivot { get; set; } = new Vector2(0.5f, 0.5f);
        [XmlIgnore]
        public Material material;
        public Vector3 SizeScale
        {
            get
            {
                return UnityComp == null ? Vector3.zero : Vector3.Scale(UnityComp.sprite.bounds.size, Transform.localScale);
            }
        }
        public Vector3 SizeNoScale
        {
            get
            {
                return UnityComp == null ? Vector3.zero : UnityComp.sprite.bounds.size;
            }
        }
        private void Recreate()
        {
            Texture2D Picture = ResorceHelper.LoadResorce<Texture2D>(GraphicsPath);
            UnityComp.sprite = Sprite.Create(Picture, new Rect(0, 0, Picture.width, Picture.height), Pivot);
            if (!string.IsNullOrWhiteSpace(MaterialPath))
            {
                material = ResorceHelper.LoadResorce<Material>(MaterialPath);
                UnityComp.material = material;
            }
        }
        public override void InitUnityComponent()
        {
            base.InitUnityComponent();
            Recreate();
        }
    }
}
