﻿using ECFramework;
using UnityEngine;

namespace RVITA
{
    public class CPRigidbody2D : CPVanilla<Rigidbody2D>
    {
    }
}
