﻿using ECFramework;
using UnityEngine;

namespace RVITA
{
    public class CPSliderJoint2D : CPVanilla<SliderJoint2D>
    {
        public float Angle { get; set; }
    }
}
