﻿using ECFramework;
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class CPMove : UpdatedComp
    {
        public float MaxSpeed { get; set; } // 最大速度
        enum State { Default, Moving, Targeting, ExistMoving }
        private Rigidbody2D rb; // 刚体组件
        private float target;
        State state;
        public override void SetReferences()
        {
            base.SetReferences();
            rb = GameObject.GetComponent<Rigidbody2D>();
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            state = State.Default;
        }
        public void Jump(float value = 8)
        {
            rb.velocity = new Vector2(rb.velocity.x, value);
        }
        public void MoveTo(float target)
        {
            this.target = target;
            state = State.Targeting;
        }
        public void MoveTo(Vector3 target)
        {
            this.target = target.x;
            state = State.Targeting;
        }
        public void ApproachTo(Vector3 target, float distance)
        {
            target.y = GameObject.transform.position.y;
            Vector3 vector = GameObject.transform.position - target;
            this.target = (vector.normalized * distance + target).x;
            state = State.Targeting;
        }
        public void Move(float value)
        {
            state = State.Moving;
            Vector2 speed = rb.velocity;
            if (value > 0)
            {
                speed.x = MaxSpeed;
            }
            else if (value < 0)
            {
                speed.x = -MaxSpeed;
            }
            rb.velocity = speed;
        }
        public override void Update()
        {
            if (state == State.Default)
            {
                return;
            }
            else if (state == State.Targeting)
            {
                HandelToTarget();
            }
            else if (state == State.Moving)
            {
                state = State.ExistMoving;
            }
            else if (state == State.ExistMoving)
            {
                state = State.Default;
                rb.velocity = new Vector2(0, rb.velocity.y);
            }
        }
        float preCoord;
        private void HandelToTarget()
        {
            Vector2 speed = rb.velocity;
            if (target > GameObject.transform.position.x)
            {
                speed.x = MaxSpeed;
            }
            else if (target < GameObject.transform.position.x)
            {
                speed.x = -MaxSpeed;
            }
            if (Mathf.Abs(target - GameObject.transform.position.x) < 0.1f || (target - preCoord) * (target - GameObject.transform.position.x) < 0)
            {//接近目标或错过目标
                state = State.Default;
                speed.x = 0;
            }
            preCoord = GameObject.transform.position.x;
            rb.velocity = speed;
        }
    }
}
