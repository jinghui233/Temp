﻿using ECFramework;

namespace RVITA
{
    public class ETNormal : UpdatedEntity
    {
    }
}
