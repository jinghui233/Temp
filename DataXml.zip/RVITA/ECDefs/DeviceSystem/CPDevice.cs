﻿using ECFramework;
using System.Xml.Serialization;
using UnityEngine;

namespace RVITA
{
    public enum DeviceState
    {
        Idle,
        Running,
        Close,
    }
    public class CPDevice : UpdatedComp
    {
        public ProdSys prodSys;
        public CPElecSys ElecSys { get; set; }
        public float ElecUse { get; set; }
        public float ElecGen { get; set; }
        [XmlIgnore]
        public DeviceState State { get; private set; }
        private DeviceState BeforeClosing;
        public void ChangeState(DeviceState state)
        {
            if (state == DeviceState.Close)
            {
                BeforeClosing = State;
            }
            if (State == DeviceState.Close)
            {
                state = BeforeClosing;
            }
            State = state;
        }
        public bool Closed { get => State == DeviceState.Close; set { if (value) ChangeState(DeviceState.Close); else ChangeState(DeviceState.Idle); } }
        public override void InitUnityComponent()
        {
            base.InitUnityComponent();
            GameObject.AddComponent<MonoDevice>();
        }
        public override void SetReferences()
        {
            base.SetReferences();
            MonoDevice monoDevice = GameObject.GetComponent<MonoDevice>();
            monoDevice.MouseEnter += OnMouseEnter;
            monoDevice.MouseExit += OnMouseExit;
        }
        public virtual void OnMouseEnter()
        {
            Debug.Log("OnMouseEnter");
        }
        public virtual void OnMouseExit()
        {
            Debug.Log("OnMouseExit");
        }
    }
}
