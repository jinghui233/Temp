﻿using ECFramework;
using System.Xml.Serialization;

namespace RVITA
{
    public class CPElecSys : UpdatedComp
    {
        public string info;
        [XmlIgnore]
        public float ElecUse_w { get; private set; }
        [XmlIgnore]
        public float ElecGen_w { get; private set; }
        [XmlIgnore]
        public float PoolUse_w { get; private set; }
        [XmlIgnore]
        public float PoolGen_w { get; private set; }
        public float UseElec(float Use)
        {
            ElecUse_w += Use;
            if (Use > ElecSupply_w)
            {
                Use = ElecSupply_w;
                ElecSupply_w = 0;
            }
            else
            {
                ElecSupply_w -= Use;
            }
            return Use;
        }
        public float GenElec(float Gen)
        {
            ElecGen_w += Gen;
            if (Gen > ElecQuota_w)
            {
                Gen = ElecQuota_w;
                ElecQuota_w = 0;
            }
            else
            {
                ElecQuota_w -= Gen;
            }
            return Gen;
        }
        public float PoolUseElec(float Use)
        {
            PoolUse_w += Use;
            if (Use > PoolUseCur_w)
            {
                Use = PoolUseCur_w;
                PoolUseCur_w = 0;
            }
            else
            {
                PoolGenCur_w -= Use;
            }
            return Use;
        }
        public float PoolGenElec(float Gen)
        {
            PoolGen_w += Gen;
            if (Gen > PoolGenCur_w)
            {
                Gen = PoolGenCur_w;
                PoolGenCur_w = 0;
            }
            else
            {
                PoolGenCur_w -= Gen;
            }
            return Gen;
        }
        [XmlIgnore]
        public float ElecSupply_w { get; private set; }
        [XmlIgnore]
        public float ElecQuota_w { get; private set; }
        [XmlIgnore]
        public float PoolUseCur_w { get; private set; }
        [XmlIgnore]
        public float PoolGenCur_w { get; private set; }
        public void EleCalc()
        {
            float Elec = ElecGen_w - ElecUse_w;
            if (Elec < -PoolGen_w)
            {
                ElecSupply_w = ElecGen_w + PoolGen_w;
                ElecQuota_w = ElecGen_w;
                PoolGenCur_w = PoolGen_w;
                PoolUseCur_w = 0;
            }
            else if (-PoolGen_w <= Elec && Elec <= 0)
            {
                ElecSupply_w = ElecUse_w;
                ElecQuota_w = ElecGen_w;
                PoolGenCur_w = -Elec;
                PoolUseCur_w = 0;
            }
            else if (0 <= Elec && Elec <= PoolUse_w)
            {
                ElecSupply_w = ElecUse_w;
                ElecQuota_w = ElecGen_w;
                PoolGenCur_w = 0;
                PoolUseCur_w = Elec;
            }
            else if (PoolUse_w < Elec)
            {
                ElecSupply_w = ElecUse_w;
                ElecQuota_w = ElecUse_w + PoolUse_w;
                PoolGenCur_w = 0;
                PoolUseCur_w = PoolUse_w;
            }
            ElecGen_w = 0;
            ElecUse_w = 0;
            PoolGen_w = 0;
            PoolUse_w = 0;
        }
        public override void Update()
        {
            base.Update();
            EleCalc();
            InfoCalc();
        }

        private void InfoCalc()
        {
            info = $"ElecSupply:{ElecSupply_w}\nElecQuota:{ElecQuota_w}\nPoolUseCur:{PoolUseCur_w}\nPoolGenCur:{PoolGenCur_w}";
        }
    }
}
