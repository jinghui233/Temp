﻿using ECFramework;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using UnityEngine;

namespace RVITA
{
    public class ETRV : UpdatedEntity
    {
        [XmlIgnore]
        public CPElecSys ElecSys { get; private set; }
        [XmlIgnore]
        public ProdSys ProdSys { get; private set; }
        [XmlIgnore]
        public List<ETPart> Parts { get; set; }
        [XmlIgnore]
        public RVDrive RVDrive { get; private set; }
        private PartConnectivity blockConnectivity;
        public override void OnDrawGizmos()
        {
            base.OnDrawGizmos();
            if (Application.isPlaying)
            {
                Gizmos.color = Color.red;
                Gizmos.DrawSphere(GameObject.GetComponent<Rigidbody2D>().centerOfMass + new Vector2(Transform.position.x, Transform.position.y), 0.04f);
                Gizmos.color = Color.white;
            }
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            DrawGizmos = true;
            ElecSys = GetComp<CPElecSys>();
            ProdSys = new ProdSys();
            Parts = new List<ETPart>();
            blockConnectivity = new PartConnectivity();
            RVDrive = new RVDrive();
        }
        public static ETRV New(PartConnectivity blockConnectivity)
        {
            ETRV rv = EntityAssembler.Spawn<ETRV>("RV");
            rv.blockConnectivity = blockConnectivity;
            foreach (var item in blockConnectivity.Parts)
            {
                rv.AddBuildable(item, null);
            }
            return rv;
        }
        public void AddBuildable(ETPart eTBuildable, List<ETPart> conns)
        {
            Parts.Add(eTBuildable);
            blockConnectivity.AddBlock(eTBuildable);
            blockConnectivity.AddConns(eTBuildable, conns);
            eTBuildable.GameObject.transform.SetParent(Transform);
            if (eTBuildable.TryGetComp(out CPDevice cPDevice))
            {
                cPDevice.ElecSys = ElecSys;
                cPDevice.prodSys = ProdSys;
                cPDevice.Closed = false;
            }
            if (eTBuildable.TryGetComp(out CPProducter cPProducter))
            {
                cPProducter.Circulation = true;
                cPProducter.AddOrder(new Recipe() { ProdIn = new Product[] { new Product() { Count = 2, Name = "wood" } }, Prodout = new Product[] { new Product() { Count = 1, Name = "coal" } }, TimeUse = 3 });
            }
            if (eTBuildable is ETWheel)
            {
                RVDrive.AddWheel(eTBuildable as ETWheel);
            }
            eTBuildable.OnBuiltTo(this);
        }
        public List<ETRV> RemoveBuildable(ETPart eTBuildable)
        {
            Parts.Remove(eTBuildable);
            blockConnectivity.RemoveBlock(eTBuildable);
            return blockConnectivity.SplitNew(Parts.First());
        }
    }
}
