﻿using ECFramework;
using System.Collections.Generic;
using UnityUtils;

namespace RVITA
{
    public class PartConnectivity
    {
        public IEnumerable<ETPart> Parts { get { return qg.Vertices; } }
        private QG<ETPart> qg;
        public PartConnectivity()
        {
            qg = new QG<ETPart>();
        }
        public PartConnectivity(QG<ETPart> qGBlocks)
        {
            qg = qGBlocks;
        }
        public void AddBlock(ETPart part)
        {
            qg.AddVertex(part);
        }
        public void RemoveBlock(ETPart part)
        {
            qg.RemoveVertex(part);
        }
        public void AddConn(ETPart part, ETPart conn)
        {
            qg.AddEdge(part, conn);
        }
        public void AddConns(ETPart part, List<ETPart> conns)
        {
            if (conns != null)
            {
                foreach (ETPart e in conns)
                {
                    AddConn(part, e);
                }
            }
        }
        public List<ETRV> SplitNew(ETPart part)
        {
            List<ETRV> eTRVs = new List<ETRV>();
            List<QG<ETPart>> qgs = qg.SplitNew(part);
            foreach (var item in qgs)
            {
                eTRVs.Add(ETRV.New(new PartConnectivity(item)));
            }
            return eTRVs;
        }
        public void RecalcConns()
        {
            qg.ClearEdges();
            foreach (var item in Parts)
            {
                var conns = BuildHelper.Connected(item);
                AddConns(item, conns);
            }
        }
    }
}
