﻿using System;
using UnityEngine;

namespace RVITA
{
    public class MonoMeleeWeapon : MonoBehaviour
    {
        public event Action<Collider2D> TriggerEnter2D;
        public event Action ChopFinish;
        private void OnTriggerEnter2D(Collider2D collision)
        {
            TriggerEnter2D?.Invoke(collision);
        }

        private void OnChopFinish(int _)
        {
            ChopFinish?.Invoke();
        }
    }
}
