﻿using UnityEngine;

namespace RVITA
{
    public class ETWheel : ETPart//TODO:优化，轮子使用到的刚体组件是否可以修改类型优化计算
    {
        ETNormal wheelAxle;
        ETNormal wheelTire;
        SpringJoint2D wheelAxle_SpringJoint2D;
        SliderJoint2D wheelAxle_SliderJoint2D;
        WheelJoint2D wheelTire_WheelJoint2D;
        FixedJoint2D FixedJoint2D;
        public float SuspensionHeight { get; set; }
        public float SuspensionAngle { get; set; }
        public override void SetReferences()
        {
            base.SetReferences();
            FixedJoint2D = GameObject.GetComponent<FixedJoint2D>();
            FixedJoint2D.autoConfigureConnectedAnchor = false;
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            foreach (var item in SubEntities)
            {
                if (item != null)
                {
                    if (item.DefName.ToLower().Contains("axle"))
                    {
                        wheelAxle = item as ETNormal;
                    }
                    else
                    {
                        wheelTire = item as ETNormal;
                    }
                }
            }
            wheelAxle_SpringJoint2D = wheelAxle.GameObject.GetComponent<SpringJoint2D>();
            wheelAxle_SliderJoint2D = wheelAxle.GameObject.GetComponent<SliderJoint2D>();
            wheelTire_WheelJoint2D = wheelTire.GameObject.GetComponent<WheelJoint2D>();

            wheelAxle_SpringJoint2D.connectedBody = GameObject.GetComponent<Rigidbody2D>();
            wheelAxle_SliderJoint2D.connectedBody = GameObject.GetComponent<Rigidbody2D>();
            wheelTire_WheelJoint2D.connectedBody = wheelAxle.GameObject.GetComponent<Rigidbody2D>();

            wheelAxle_SliderJoint2D.autoConfigureAngle = false;
            wheelAxle_SliderJoint2D.angle = SuspensionAngle;

            wheelAxle_SpringJoint2D.autoConfigureDistance = false;
            wheelAxle_SpringJoint2D.distance = SuspensionHeight;
        }
        public override void OnBuiltTo(ETRV rV)
        {
            base.OnBuiltTo(rV);
            FixedJoint2D.connectedBody = rV.GameObject.GetComponent<Rigidbody2D>();
            FixedJoint2D.connectedAnchor = Transform.localPosition;
        }
        public void Park()
        {
            SetMotore(0);
        }
        public void UnPark()
        {
            wheelTire_WheelJoint2D.useMotor = false;
        }
        public void SetMotore(float val)
        {
            wheelTire_WheelJoint2D.useMotor = true;
            var motor = wheelTire_WheelJoint2D.motor;
            motor.motorSpeed = val;
            wheelTire_WheelJoint2D.motor = motor;
        }
    }
}
