﻿using UnityEngine;
using UnityUtils;
using ECFramework;
using System.Collections.Generic;
using System.Collections;

namespace RVITA
{
    //TODO:1.放置发电机或组装机时覆盖了普通方块也能建造
    //TODO:建造物类型：1.结构块、2.墙体

    //连接逻辑：1.结构块：结构块、墙体
    //连接逻辑：2.墙体：结构块、墙体

    //碰撞逻辑：1.结构块：结构块
    //碰撞逻辑：2.墙体：墙体
    public class MouseBuilder : MonoSingleton<MouseBuilder>
    {
        ETPart buildingPart;
        private ETRV rv;
        public float rotate;
        public bool hasMoved;
        private void Update()
        {//键鼠指令处理放在Update方法中，FixedUpdate有可能错过指令帧
            if (buildingPart != null && canbuild && Input.GetMouseButtonDown(0))
            {
                rv.AddBuildable(buildingPart, conns);
                //buildingPart.DisableGhosting();
                ETPart newBuildingPart = EntityAssembler.Spawn<ETPart>(buildingPart.DefName);
                buildingPart = null;
                SetInBuilding(newBuildingPart);
            }
            float scrollWheel = Input.GetAxis("Mouse ScrollWheel");
            if (scrollWheel > 0)
            {
                rotate += 90;
            }
            else if (scrollWheel < 0)
            {
                rotate -= 90;
            }
            if (Input.GetKey(KeyCode.LeftControl))
            {
                Debug.Log(BuildHelper.BuildingOverLap(buildingPart));
            }
        }
        private void FixedUpdate()
        {//移动操作放在FixedUpdate中节省性能
            if (Input.GetMouseButtonUp(1) && buildingPart != null)
            {
                EntityAssembler.UnSpawn(buildingPart);
                buildingPart = null;
            }
            if (buildingPart != null)
            {
                if (hasMoved)
                {//判断上一次是否进行了移动，也就是说，总是在移动后的下一次判断CanBuild保证物体确实已经进行了移动，避免出现物体虽移动了但物理系统还未更新。
                    CanBuild(buildingPart);
                }
                hasMoved = FollowMouse(buildingPart);
            }
        }
        public void SetInBuilding(ETPart part)
        {
            if (buildingPart != null)
            {
                EntityAssembler.UnSpawn(buildingPart);
            }
            buildingPart = part;
            if (rv != null)
            {
                gameObject.transform.SetParent(rv.Transform);
            }
            if (part.TryGetComp(out CPDevice cPDevice))
            {
                cPDevice.Closed = true;
            }
            part.EnableGhosting();
            preCoord = Vector3.zero;
            hasMoved = FollowMouse(buildingPart);
        }
        public float CoordTransfer(float pivot, float size, float coord, float step)
        {
            float left = coord - pivot * size;
            int times = (int)(left / step);
            float leftcoord1 = step * times;
            float leftcoord2 = step * (times + 1);
            if (Mathf.Abs(left - leftcoord1) < Mathf.Abs(left - leftcoord2))
            {
                return leftcoord1 + pivot * size;
            }
            else
            {
                return leftcoord2 + pivot * size;
            }
        }
        private Vector2 preCoord;
        private float preRotate;
        /// <summary>
        /// 跟随Mouse
        /// </summary>
        /// <param name="part"></param>
        /// <returns>有可能未进行移动</returns>
        private bool FollowMouse(ETPart part)
        {
            Vector2 coord = CoordAndScreen.MousePosition();
            if (rv != null)
            {
                coord = rv.Transform.InverseTransformPoint(coord);
                coord.x = CoordTransfer(part.CPSpriteRenderer.Pivot.x, part.CPSpriteRenderer.WorldSize.x, coord.x, 0.1f);
                coord.y = CoordTransfer(part.CPSpriteRenderer.Pivot.y, part.CPSpriteRenderer.WorldSize.y, coord.y, 0.1f);
                if (preCoord != coord || preRotate != rotate)
                {
                    transform.localPosition = coord;
                    transform.localRotation = Quaternion.Euler(0, 0, rotate);
                    part.GameObject.transform.position = transform.position;
                    part.GameObject.transform.rotation = transform.rotation;
                    preCoord = coord;
                    preRotate = rotate;
                    return true;
                }
            }
            else
            {
                part.GameObject.transform.position = new Vector3(coord.x, coord.y, part.GameObject.transform.position.z);
                return true;
            }
            return false;
        }
        private void OnDrawGizmos()
        {
            if (canbuild && buildingPart != null)
            {
                foreach (ETPart item in conns)
                {
                    Gizmos.DrawLine(buildingPart.Transform.position, item.Transform.position);
                }
            }
        }
        private bool canbuild = false;
        List<ETPart> conns;
        private bool CanBuild(ETPart buildingPart)
        {
            canbuild = false;
            conns = BuildHelper.Connected(buildingPart);
            if (conns.Count > 0)
            {
                if (!ReferenceEquals(rv, conns[0].RV))
                {
                    rv = conns[0].RV;
                    gameObject.transform.SetParent(rv.Transform);
                }
            }
            else
            {
                rv = null;
            }
            canbuild = conns.Count > 0 && !BuildHelper.BuildingOverLap(buildingPart) && rv != null;
            if (canbuild)
            {
                //视觉展示
            }
            else
            {
                //视觉展示
            }
            return canbuild;
        }
    }
}
