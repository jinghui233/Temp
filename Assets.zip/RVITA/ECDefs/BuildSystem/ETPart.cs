﻿using ECFramework;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class ETPart : UpdatedEntity
    {
        [XmlIgnore] public bool BlueprintMod { get; private set; }
        [XmlIgnore] public ETRV RV { get; private set; }
        public string ConnAreaDef { get; set; }//LRTD分别代表上下左右
        [XmlIgnore] public CPSpriteRenderer CPSpriteRenderer { get; private set; }
        public virtual void OnBuiltTo(ETRV rV)
        {
            RV = rV;
        }
        public override void Update()
        {
            if (BlueprintMod)
            {
                return;
            }
            base.Update();
        }
        public override void SetReferences()
        {
            base.SetReferences();
            CPSpriteRenderer = GetComp<CPSpriteRenderer>();
        }
        public virtual void EnableGhosting()
        {
            BlueprintMod = true;
            Joint2D[] joint2Ds = GameObject.GetComponentsInChildren<Joint2D>();
            foreach (Joint2D joint in joint2Ds)
            {
                joint.enabled = false;
            }
            Rigidbody2D[] rigidbody2Ds = GameObject.GetComponentsInChildren<Rigidbody2D>();
            foreach (var item in rigidbody2Ds)
            {
                item.isKinematic = true;
            }
            //Collider2D[] collider2Ds = GameObject.GetComponentsInChildren<Collider2D>();
            //foreach (var item in collider2Ds)
            //{
            //    item.enabled = false;
            //}
        }
        public virtual void DisableGhosting()
        {
            Joint2D[] joint2Ds = GameObject.GetComponentsInChildren<Joint2D>();
            foreach (Joint2D joint in joint2Ds)
            {
                joint.enabled = true;
            }
            Rigidbody2D[] rigidbody2Ds = GameObject.GetComponentsInChildren<Rigidbody2D>();
            foreach (var item in rigidbody2Ds)
            {
                item.isKinematic = false;
            }
            //Collider2D[] collider2Ds = GameObject.GetComponentsInChildren<Collider2D>();
            //foreach (var item in collider2Ds)
            //{
            //    item.enabled = true;
            //}
            BlueprintMod = false;
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            DrawGizmos = true;
            Layerer.SetLayer(GameObject, LayerEnum.Building);//TODO:这个还是要想想办法后续传进来，因为考虑到可能的敌人建造或者多玩家建造
        }
        public override void OnDrawGizmos()
        {
            if (!Application.isPlaying)
            {
                return;
            }
            base.OnDrawGizmos();
            Gizmos.color = Color.yellow;
            BoxCollider2D collider = GameObject.GetComponent<BoxCollider2D>();
            GizmosHelper.DrawRotatedWireRect((Vector2)Transform.position + collider.offset, collider.size.x, collider.size.y, Transform.rotation.eulerAngles.z);
            foreach (var rect in BuildHelper.CalcRects(this))
            {
                GizmosHelper.DrawRotatedWireRect(new Vector2(rect.x, rect.y), rect.z, rect.w, Transform.rotation.eulerAngles.z);
                Gizmos.DrawSphere(new Vector2(rect.x, rect.y), 0.02f);
            }
            Gizmos.color = Color.white;
        }
    }
}
