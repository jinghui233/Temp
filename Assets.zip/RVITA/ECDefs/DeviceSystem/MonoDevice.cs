﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace RVITA
{
    public class MonoDevice : MonoBehaviour
    {
        public event Action MouseEnter;
        public event Action MouseExit;
        private void OnMouseEnter()
        {
            MouseEnter?.Invoke();
        }
        private void OnMouseExit()
        {
            MouseExit?.Invoke();
        }
    }
}
