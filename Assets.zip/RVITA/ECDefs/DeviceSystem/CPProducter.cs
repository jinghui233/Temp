﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using UnityEngine;

namespace RVITA
{
    public enum ProducerState
    {
        Finish,
        WaitingProdIn,
        Producting,
        WaitingProdOut,
    }
    public class CPProducter : CPDevice
    {
        [XmlIgnore]
        public ProducerState ProducerState { get; private set; }
        public bool Circulation;
        List<Recipe> Orders = new List<Recipe>();
        List<Product> ProdIn = new List<Product>();
        List<Product> ProdOut = new List<Product>();
        float TimeRemain;
        Recipe curRecipe;
        public float Progress { get => (curRecipe.TimeUse - TimeRemain) / curRecipe.TimeUse; }
        public void AddOrder(Recipe recipe)
        {
            Orders.Add(recipe);
        }
        private bool FeedSupplement()
        {
            bool done = true;
            for (int i = 0; i < ProdIn.Count; i++)
            {
                var item = ProdIn[i];
                if (item.Count > 0)
                {
                    item.Count -= prodSys.StoreOut(item.Name, item.Count);
                    ProdIn[i] = item;
                    done = item.Count > 0 ? false : done;
                }
            }
            return done;
        }
        private bool DeliverProducts()
        {
            bool done = true;
            for (int i = 0; i < ProdOut.Count; i++)
            {
                var item = ProdOut[i];
                if (item.Count > 0)
                {
                    item.Count = prodSys.StoreIn(item.Name, item.Count);
                    ProdOut[i] = item;
                    done = item.Count > 0 ? false : done;
                }
            }
            return done;
        }
        public override void Update()
        {
            if (Closed) return;
            base.Update();
            switch (ProducerState)
            {
                case ProducerState.Finish:
                    if (Orders.Count > 0)
                    {
                        curRecipe = Orders[0];
                        if (!Circulation)
                            Orders.RemoveAt(0);
                        TimeRemain = curRecipe.TimeUse;
                        ProdIn.Clear();
                        ProdOut.Clear();
                        foreach (Product item in curRecipe.ProdIn)
                        {
                            ProdIn.Add(item);
                        }
                        ProducerState = FeedSupplement() ? ProducerState.Producting : ProducerState.WaitingProdIn;
                    }
                    break;
                case ProducerState.WaitingProdIn:
                    ProducerState = FeedSupplement() ? ProducerState.Producting : ProducerState.WaitingProdIn;
                    break;
                case ProducerState.Producting:
                    float elec = ElecSys.UseElec(ElecUse);
                    TimeRemain -= Time.deltaTime * (elec / ElecUse);
                    if (TimeRemain < 0)
                    {
                        TimeRemain = 0;
                        foreach (var item in curRecipe.Prodout)
                        {
                            ProdOut.Add(item);
                        }
                        ProducerState = DeliverProducts() ? ProducerState.Finish : ProducerState.WaitingProdOut;
                    }
                    break;
                case ProducerState.WaitingProdOut:
                    ProducerState = DeliverProducts() ? ProducerState.Finish : ProducerState.WaitingProdOut;
                    break;
                default:
                    break;
            }
        }
    }
}
