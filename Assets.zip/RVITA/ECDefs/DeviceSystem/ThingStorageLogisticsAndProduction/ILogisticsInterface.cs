﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RVITA
{
    public interface ILogisticsInterface
    {
        StorageDomain StorageDomain { get; set; }
        float In(string name, float count);
        float Out(string name, float count);
    }
}
