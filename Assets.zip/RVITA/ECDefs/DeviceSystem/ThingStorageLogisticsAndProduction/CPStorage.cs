﻿using ECFramework;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;

namespace RVITA
{
    public class CPStorage : Comp, ILogisticsInterface
    {
        [XmlIgnore] public StorageDomain StorageDomain { get; set; }
        public List<Item> Items { get; set; } = new List<Item>();
        public override void OnSpawn()
        {
            base.OnSpawn();
        }
        public float ItemCount(string name)
        {
            return Items.FindAll(t => t.Name == name).Sum(t => t.Count);
        }
        public float In(string name, float count)
        {
            foreach (Item item in Items)
            {
                if (item.Name == name)
                {
                    float remain = item.In(count);
                    if (remain == 0)
                    {
                        return 0;
                    }
                    else
                    {
                        count -= remain;
                    }
                }
            }
            while (true)
            {
                Item item = new Item() { Name = name, MaxCount = Item.ItemDic[name].MaxCount };
                Items.Add(item);
                float remain = item.In(count);
                if (remain == 0)
                {
                    return 0;
                }
                else
                {
                    count -= remain;
                }
            }
        }
        public float Out(string name, float count)
        {
            float cache = 0;
            for (int i = Items.Count - 1; i >= 0; i--)
            {
                if (Items[i].Name == name)
                {
                    cache += Items[i].Out(count);
                    if (Items[i].Count == 0)
                    {
                        Items.RemoveAt(i);
                    }
                    if (cache == count)
                    {
                        return cache;
                    }
                }
            }
            return cache;
        }
        public float Empty(string name)
        {
            float cache = 0;
            for (int i = Items.Count - 1; i >= 0; i--)
            {
                if (Items[i].Name == name)
                {
                    cache += Items[i].Empty();
                    Items.RemoveAt(i);
                }
            }
            return cache;
        }
    }
}
