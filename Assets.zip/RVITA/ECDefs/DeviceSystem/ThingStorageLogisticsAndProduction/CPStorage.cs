﻿using ECFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using UnityEngine;

namespace RVITA
{
    public class CPStorage : Comp, ILogisticsInterface
    {
        [XmlIgnore] public StorageDomain StorageDomain { get; set; }
        public List<ThingContainer> Things = new List<ThingContainer>();
        public override void OnSpawn()
        {
            base.OnSpawn();
            Things.Add(new ThingContainer() { Name = "wood", Count = 100 });
            Things.Add(new ThingContainer() { Name = "food", Count = 200 });
        }
        public float ItemCount(string name)
        {
            return Things.FindAll(t => t.Name == name).Sum(t => t.Count);
        }
        public ThingContainer In(ThingContainer thingContainer)
        {
            Things.Add(thingContainer);
            ThingContainer thingContainer1 = thingContainer;
            thingContainer1.Count = 0;
            return thingContainer1;
        }
        public ThingContainer Out(ThingContainer thingContainer)
        {
            for (int i = 0; i < Things.Count; i++)
            {
                if (Things[i] == thingContainer)
                {
                    Things.RemoveAt(i);
                    return thingContainer;
                }
            }
            ThingContainer thingContainer1 = thingContainer;
            thingContainer1.Count = 0;
            return thingContainer1;
        }
        public float In(string name, float count)
        {
            foreach (ThingContainer item in Things)
            {
                if (item.Name == name)
                {
                    float remain = item.In(count);
                    if (remain == 0)
                    {
                        return 0;
                    }
                    else
                    {
                        count -= remain;
                    }
                }
            }
            while (true)
            {
                ThingContainer thingContainer1 = new ThingContainer() { Name = name, MaxCount = ThingInfo.ThingDic[name].MaxCount };
                Things.Add(thingContainer1);
                float remain = thingContainer1.In(count);
                if (remain == 0)
                {
                    return 0;
                }
                else
                {
                    count -= remain;
                }
            }
        }
        public float Out(string name, float count)
        {
            float cache = 0;
            for (int i = Things.Count - 1; i >= 0; i--)
            {
                if (Things[i].Name == name)
                {
                    cache += Things[i].Out(count);
                    if (Things[i].Count == 0)
                    {
                        Things.RemoveAt(i);
                    }
                    if (cache == count)
                    {
                        return cache;
                    }
                }
            }
            return cache;
        }
        public float Empty(string name)
        {
            float cache = 0;
            for (int i = Things.Count - 1; i >= 0; i--)
            {
                if (Things[i].Name == name)
                {
                    cache += Things[i].Empty();
                    Things.RemoveAt(i);
                }
            }
            return cache;
        }
    }
}
