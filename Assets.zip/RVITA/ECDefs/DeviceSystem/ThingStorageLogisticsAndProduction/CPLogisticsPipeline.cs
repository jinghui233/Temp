﻿using ECFramework;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace RVITA
{
    public class CPLogisticsPipeline : UpdatedComp
    {
        [XmlIgnore] public StorageDomain StorageDomain { get; private set; }
        [XmlIgnore] private ETPart part;
        public override void SetReferences()
        {
            base.SetReferences();
            part = Entity as ETPart;
        }

        public override void FixedUpdate()
        {
            base.FixedUpdate();
            //检测与之连接的块合并其储存域
            List<ETPart> parts = part.RV.Connected(part);
            foreach (ETPart item in parts)
            {
                if (item.BlueprintMod)
                {
                    continue;
                }
                if (item.TryGetComp(out CPLogisticsPipeline logisticsPipeline))
                {
                    if (StorageDomain == null && logisticsPipeline.StorageDomain == null)
                    {
                        StorageDomain = new StorageDomain();
                        logisticsPipeline.StorageDomain = StorageDomain;
                    }
                    else if (ReferenceEquals(StorageDomain, logisticsPipeline.StorageDomain))
                    {
                    }
                    else if (StorageDomain == null)
                    {
                        StorageDomain = logisticsPipeline.StorageDomain;
                    }
                    else if (logisticsPipeline.StorageDomain == null)
                    {
                        logisticsPipeline.StorageDomain = StorageDomain;
                    }
                    else
                    {
                        logisticsPipeline.StorageDomain = StorageDomain.Combine(logisticsPipeline.StorageDomain);
                    }
                }
                else if (item.TryGetComp(out ILogisticsInterface storage))
                {
                    if (StorageDomain == null)
                    {
                        StorageDomain = new StorageDomain();
                        StorageDomain.AddStorage(storage);
                    }
                    else if (StorageDomain.Endpoints.Contains(storage))
                    {
                    }
                    else
                    {
                        StorageDomain.AddStorage(storage);
                    }
                }
            }
        }
    }
}
