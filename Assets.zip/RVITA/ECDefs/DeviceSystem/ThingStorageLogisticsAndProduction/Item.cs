﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RVITA
{
    public class Item
    {
        public static Dictionary<string, Item> ItemDic = new Dictionary<string, Item>();
        public string Name;
        public float Weight;
        public float Count;
        public float MaxCount;
        public string TexterPath;
        public float In(float count)
        {
            if (MaxCount > 0 && count + Count >= MaxCount)
            {
                count -= MaxCount - Count;
                Count = MaxCount;
                return count;
            }
            else
            {
                Count += count;
                return 0;
            }
        }
        public float Out(float count)
        {
            if (Count >= count)
            {
                Count -= count;
                return count;
            }
            else
            {
                count = Count;
                Count = 0;
                return count;
            }
        }
        public float Empty()
        {
            float count = Count;
            Count = 0;
            return count;
        }
        public Item SplitHalf()
        {
            Item item = this;
            item.Count = 0;
            int count = (int)Count;
            if (count < 2)
            {
                return item;
            }
            int half = count / 2;
            int remainder = count % 2;
            if (remainder == 1)
            {
                half += 1;
            }
            Count = half;
            item.Count = count - half;
            return item;
        }
    }
}
