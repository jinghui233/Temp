﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RVITA
{
    public struct RecipeItem
    {
        public string Name;
        public float Amount;
    }

    public class Recipe
    {
        public List<RecipeItem> MaterialInfo;
        public List<RecipeItem> ProductInfo;
        public CPStorage Material = new CPStorage();
        public CPStorage Product = new CPStorage();
        /// <summary>
        /// 总工作量
        /// </summary>
        public float WorkTotalQuantity { get; set; }
        /// <summary>
        /// 已完成工作量
        /// </summary>
        public float WorkDoneQuantity { get; set; }
        public float Progress { get => WorkDoneQuantity / WorkTotalQuantity; }
        public bool ProductionDone { get => WorkDoneQuantity >= WorkTotalQuantity; }
        public bool MaterialDone()
        {
            foreach (RecipeItem item in MaterialInfo)
            {
                if (!(Material.ItemCount(item.Name) >= item.Amount))
                {
                    return false;
                }
            }
            return true;
        }
        public void Work(float workQuantity)
        {
            if (MaterialDone())
            {
                WorkDoneQuantity += workQuantity;
                if (ProductionDone)
                {
                    foreach (RecipeItem item in ProductInfo)
                    {
                        Product.In(item.Name, item.Amount);
                    }
                    foreach (RecipeItem item in MaterialInfo)
                    {
                        Material.Out(item.Name, item.Amount);
                    }
                }
            }
        }
        public void Reset()
        {
            WorkDoneQuantity = 0;
        }
    }
}
