﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using UnityEngine;

namespace RVITA
{
    public enum ProducerState
    {
        Finish,
        WaitingProdIn,
        Producting,
        WaitingProdOut,
    }
    public class CPProducter : CPDevice
    {
        [XmlIgnore] public ProducerState ProducerState { get; private set; }
        public bool Circulation;//持续生产
        List<Recipe> Orders = new List<Recipe>();
        [XmlIgnore] public Recipe Recipe;
        public CPStorage Storage;
        public float WorkSpeed { get; set; }
        public override void SetReferences()
        {
            base.SetReferences();
            Storage = Entity.GetComp<CPStorage>();
        }
        public void AddOrder(Recipe recipe)
        {
            Orders.Add(recipe);
        }
        private bool FeedSupplement()
        {
            foreach (RecipeItem item in Recipe.MaterialInfo)
            {
                float materialCount = Recipe.Material.ItemCount(item.Name);
                if (materialCount < item.Amount)
                {
                    Recipe.Material.In(item.Name, Storage.Out(item.Name, item.Amount - materialCount));
                }
            }
            return Recipe.MaterialDone();
        }
        private bool DeliverProducts()
        {
            bool done = true;
            foreach (RecipeItem item in Recipe.ProductInfo)
            {
                float count = Storage.In(item.Name, Recipe.Product.Empty(item.Name));
                if (count > 0)
                {
                    Recipe.Product.In(item.Name, count);
                    done = false;
                }
            }
            return done;
        }
        public override void Update()
        {
            if (Closed) return;
            base.Update();
            switch (ProducerState)
            {
                case ProducerState.Finish:
                    if (Orders.Count > 0)
                    {
                        Recipe = Orders[0];
                        if (!Circulation)
                            Orders.RemoveAt(0);
                        Recipe.Reset();
                        ProducerState = FeedSupplement() ? ProducerState.Producting : ProducerState.WaitingProdIn;
                    }
                    break;
                case ProducerState.WaitingProdIn:
                    ProducerState = FeedSupplement() ? ProducerState.Producting : ProducerState.WaitingProdIn;
                    break;
                case ProducerState.Producting:
                    float elec = ElecSys.UseElec(ElecUse);
                    Recipe.Work(Time.deltaTime * (elec / ElecUse) * WorkSpeed);
                    if (Recipe.ProductionDone)
                    {
                        ProducerState = DeliverProducts() ? ProducerState.Finish : ProducerState.WaitingProdOut;
                    }
                    break;
                case ProducerState.WaitingProdOut:
                    ProducerState = DeliverProducts() ? ProducerState.Finish : ProducerState.WaitingProdOut;
                    break;
                default:
                    break;
            }
        }
    }
}
