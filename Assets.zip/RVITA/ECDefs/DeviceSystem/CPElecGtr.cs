﻿using System.Xml.Serialization;
using UnityEngine;

namespace RVITA
{
    public class CPElecGtr : CPDevice
    {
        public Product Fuel { get => fuel; set => fuel = value; }
        private Product fuel;
        public float TimeUsage { get; set; }
        [XmlIgnore]
        public float TimeRemaining { get; private set; }
        public override void Update()
        {
            if (Closed) return;
            base.Update();
            if (fuel.Count <= 0)
            {
                fuel.Count += prodSys.StoreOut(fuel.Name, 1);
                if (fuel.Count <= 0)
                    return;
            }
            TimeRemaining -= Time.deltaTime * (ElecSys.GenElec(ElecGen) / ElecGen);
            if (TimeRemaining <= 0)
            {
                TimeRemaining = TimeUsage + TimeRemaining;
                fuel.Count -= 1;
                fuel.Count += prodSys.StoreOut(fuel.Name, 1);
            }
        }
    }
}
