﻿using System.Xml.Serialization;
using UnityEngine;

namespace RVITA
{
    public class CPElecGtr : CPDevice
    {
        public CPStorage Storage;
        public ThingContainer Fuel { get => fuel; set => fuel = value; }
        private ThingContainer fuel;
        public float TimeUsage { get; set; }
        [XmlIgnore]
        public float TimeRemaining { get; private set; }
        public override void SetReferences()
        {
            base.SetReferences();
            Storage = Entity.GetComp<CPStorage>();
        }
        public override void Update()
        {
            if (Closed) return;
            base.Update();
            if (fuel.Count <= 0)
            {
                fuel.Count += Storage.Out(fuel.Name, 1);
                if (fuel.Count <= 0)
                    return;
            }
            TimeRemaining -= Time.deltaTime * (ElecSys.GenElec(ElecGen) / ElecGen);
            if (TimeRemaining <= 0)
            {
                TimeRemaining = TimeUsage + TimeRemaining;
                fuel.Count -= 1;
                fuel.Count += Storage.Out(fuel.Name, 1);
            }
        }
    }
}
