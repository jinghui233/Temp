﻿using ECFramework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace RVITA
{
    public class ECDefGenerator
    {
        public static string TargetDir;
        public static void DoGenerate(string path = null)
        {
            XmlHelper.InitTypes();
            XmlHelper.InitXmlSerializer();
            if (!string.IsNullOrWhiteSpace(path))
            {
                TargetDir = path;
            }
            List<Entity> entities = new List<Entity>();
            entities.AddRange(Parts());
            entities.AddRange(RV());
            entities.AddRange(ElecParts());
            XmlHelper.SerializeToFile(entities, Path.Combine(TargetDir, "block-parts.xml"));
            XmlHelper.SerializeToFile(CharacterTest(), Path.Combine(TargetDir, "test-character.xml"));
            List<Item> items = GenItems();
            XmlHelper.SerializeToFile(items, Path.Combine(TargetDir, "items.xml"));
            items = XmlHelper.DeserializeFromFile<List<Item>>(Path.Combine(TargetDir, "items.xml"));

        }
        public static List<Item> GenItems()
        {
            List<Item> items = new List<Item>();
            items.Add(new Item() { Name = "plastics", Weight = 1 });
            items.Add(new Item() { Name = "wood", Weight = 1 });
            items.Add(new Item() { Name = "stone", Weight = 2 });
            items.Add(new Item() { Name = "iron", Weight = 3 });
            items.Add(new Item() { Name = "ElecGtr", Weight = 3 });
            items.Add(new Item() { Name = "Producter", Weight = 3 });
            items.Add(new Item() { Name = "Battery", Weight = 3 });
            items.Add(new Item() { Name = "Chest", Weight = 3 });
            items.Add(new Item() { Name = "LogisticsPipeline", Weight = 3 });
            items.Add(new Item() { Name = "SimplePart", Weight = 3 });
            items.Add(new Item() { Name = "SimplePart2", Weight = 3 });
            items.Add(new Item() { Name = "SimplePart3", Weight = 3 });
            items.Add(new Item() { Name = "RV", Weight = 3 });
            return items;
        }
        private static List<Entity> CharacterTest()
        {
            List<Entity> entities = new List<Entity>();
            ETCharacter character = new ETCharacter();
            entities.Add(character);
            character.DefName = "SimplePlayer";
            character.AddComp(new CPMove() { MaxSpeed = 5 });
            character.AddComp(new CPHealth() { MaxHP = 20 });
            character.AddSubEntity(new Entity() { DefName = "SimpleTurret", LocalPosition = new Vector3(1, 1, 0) });
            ETTurret turret = new ETTurret();
            entities.Add(turret);
            turret.DefName = "SimpleTurret";
            turret.LocalPosition = new Vector3(1, 1, 0);
            turret.Cooldown = 5;
            turret.AttackRange = 10;
            return entities;
        }
        private static List<Entity> ElecParts()
        {
            List<Entity> entities = new List<Entity>();
            ETPart part = new ETPart();
            entities.Add(part);
            part.DefName = "ElecGtr";
            part.ConnAreaDef = "LRTD";
            part.LayerEnum = LayerEnum.RVBlock;
            part.AddComp(new CPSpriteRenderer() { Pivot = new Vector2(0.5f, 0.5f), GraphicsPath = "Assets/GameAssets/Graphics/Test/发电机.png" });
            part.AddComp(new CPBoxCollider2D());
            part.AddComp(new CPElecGtr() { TimeUsage = 2, ElecGen = 80, Fuel = new Item() { Name = "fuel", Count = 1 } });
            part.AddComp(new CPStorage());
            part = new ETPart();
            entities.Add(part);
            part.DefName = "Producter";
            part.ConnAreaDef = "LRTD";
            part.LayerEnum = LayerEnum.RVBlock;
            part.AddComp(new CPSpriteRenderer() { Pivot = new Vector2(0.5f, 0.5f), GraphicsPath = "Assets/GameAssets/Graphics/Test/组装机.png" });
            part.AddComp(new CPBoxCollider2D());
            part.AddComp(new CPProducter() { ElecUse = 10 });
            part.AddComp(new CPStorage());
            part = new ETPart();
            entities.Add(part);
            part.DefName = "Battery";
            part.ConnAreaDef = "LRTD";
            part.LayerEnum = LayerEnum.RVBlock;
            part.AddComp(new CPSpriteRenderer() { Pivot = new Vector2(0.5f, 0.5f), GraphicsPath = "Assets/GameAssets/Graphics/Test/蓄电池.png" });
            part.AddComp(new CPBoxCollider2D());
            part.AddComp(new CPBattery() { ElecUse = 10, ElecGen = 10, ElecStorage = 100000 });
            part = new ETPart();
            entities.Add(part);
            part.DefName = "Chest";
            part.ConnAreaDef = "LRTD";
            part.LayerEnum = LayerEnum.RVBlock;
            part.AddComp(new CPSpriteRenderer() { Pivot = new Vector2(0.5f, 0.5f), GraphicsPath = "Assets/GameAssets/Graphics/Test/箱子.png" });
            part.AddComp(new CPBoxCollider2D());
            part.AddComp(new CPStorage() { Items = new List<Item>() { new Item() { Name = "wood", Weight = 1, Count = 100 }, new Item() { Name = "stone", Weight = 2, Count = 200 } } });
            part = new ETPart();
            entities.Add(part);
            part.DefName = "LogisticsPipeline";
            part.ConnAreaDef = "LRTD";
            part.LayerEnum = LayerEnum.RVBlock;
            part.AddComp(new CPSpriteRenderer() { Pivot = new Vector2(0.5f, 0.5f), GraphicsPath = "Assets/GameAssets/Graphics/Test/物流管道.png" });
            part.AddComp(new CPBoxCollider2D());
            part.AddComp(new CPLogisticsPipeline());
            return entities;
        }
        public static List<Entity> Parts()
        {
            List<Entity> entities = new List<Entity>();
            ETPart part = new ETPart();
            entities.Add(part);
            part.DefName = "SimplePart";
            part.ConnAreaDef = "LRTD";
            part.LayerEnum = LayerEnum.RVBlock;
            part.AddComp(new CPSpriteRenderer() { Pivot = new Vector2(0.5f, 0.5f), GraphicsPath = "Assets/GameAssets/Graphics/Test/1×1普通砖块.png" });
            part.AddComp(new CPBoxCollider2D());
            part = new ETPart();
            entities.Add(part);
            part.DefName = "SimplePart2";
            part.ConnAreaDef = "LRTD";
            part.LayerEnum = LayerEnum.RVBlock;
            part.AddComp(new CPSpriteRenderer() { Pivot = new Vector2(0.5f, 0.5f), GraphicsPath = "Assets/GameAssets/Graphics/Test/2×2普通砖块.png" });
            part.AddComp(new CPBoxCollider2D());
            part = new ETPart();
            entities.Add(part);
            part.DefName = "SimplePart3";
            part.ConnAreaDef = "LRTD";
            part.LayerEnum = LayerEnum.RVBlock;
            part.AddComp(new CPSpriteRenderer() { Pivot = new Vector2(0.5f, 0.5f), GraphicsPath = "Assets/GameAssets/Graphics/Test/3×3普通砖块.png" });
            part.AddComp(new CPBoxCollider2D());
            return entities;
        }
        public static List<Entity> RV()
        {
            List<Entity> entities = new List<Entity>();
            ETRV rv = new ETRV();
            entities.Add(rv);
            rv.DefName = "RV";
            rv.AddComp(new CPRigidbody2D());
            rv.AddComp(new CPElecSys());
            return entities;
        }
    }
}
