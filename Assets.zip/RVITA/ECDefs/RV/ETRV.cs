﻿using ECFramework;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public partial class ETRV : UpdatedEntity
    {
        [XmlIgnore]
        public CPElecSys ElecSys { get; private set; }
        [XmlIgnore]
        public ProdSys ProdSys { get; private set; }
        [XmlIgnore]
        public IEnumerable<ETPart> Parts { get => qg.Vertices; }
        [XmlIgnore]
        public RVDrive RVDrive { get; private set; }
        public override void OnDrawGizmos()
        {
            base.OnDrawGizmos();
            if (Application.isPlaying)
            {
                Gizmos.color = Color.red;
                //Gizmos.DrawSphere(GameObject.GetComponent<Rigidbody2D>().centerOfMass + new Vector2(Transform.position.x, Transform.position.y), 0.04f);
                Gizmos.color = Color.white;
            }
        }
        public override void InitUnityComponent()
        {
            base.InitUnityComponent();
            GetOrCreateGameObject();
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            DrawGizmos = true;
            ElecSys = GetComp<CPElecSys>();
            ProdSys = new ProdSys();
            qg = new QG<ETPart>();
            RVDrive = new RVDrive();
            FromSave();
        }
        public void AddBuildable(ETPart part, List<ETPart> connectedParts)
        {
            qg.AddVertex(part);
            connectedParts?.ForEach(p => qg.AddEdge(part, p));
            part.GameObject.transform.SetParent(Transform);
            AddSubEntity(part);
            ProcessFunctionPart(part);
        }
        public void ProcessFunctionPart(ETPart part)
        {//TODO:判重处理，逻辑完善
            if (part.TryGetComp(out CPDevice device))
            {
                device.ElecSys = ElecSys;
                device.prodSys = ProdSys;
                device.Closed = false;
            }
            if (part.TryGetComp(out CPProducter producter))
            {
                producter.Circulation = true;
                producter.AddOrder(new Recipe() { ProdIn = new Product[] { new Product() { Count = 2, Name = "wood" } }, Prodout = new Product[] { new Product() { Count = 1, Name = "coal" } }, TimeUse = 3 });
            }
            if (part is ETWheel)
            {
                RVDrive.AddWheel(part as ETWheel);
            }
            part.OnBuiltTo(this);
        }
        public List<ETRV> RemoveBuildable(ETPart part)
        {
            qg.RemoveVertex(part);
            RemoveSubEntity(part);
            return SplitNew(Parts.First());
        }
    }
}
