﻿using System.Collections.Generic;

namespace RVITA
{
    public class RVDrive
    {
        public List<ETWheel> wheels = new List<ETWheel>();
        public bool Parked { get; private set; }
        public void AddWheel(ETWheel wheel)
        {
            wheels.Add(wheel);
        }
        public bool Park()
        {
            if (Parked)
            {
                foreach (ETWheel wheel in wheels)
                {
                    wheel.UnPark();
                }
            }
            else
            {
                foreach (ETWheel wheel in wheels)
                {
                    wheel.Park();
                }
            }
            Parked = !Parked;
            return Parked;
        }
        public void SetWheelMotor(float val)
        {
            foreach (ETWheel wheel in wheels)
            {
                wheel.SetMotore(val);
            }
        }
    }
}
