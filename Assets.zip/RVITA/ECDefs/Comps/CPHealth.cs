﻿using ECFramework;
using System;
using System.Xml.Serialization;

namespace RVITA
{
    public class CPHealth : Comp
    {
        public float MaxHP { get; set; }
        public float CurHP { get; set; }
        public event Action<CPHealth> HealthCleared;
        public event Action<CPHealth> Hitting;
        public override void OnSpawn()
        {
            base.OnSpawn();
            CurHP = MaxHP;
        }
        public void TakeDamage(float damage)
        {
            CurHP -= damage;
            UnityEngine.Mathf.Clamp(CurHP, 0f, MaxHP);
            if (CurHP == 0)
            {
                HealthCleared?.Invoke(this);
            }
            Hitting?.Invoke(this);
        }
        public float GetHPBarVal()
        {
            return CurHP / MaxHP;
        }
    }
}
