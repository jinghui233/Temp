﻿using ECFramework;
using UnityEngine;

namespace RVITA
{
    public class CPAnimator : CPVanilla<Animator>
    {
    }
}
