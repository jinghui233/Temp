﻿using ECFramework;
using System.Xml.Serialization;
using UnityEngine;

namespace RVITA
{
    public class CPSpriteRenderer : CPVanilla<SpriteRenderer>
    {
        public string GraphicsPath { get; set; }
        public string MaterialPath { get; set; }
        public Vector2 Pivot { get; set; } = new Vector2(0.5f, 0.5f);
        [XmlIgnore]
        public Material material;
        //TODO:这里是否需要判空
        //public Vector3 WorldSize => UnityComp == null ? Vector3.zero : UnityComp.bounds.size;
        public Vector3 WorldSize => UnityComp == null ? Vector3.zero : Vector3.Scale(UnityComp.sprite.bounds.size, Transform.localScale);
        public Vector3 AbsoluteSize => UnityComp == null ? Vector3.zero : UnityComp.sprite.bounds.size;
        private void Recreate()
        {
            Texture2D picture = ResorceHelper.LoadResorce<Texture2D>(GraphicsPath);
            UnityComp.sprite = Sprite.Create(picture, new Rect(0, 0, picture.width, picture.height), Pivot);
            if (!string.IsNullOrWhiteSpace(MaterialPath))
            {
                material = ResorceHelper.LoadResorce<Material>(MaterialPath);
                UnityComp.material = material;
            }
        }
        public override void InitUnityComponent()
        {
            base.InitUnityComponent();
            Recreate();
        }
    }
}
