﻿using ECFramework;
using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class CPKeyMove : UpdatedComp
    {
        public bool Disabled;
        CPMove cPMove;
        public override void SetReferences()
        {
            base.SetReferences();
            cPMove = Entity.GetComp<CPMove>();
        }
        public override void Update()
        {
            if (Disabled)
                return;
            float Horizontal = Input.GetAxis("Horizontal");
            if (Horizontal != 0)
            {
                cPMove.Move(Horizontal);
            }
            if (Input.GetAxis("Jump") != 0)
            {
                cPMove.Jump(8);
            }
            //if (Input.GetMouseButtonDown(1))
            //{
            //    cPMove.MoveTo(CoordAndScreen.MousePosition().x);
            //}
        }
    }
}
