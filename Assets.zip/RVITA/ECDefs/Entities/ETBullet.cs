﻿using RVITA;
using ECFramework;
using UnityEngine;

namespace RVITA
{
    public class ETBullet : UpdatedEntity
    {
        public float FlySpeed { get; set; }
        public float Damage { get; set; }
        Vector3 shootDir;
        float aliveTime;
        LayerEnum rivalCampLayer;
        Vector2 size;
        public override void SetReferences()
        {
            base.SetReferences();
            Collider2D collider2D = GameObject.GetComponent<Collider2D>();
            collider2D.isTrigger = true;
            size = GameObject.GetComponent<SpriteRenderer>().bounds.size;
        }
        public virtual void Lanch(Transform shootPosition, Camp camp)
        {
            aliveTime = 2;
            GameObject.transform.SetPositionAndRotation(shootPosition.position, shootPosition.rotation);
            shootDir = (GameObject.transform.rotation * Vector3.right).normalized;
            rivalCampLayer = Camper.GetRivalCampLayer(camp);
        }
        public override void Update()
        {
            base.Update();
            GameObject.transform.position += FlySpeed * Time.deltaTime * shootDir;
            if (DetectCollision())
            {
                return;
            }
            aliveTime -= Time.deltaTime;
            if (aliveTime <= 0)
            {
                EntityAssembler.UnSpawn(this);
            }
        }
        public bool DetectCollision()
        {
            RaycastHit2D raycastHit2D = Physics2D.Raycast(GameObject.transform.position, GameObject.transform.right, Mathf.Max(size.x, size.y) / 2, rivalCampLayer.Mask() | LayerEnum.Static.Mask());
            if (raycastHit2D.transform != null)
            {
                if (raycastHit2D.transform.TryGetEntity(out Entity entity))
                {
                    if (entity.TryGetComp(out CPHealth health))
                    {
                        health.TakeDamage(Damage);
                    }
                }
                EntityAssembler.UnSpawn(this);
                return true;
            }
            return false;
        }
    }
}
