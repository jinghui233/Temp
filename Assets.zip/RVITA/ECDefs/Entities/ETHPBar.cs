﻿using ECFramework;
using System.Xml.Serialization;
using UnityEngine;
using UnityEngine.UI;
using UnityUtils;

namespace RVITA
{
    public class ETHPBar : UpdatedEntity
    {
        [XmlIgnore]
        public Transform AttachedTransform;
        Slider Slider;
        public override void SetReferences()
        {
            base.SetReferences();
            Slider = GameObject.GetComponent<Slider>();

        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            GameObject.transform.SetParent(UIGaming.Instance.canvas.transform);
        }
        public void SetVal(float val)
        {
            Slider.value = val;
        }
        public override void Update()
        {
            base.Update();
            GameObject.transform.position = CoordAndScreen.ScreenPosition(AttachedTransform.position);
        }
    }
}
