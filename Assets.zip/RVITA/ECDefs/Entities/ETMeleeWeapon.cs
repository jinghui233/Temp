﻿using ECFramework;
using UnityEngine;
using UnityEngine.UI;

namespace RVITA
{
    public class ETMeleeWeapon : UpdatedEntity
    {
        public float Damage { get; set; }
        public float AttackRange { get; set; }
        public bool Aimed;
        public float rotaSpeed = 10;
        Collider2D collider2D;
        Animator animator;
        bool Chopping;
        MonoMeleeWeapon MonoMeleeWeapon { get; set; }
        public override void InitUnityComponent()
        {
            base.InitUnityComponent();
            GameObject gameObject = GetOrCreateGameObject();
            if (!gameObject.TryGetComponent(out MonoMeleeWeapon _))
            {
                gameObject.AddComponent<MonoMeleeWeapon>();
            }
        }
        public override void SetReferences()
        {
            base.SetReferences();
            collider2D = GameObject.GetComponent<Collider2D>();
            collider2D.isTrigger = true;
            collider2D.enabled = false;
            animator = GameObject.GetComponent<Animator>();
            MonoMeleeWeapon = GameObject.GetComponent<MonoMeleeWeapon>();
            MonoMeleeWeapon.TriggerEnter2D += OnTriggerEnter2D;
            MonoMeleeWeapon.ChopFinish += OnChopFinish;
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            Chopping = false;
        }
        public void OnChopFinish()
        {
            collider2D.enabled = false;
            Chopping = false;
        }
        public void SetCamp(Camp camp)
        {
            Layerer.SetLayer(GameObject, Layerer.GetMeleeLayer(camp));
        }
        public void TakeAim(Vector3 target)
        {
            if (Chopping)
                return;
            Vector2 direction = target - GameObject.transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            float angle2 = Vector2.Angle(target - GameObject.transform.rotation.eulerAngles, GameObject.transform.right);
            Aimed = Mathf.Abs(angle2) < 3;
            Quaternion q = Quaternion.AngleAxis(angle, Vector3.forward);
            GameObject.transform.rotation = Quaternion.Slerp(GameObject.transform.rotation, q, rotaSpeed * Time.deltaTime);
        }
        public void Attack()
        {
            if (!Chopping)
            {
                collider2D.enabled = true;
                animator.SetTrigger("Chop");
                Chopping = true;
            }
        }
        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (collision.transform.TryGetEntity(out Entity entity))
            {
                if (entity.TryGetComp(out CPHealth health))
                {
                    health.TakeDamage(Damage);
                }
            }
        }
    }
}
