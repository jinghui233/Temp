using RVITA;
using SimpleUI;
using UnityEngine;
using UnityEngine.UI;

public class UIElecGtr : SimpleWindow
{
    public ProgressBar ProgressBar;
    public UIInventory Inventory;
    public Text Info;
    private CPElecGtr elecGtr;
    public void SetElecGtr(CPElecGtr elecGtr)
    {
        this.elecGtr = elecGtr;
        Inventory.SetStorage(elecGtr.Storage);
        ProgressBar.SetValue(elecGtr.TimeRemaining / elecGtr.TimeUsage);
        Title.text = elecGtr.Entity.DefName;
        Info.text = "";
    }
    void Update()
    {
        if (Closed) return;
        if (elecGtr != null)
        {
            ProgressBar.SetValue(elecGtr.TimeRemaining / elecGtr.TimeUsage);
        }
    }
}
