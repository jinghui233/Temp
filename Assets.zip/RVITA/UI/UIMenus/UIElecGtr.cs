using RVITA;
using UnityEngine;
using UnityEngine.UI;

public class UIElecGtr : SimpleWindow
{
    public ProgressBar ProgressBar;
    public Text Info;
    public CPElecGtr CPElecGtr;
    public override void Open()
    {
        base.Open();
        if (CPElecGtr != null)
        {
            ProgressBar.SetValue(CPElecGtr.TimeRemaining / CPElecGtr.TimeUsage);
            Title.text = CPElecGtr.Entity.DefName;
            Info.text = "";
        }
    }
    void Update()
    {
        if (Closed) return;
        if (CPElecGtr != null)
        {
            ProgressBar.SetValue(CPElecGtr.TimeRemaining / CPElecGtr.TimeUsage);
        }
    }
}
