using RVITA;
using SimpleUI;
using UnityEngine;
using UnityEngine.UI;

public class UIChest : SimpleWindow
{
    public UIInventory Inventory;
    public void SetStorage(CPStorage storage)
    {
        Inventory.SetStorage(storage);
        Title.text = storage.Entity.DefName;
    }
}
