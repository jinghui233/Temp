using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ProgressBar : MonoBehaviour
{
    public RectTransform FillRectTransform;
    public Image FillImage;
    private void OnRectTransformDimensionsChange()
    {
        FillRectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, (transform as RectTransform).rect.width);
        FillRectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, (transform as RectTransform).rect.height);
    }
    public void SetValue(float val)
    {
        FillImage.fillAmount = val;
    }
}
