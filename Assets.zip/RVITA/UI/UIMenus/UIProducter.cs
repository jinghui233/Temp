﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace RVITA
{
    public class UIProducter : SimpleWindow
    {
        public Text Info;
        public CPProducter CPProducter;
        public ProgressBar ProgressBar;
        public override void Open()
        {
            base.Open();
            if (CPProducter != null)
            {
                Title.text = CPProducter.Entity.DefName;
                Info.text = "";
            }
        }
        void Update()
        {
            if (Closed) return;
            if (CPProducter != null)
            {
                ProgressBar.SetValue(CPProducter.Progress);
            }
        }
    }
}
