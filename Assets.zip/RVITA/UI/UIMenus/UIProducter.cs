﻿using SimpleUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace RVITA
{
    public class UIProducter : SimpleWindow
    {
        public Text Info;
        public ProgressBar ProgressBar;
        public UIInventory Inventory;
        private CPProducter producter;
        public void SetProducter(CPProducter producter)
        {
            this.producter = producter;
            Inventory.SetStorage(producter.Storage);
            if (producter != null && producter.Recipe != null)
            {
                ProgressBar.SetValue(producter.Recipe.Progress);
            }
            Title.text = producter.Entity.DefName;
            Info.text = "";
        }
        void Update()
        {
            if (Closed) return;
            if (producter != null && producter.Recipe != null)
            {
                ProgressBar.SetValue(producter.Recipe.Progress);
            }
        }
    }
}
