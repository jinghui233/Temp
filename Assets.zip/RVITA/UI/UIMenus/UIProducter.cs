﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace RVITA
{
    public class UIProducter : SimpleWindow
    {
        public Text Info;
        public ProgressBar ProgressBar { get; set; }
        private CPProducter producter;
        public void SetProducter(CPProducter producter)
        {
            this.producter = producter;
            ProgressBar.SetValue(producter.Progress);
            Title.text = producter.Entity.DefName;
            Info.text = "";
        }
        void Update()
        {
            if (Closed) return;
            if (producter != null)
            {
                ProgressBar.SetValue(producter.Progress);
            }
        }
    }
}
