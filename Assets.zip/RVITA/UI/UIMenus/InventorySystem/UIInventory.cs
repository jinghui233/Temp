﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace RVITA
{
    public partial class UIInventory : MonoBehaviour, IPointerClickHandler
    {
        [SerializeField]
        private GridLayoutGroup gridLayoutGroup;//背包格子容器
        private List<UIItem> uiItems = new List<UIItem>();
        public CPStorage Storage { get; private set; }
        public void SetStorage(CPStorage storage)
        {
            Storage = storage;
        }
        private void Update()
        {
            // 将点击的屏幕坐标转换为背包格子内的本地坐标  
            Vector2 clickPosition;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(gridLayoutGroup.transform as RectTransform, Input.mousePosition, null, out clickPosition);
            Debug.Log(clickPosition);
            if (Storage == null) return;
            int index = -1;
            foreach (Item item in Storage.Items)
            {
                index++;
                if (index < uiItems.Count)
                {
                    if (!ReferenceEquals(uiItems[index].Item, item))
                    {
                        uiItems[index].Item = item;
                    }
                }
                else
                {
                    UIItem uiItem = Instantiate(UIManager.Instance.pfUIItem);
                    uiItem.transform.parent = gridLayoutGroup.transform;
                    uiItems.Add(uiItem);
                    uiItem.Item = item;
                }
            }
            if (uiItems.Count > Storage.Items.Count)
            {
                for (int i = uiItems.Count - 1; i >= Storage.Items.Count - 1; i--)
                {
                    Destroy(uiItems[i]);
                    uiItems.RemoveAt(i);
                }
            }
        }
        private void FastMove(int index)
        {
            UIItem uiItem = UIInventoryController.GetInventoryItem(gridLayoutGroup, index);
            if (uiItem != null)
            {
                UIInventory targetInventory = UIInventoryController.GetTargetInventory(this);
                if (targetInventory != null)
                {
                    Storage.Items.Remove(uiItem.Item);
                    targetInventory.Storage.Items.Add(uiItem.Item);
                }
            }
        }
        private void FastMoveHalf(int index)
        {
            UIItem uiItem = UIInventoryController.GetInventoryItem(gridLayoutGroup, index);
            if (uiItem != null)
            {
                UIInventory targetInventory = UIInventoryController.GetTargetInventory(this);
                if (targetInventory != null)
                {
                    UIItem anotherUIItem = uiItem.SplitHalf();
                    if (anotherUIItem == null)
                    {
                        anotherUIItem = uiItem;
                        Storage.Items.Remove(anotherUIItem.Item);
                    }
                    targetInventory.Storage.Items.Add(anotherUIItem.Item);
                }
            }
        }
        private void Pick(int index)
        {
            if (UIInventoryController.ItemPickedUp == null)
            {
                UIItem uiItem = UIInventoryController.GetInventoryItem(gridLayoutGroup, index);
                if (uiItem != null)
                {
                    Storage.Items.Remove(uiItem.Item);
                    UIInventoryController.SetPickedItem(uiItem, this);
                    uiItems.Remove(uiItem);
                }
            }
            else
            {
                Storage.Items.Add(UIInventoryController.ItemPickedUp.Item);
                UIInventoryController.SetPickedItem(null, null);
            }
        }
        private void PickHalf(int index)
        {
            if (UIInventoryController.ItemPickedUp == null)
            {
                UIItem uiItem = UIInventoryController.GetInventoryItem(gridLayoutGroup, index);
                if (uiItem != null)
                {
                    UIItem anotherUIItem = uiItem.SplitHalf();
                    if (anotherUIItem == null)
                    {
                        anotherUIItem = uiItem;
                        Storage.Items.Remove(anotherUIItem.Item);
                    }
                    UIInventoryController.SetPickedItem(anotherUIItem, this);
                }
            }
            else
            {
                Storage.Items.Add(UIInventoryController.ItemPickedUp.Item);
                UIInventoryController.SetPickedItem(null, null);
            }
        }
        public void OnPointerClick(PointerEventData eventData)
        {
            // 将点击的屏幕坐标转换为背包格子内的本地坐标  
            Vector2 clickPosition;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(gridLayoutGroup.transform as RectTransform, Input.mousePosition, null, out clickPosition);

            // 根据GridLayoutGroup的属性和点击的本地坐标计算格子索引  
            int columnIndex = Mathf.FloorToInt(clickPosition.x / gridLayoutGroup.cellSize.x);
            int rowIndex = Mathf.FloorToInt(clickPosition.y / gridLayoutGroup.cellSize.y);

            // 根据GridLayoutGroup的排列方式调整索引  
            // 假设是从左到右，从上到下的排列方式  
            int index = rowIndex * gridLayoutGroup.constraintCount + columnIndex;
            index = Mathf.Abs(index);
            if (eventData.button == PointerEventData.InputButton.Left)
            {
                if (Input.GetKey(KeyCode.LeftControl))
                {
                    PickHalf(index);
                }
                else
                {
                    Pick(index);
                }
            }
            else if (eventData.button == PointerEventData.InputButton.Right)
            {
                if (Input.GetKey(KeyCode.LeftControl))
                {
                    FastMoveHalf(index);
                }
                else
                {
                    FastMove(index);
                }
            }
        }
    }
}
