﻿using SimpleUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
using UnityUtils;

namespace RVITA
{
    public class UIInventoryController : MonoSingleton<UIInventoryController>
    {
        public static UIItem ItemPickedUp { get; private set; }
        private static UIInventory SourceInventory;
        public static void SetPickedItem(UIItem inventoryItem, UIInventory sourceInventory)
        {
            ItemPickedUp = inventoryItem;
            SourceInventory = sourceInventory;
        }
        private void Update()
        {
            if (ItemPickedUp != null)
            {
                ItemPickedUp.transform.position = CoordAndScreen.MousePosition();//应该需要处理UI坐标转换问题
                if (Input.GetMouseButtonDown(1))
                {
                    SourceInventory.Storage.Items.Add(ItemPickedUp.Item);
                    SetPickedItem(null, null);
                }
            }
        }
        internal static UIInventory GetTargetInventory(UIInventory simpleInventory)
        {
            SimpleWindow simpleWindow = SimpleWindow.GetSimpleWindow(simpleInventory.GetComponentInParent<SimpleWindow>());
            if (simpleWindow != null)
            {
                UIInventory targetInventory = simpleWindow.GetComponentInChildren<UIInventory>();
                return targetInventory;
            }
            return null;
        }
        internal static UIItem GetInventoryItem(GridLayoutGroup gridLayoutGroup, int index)
        {
            if (gridLayoutGroup.transform.childCount > index)
            {
                Transform transform = gridLayoutGroup.transform.GetChild(index);
                return transform.GetComponent<UIItem>();
            }
            return null;
        }
    }
}
