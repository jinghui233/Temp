﻿using ECFramework;
using UnityEngine;
using UnityEngine.UI;

namespace RVITA
{
    public class UIItem : MonoBehaviour
    {
        [SerializeField]
        private Text TextName;
        [SerializeField]
        private Text TextCount;
        [SerializeField]
        private Image Image;
        private string texturePath;
        public Item Item;
        private float count;
        internal UIItem SplitHalf()
        {
            Item item = Item.SplitHalf();
            if (item.Count == 0)
            {
                return null;
            }
            UIItem uiItem = Instantiate(this);
            uiItem.Item = item;
            return uiItem;
        }
        private void Update()
        {
            if (Item.Count != count)
            {
                count = Item.Count;
                TextCount.text = Item.Count.ToString();
            }
            if (Item.ItemDic[Item.Name].TexterPath != texturePath)
            {
                Texture2D texture = ResorceHelper.LoadResorce(Item.ItemDic[Item.Name].TexterPath);
                Rect rect = new Rect(0, 0, texture.width, texture.height);
                Sprite sprite = Sprite.Create(texture, rect, new Vector2(0.5f, 0.5f));
                Image.sprite = sprite;
                texturePath = Item.ItemDic[Item.Name].TexterPath;
            }
            if (TextName.text != Item.Name)
            {
                TextName.text = Item.Name;
            }
        }
    }
}
