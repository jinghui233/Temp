﻿using ECFramework;
using UnityEngine;
using UnityEngine.UI;

namespace RVITA
{
    public class SimpleInventoryItem : MonoBehaviour
    {
        [SerializeField]
        private Text TextName;
        [SerializeField]
        private Text TextCount;
        [SerializeField]
        private Image Image;
        private string texturePath;
        public ThingContainer ThingContainer;
        private float count;
        internal SimpleInventoryItem SplitHalf()
        {
            ThingContainer thingContainer = ThingContainer.SplitHalf();
            if (thingContainer.Count == 0)
            {
                return null;
            }
            SimpleInventoryItem simpleInventoryItem = Instantiate(this);
            simpleInventoryItem.ThingContainer = thingContainer;
            return simpleInventoryItem;
        }
        private void Update()
        {
            if (ThingContainer.Count != count)
            {
                count = ThingContainer.Count;
                TextCount.text = ThingContainer.Count.ToString();
            }
            if (ThingInfo.ThingDic[ThingContainer.Name].TexterPath != texturePath)
            {
                Texture2D texture = ResorceHelper.LoadResorce(ThingInfo.ThingDic[ThingContainer.Name].TexterPath);
                Rect rect = new Rect(0, 0, texture.width, texture.height);
                Sprite sprite = Sprite.Create(texture, rect, new Vector2(0.5f, 0.5f));
                Image.sprite = sprite;
                texturePath = ThingInfo.ThingDic[ThingContainer.Name].TexterPath;
            }
            if (TextName.text != ThingContainer.Name)
            {
                TextName.text = ThingContainer.Name;
            }
        }
    }
}
