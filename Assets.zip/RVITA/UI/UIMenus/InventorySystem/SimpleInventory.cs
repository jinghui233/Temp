﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace RVITA
{
    public partial class SimpleInventory : MonoBehaviour, IPointerClickHandler
    {
        [SerializeField]
        private GridLayoutGroup gridLayoutGroup;//背包格子容器
        private List<SimpleInventoryItem> inventoryItems = new List<SimpleInventoryItem>();
        public CPStorage Storage { get; private set; }
        public void SetStorage(CPStorage storage)
        {
            Storage = storage;
        }
        private void Update()
        {
            // 将点击的屏幕坐标转换为背包格子内的本地坐标  
            Vector2 clickPosition;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(gridLayoutGroup.transform as RectTransform, Input.mousePosition, null, out clickPosition);
            Debug.Log(clickPosition);
            if (Storage == null) return;
            int index = -1;
            foreach (ThingContainer item in Storage.Things)
            {
                index++;
                if (index < inventoryItems.Count)
                {
                    if (inventoryItems[index].ThingContainer != item)
                    {
                        inventoryItems[index].ThingContainer = item;
                    }
                }
                else
                {
                    SimpleInventoryItem simpleInventoryItem = Instantiate(UIManager.Instance.pfSimpleInventoryItem);
                    simpleInventoryItem.transform.parent = gridLayoutGroup.transform;
                    inventoryItems.Add(simpleInventoryItem);
                    simpleInventoryItem.ThingContainer = item;
                }
            }
            if (inventoryItems.Count > Storage.Things.Count)
            {
                for (int i = inventoryItems.Count - 1; i >= Storage.Things.Count - 1; i--)
                {
                    Destroy(inventoryItems[i]);
                    inventoryItems.RemoveAt(i);
                }
            }
        }
        private void FastMove(int index)
        {
            SimpleInventoryItem inventoryItem = SimpleInventoryController.GetInventoryItem(gridLayoutGroup, index);
            if (inventoryItem != null)
            {
                SimpleInventory targetInventory = SimpleInventoryController.GetTargetInventory(this);
                if (targetInventory != null)
                {
                    Storage.Out(inventoryItem.ThingContainer);
                    targetInventory.Storage.In(inventoryItem.ThingContainer);
                }
            }
        }
        private void FastMoveHalf(int index)
        {
            SimpleInventoryItem inventoryItem = SimpleInventoryController.GetInventoryItem(gridLayoutGroup, index);
            if (inventoryItem != null)
            {
                SimpleInventory targetInventory = SimpleInventoryController.GetTargetInventory(this);
                if (targetInventory != null)
                {
                    SimpleInventoryItem anotherItem = inventoryItem.SplitHalf();
                    if (anotherItem == null)
                    {
                        anotherItem = inventoryItem;
                        Storage.Out(anotherItem.ThingContainer);
                    }
                    targetInventory.Storage.In(anotherItem.ThingContainer);
                }
            }
        }
        private void Pick(int index)
        {
            if (SimpleInventoryController.ItemPickedUp == null)
            {
                SimpleInventoryItem inventoryItem = SimpleInventoryController.GetInventoryItem(gridLayoutGroup, index);
                if (inventoryItem != null)
                {
                    Storage.Out(inventoryItem.ThingContainer);
                    SimpleInventoryController.SetPickedItem(inventoryItem, this);
                    inventoryItems.Remove(inventoryItem);
                }
            }
            else
            {
                Storage.In(SimpleInventoryController.ItemPickedUp.ThingContainer);
                SimpleInventoryController.SetPickedItem(null, null);
            }
        }
        private void PickHalf(int index)
        {
            if (SimpleInventoryController.ItemPickedUp == null)
            {
                SimpleInventoryItem inventoryItem = SimpleInventoryController.GetInventoryItem(gridLayoutGroup, index);
                if (inventoryItem != null)
                {
                    SimpleInventoryItem anotherItem = inventoryItem.SplitHalf();
                    if (anotherItem == null)
                    {
                        anotherItem = inventoryItem;
                        Storage.Out(anotherItem.ThingContainer);
                    }
                    SimpleInventoryController.SetPickedItem(anotherItem, this);
                }
            }
            else
            {
                Storage.In(SimpleInventoryController.ItemPickedUp.ThingContainer);
                SimpleInventoryController.SetPickedItem(null, null);
            }
        }
        public void OnPointerClick(PointerEventData eventData)
        {
            // 将点击的屏幕坐标转换为背包格子内的本地坐标  
            Vector2 clickPosition;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(gridLayoutGroup.transform as RectTransform, Input.mousePosition, null, out clickPosition);

            // 根据GridLayoutGroup的属性和点击的本地坐标计算格子索引  
            int columnIndex = Mathf.FloorToInt(clickPosition.x / gridLayoutGroup.cellSize.x);
            int rowIndex = Mathf.FloorToInt(clickPosition.y / gridLayoutGroup.cellSize.y);

            // 根据GridLayoutGroup的排列方式调整索引  
            // 假设是从左到右，从上到下的排列方式  
            int index = rowIndex * gridLayoutGroup.constraintCount + columnIndex;
            index = (int)MathF.Abs(index);
            if (eventData.button == PointerEventData.InputButton.Left)
            {
                if (Input.GetKey(KeyCode.LeftControl))
                {
                    PickHalf(index);
                }
                else
                {
                    Pick(index);
                }
            }
            else if (eventData.button == PointerEventData.InputButton.Right)
            {
                if (Input.GetKey(KeyCode.LeftControl))
                {
                    FastMoveHalf(index);
                }
                else
                {
                    FastMove(index);
                }
            }
        }
    }
}
