﻿using UnityUtils;
using UnityEngine;
namespace RVITA
{
    public class UIManager : MonoSingleton<UIManager>
    {
        public UIChest UIChest;
        public UIElecGtr UIElecGtr;
        public UIProducter UIProducter;
        public UIItem pfUIItem;
        public UIInventoryController SimpleInventoryController;
        public RectTransform MainCanvas;
    }
}
