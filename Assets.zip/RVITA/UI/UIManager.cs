﻿using UnityUtils;
using UnityEngine;
namespace RVITA
{
    public class UIManager : MonoSingleton<UIManager>
    {
        public UIElecGtr UIElecGtr;
        public UIProducter UIProducter;
        public SimpleInventoryItem pfSimpleInventoryItem;
        public SimpleInventoryController SimpleInventoryController;
        public RectTransform MainCanvas;
    }
}
