﻿using UnityEngine;
using UnityUtils;

namespace RVITA
{
    public class CamMenuCtrl : MonoBehaviour
    {
        public Vector3 moveTarget;
        public float zoomTarget;
        public Vector3 moveVelocity = Vector3.zero;
        public float zoomVelocity = 0;
        public float moveSmoothTime = 0.15f;
        public float zoomSmoothTime = 0.1f;
        public float moveSpeed = 0.1f;
        public float zoomSpeed = 4;
        public Camera cam;
        public bool EnableKeyMove;
        private void Start()
        {
            cam = Camera.main;
            moveTarget = transform.position;
            zoomTarget = cam.orthographicSize;
        }
        private void Update()
        {
            HandleInput();
            zoomTarget = Mathf.Clamp(zoomTarget, 0.5f, 40);
            transform.position = Vector3.SmoothDamp(transform.position, moveTarget, ref moveVelocity, moveSmoothTime);
            cam.orthographicSize = Mathf.SmoothDamp(cam.orthographicSize, zoomTarget, ref zoomVelocity, zoomSmoothTime);
        }
        Vector3 prePosition;
        public void HandleInput()
        {
            if (Input.GetMouseButtonDown(1))
            {
                prePosition = CoordAndScreen.MousePosition();
            }
            if (Input.GetMouseButton(1))
            {
                Vector3 curPosition = CoordAndScreen.MousePosition();
                Vector3 d = prePosition - curPosition;
                d.z = 0;
                moveTarget += d;
                prePosition = curPosition;
            }
            float Horizontal = Input.GetAxis("Horizontal");
            if (Horizontal != 0 && EnableKeyMove)
            {
                moveTarget.x += Horizontal * moveSpeed;
                print(moveVelocity.magnitude);
            }
            float Vertical = Input.GetAxis("Vertical");
            if (Vertical != 0 && EnableKeyMove)
            {
                moveTarget.y += Vertical * moveSpeed;
            }
            float mouseScrollWheel = Input.GetAxis("Mouse ScrollWheel");
            if (mouseScrollWheel != 0)
            {
                zoomTarget -= mouseScrollWheel * zoomSpeed;
            }
        }
    }
}
