﻿using ECFramework;
using System;
using UnityEngine;

namespace RVITA
{
    public static class LayerEnumExtension
    {
        public static int Mask(this LayerEnum layer)
        {
            return 1 << (int)(layer);
        }
    }
    public enum LayerEnum
    {
        Default, TransparentFX, IgnoreRaycase, Static, Water, UI,
        Player, PlayerProjectile, PlayerMelee, PlayerSensor,
        Enemy, EnemyProjectile, EnemyMelee, EnemySensor,
        RVBlock, RVWall
    }
    public static class Layerer
    {
        public static void SetLayer(GameObject gameObject, LayerEnum layer)
        {
            gameObject.layer = (int)layer;
        }
        public static LayerEnum GetLayer(GameObject gameObject)
        {
            return (LayerEnum)Enum.Parse(typeof(LayerEnum), gameObject.layer.ToString());
        }
        public static LayerEnum GetLayer(Camp camp)
        {
            if (camp == Camp.Player)
            {
                return LayerEnum.Player;
            }
            else if (camp == Camp.Enemy)
            {
                return LayerEnum.Enemy;
            }
            throw new ArgumentException($"GetProjectileLayer,{camp},NotFound!");
        }
        public static LayerEnum GetProjectileLayer(LayerEnum playerOrEnemy)
        {
            if (playerOrEnemy == LayerEnum.Player)
            {
                return LayerEnum.PlayerProjectile;
            }
            else if (playerOrEnemy == LayerEnum.Enemy)
            {
                return LayerEnum.EnemyProjectile;
            }
            throw new ArgumentException($"GetProjectileLayer,{playerOrEnemy},NotFound!");
        }
        public static LayerEnum GetProjectileLayer(Camp camp)
        {
            if (camp == Camp.Player)
            {
                return LayerEnum.PlayerProjectile;
            }
            else if (camp == Camp.Enemy)
            {
                return LayerEnum.EnemyProjectile;
            }
            throw new ArgumentException($"GetProjectileLayer,{camp},NotFound!");
        }
        public static LayerEnum GetMeleeLayer(LayerEnum playerOrEnemy)
        {
            if (playerOrEnemy == LayerEnum.Player)
            {
                return LayerEnum.PlayerMelee;
            }
            else if (playerOrEnemy == LayerEnum.Enemy)
            {
                return LayerEnum.EnemyMelee;
            }
            throw new ArgumentException($"GetMeleeLayer,{playerOrEnemy},NotFound!");
        }
        public static LayerEnum GetMeleeLayer(Camp camp)
        {
            if (camp == Camp.Player)
            {
                return LayerEnum.PlayerMelee;
            }
            else if (camp == Camp.Enemy)
            {
                return LayerEnum.EnemyMelee;
            }
            throw new ArgumentException($"GetMeleeLayer,{camp},NotFound!");
        }
        public static LayerEnum GetSensorLayer(LayerEnum playerOrEnemy)
        {
            if (playerOrEnemy == LayerEnum.Player)
            {
                return LayerEnum.PlayerSensor;
            }
            else if (playerOrEnemy == LayerEnum.Enemy)
            {
                return LayerEnum.EnemySensor;
            }
            throw new ArgumentException($"GetSensorLayer,{playerOrEnemy},NotFound!");
        }
        public static LayerEnum GetSensorLayer(Camp camp)
        {
            if (camp == Camp.Player)
            {
                return LayerEnum.PlayerSensor;
            }
            else if (camp == Camp.Enemy)
            {
                return LayerEnum.EnemySensor;
            }
            throw new ArgumentException($"GetSensorLayer,{camp},NotFound!");
        }
    }
}
