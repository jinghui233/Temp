﻿namespace RVITA
{
    public enum Camp { Player, Enemy }
    public class Camper
    {
        public static Camp GetRivalCamp(Camp camp)
        {
            if (camp == Camp.Player)
            {
                return Camp.Enemy;
            }
            else if (camp == Camp.Enemy)
            {
                return Camp.Player;
            }
            throw new System.Exception();
        }
        public static LayerEnum GetRivalCampLayer(Camp camp)
        {
            if (camp == Camp.Player)
            {
                return LayerEnum.Enemy;
            }
            else if (camp == Camp.Enemy)
            {
                return LayerEnum.Player;
            }
            throw new System.Exception();
        }
        public static void SetCamp(ETCharacter character, Camp camp)
        {
            character.Camp = camp;
            LayerEnum layer = Layerer.GetLayer(camp);
            Layerer.SetLayer(character.GameObject, layer);
            character.turret?.SetCamp(camp);
            character.agent?.SetCamp(camp);
            character.weapon?.SetCamp(camp);
        }
    }
}
