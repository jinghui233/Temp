﻿using ECFramework;
using UnityEngine;

namespace RVITA
{
    public class InputCtrl : MonoBehaviour
    {
        public GridItems gridItems;
        public MouseBuilder mouseBuilder;
        public ETRV rv;
        private void Start()
        {
            gridItems.Clicked += OnGridItemClicked;
        }
        private void Update()
        {
            if (Input.GetMouseButtonDown(0))
            {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit2D[] hits = Physics2D.RaycastAll(ray.origin, ray.direction);
                foreach (RaycastHit2D hit in hits)
                {
                    if (hit.collider != null)
                    {
                        GameObject selectedObject = hit.collider.gameObject;
                        Entity entity = GameObjectToEC.Get(selectedObject);
                        if (entity != null)
                        {
                            if (entity.TryGetComp(out CPElecGtr cPElecGtr))
                            {
                                UIManager.Instance.UIElecGtr.CPElecGtr = cPElecGtr;
                                UIManager.Instance.UIElecGtr.Open();
                            }
                            else if (entity.TryGetComp(out CPProducter cPProducter))
                            {
                                UIManager.Instance.UIProducter.CPProducter = cPProducter;
                                UIManager.Instance.UIProducter.Open();
                            }
                        }
                    }
                }
            }
        }
        private void OnGridItemClicked(string entityName)
        {
            mouseBuilder.rV = rv;
            mouseBuilder.SetInBuilding(EntityAssembler.Spawn<ETPart>(entityName));
        }
    }
}
