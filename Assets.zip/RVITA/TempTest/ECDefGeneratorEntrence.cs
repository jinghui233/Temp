﻿using ECFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace RVITA
{
    public class ECDefGeneratorEntrence : MonoBehaviour
    {
        private void Start()
        {
            XmlHelper.InitTypes(Assembly.GetExecutingAssembly().GetTypes());
            ECDefGenerator.DoGenerate(@"C:\Users\静回\OneDrive\Projects\Unity\RVInTheApocalypse\RVInTheApocalypse\Assets\DataXml");
        }
    }
}
