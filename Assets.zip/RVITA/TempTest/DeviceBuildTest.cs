﻿using System.Reflection;
using UnityEngine.UI;
using UnityUtils;
using ECFramework;

namespace RVITA
{
    public class DeviceBuildTest : MonoSingleton<DeviceSysTest>
    {
        public GridItems gridItems;
        public Text text;
        public InputCtrl inputCtrl;
        void Load()
        {
            XmlHelper.InitTypes(Assembly.GetExecutingAssembly().GetTypes());
            XmlHelper.InitXmlSerializer();
            XmlHelper.Load("Assets/DataXml/block-parts.xml");
            XmlHelper.Load("Assets/DataXml/test-character.xml");
        }
        void TestProcess()
        {
            foreach (string item in XmlHelper.XmlPool.Keys)
            {
                EntityAssembler.Create(item);
            }
        }
        private void Start()
        {
            Load();
            TestProcess();
            foreach (var item in XmlHelper.XmlPool.Keys)
            {
                gridItems.AddItem(item);
            }
            EntityAssembler.Spawn<ETCharacter>("SimplePlayer");
            rv = EntityAssembler.Spawn<ETRV>("RV");
            ETPart eTBuildable = EntityAssembler.Spawn<ETPart>("SimplePart2");
            eTBuildable.Transform.position = rv.Transform.position;
            rv.AddBuildable(eTBuildable, null);
            inputCtrl.rv = rv;
            rv.ProdSys.StoreIn("wood", 10000);
            rv.ProdSys.StoreIn("fuel", 40000);
        }
        ETRV rv;
        private void Update()
        {
            text.text = $"{rv.ElecSys.info}\n{rv.ProdSys.info}";
        }
    }
}
