﻿using System.Reflection;
using UnityEngine.UI;
using UnityUtils;
using ECFramework;
using System.Collections.Generic;

namespace RVITA
{
    public class DeviceBuildTest : MonoSingleton<DeviceBuildTest>
    {
        public GridItems gridItems;
        public Text text;
        public InputCtrl inputCtrl;
        void Load()
        {
            XmlHelper.InitTypes(Assembly.GetExecutingAssembly().GetTypes());
            XmlHelper.InitXmlSerializer();
            XmlHelper.LoadEntitys("Assets/DataXml/block-parts.xml");
            XmlHelper.LoadEntitys("Assets/DataXml/test-character.xml");
            foreach (string item in XmlHelper.XmlPool.Keys)
            {
                EntityAssembler.Create(item);
            }
            List<Item> items = XmlHelper.DeserializeFromFile<List<Item>>("Assets/DataXml/items.xml");
            foreach (Item item in items)
            {
                if (!Item.ItemDic.ContainsKey(item.Name))
                {
                    Item.ItemDic.Add(item.Name, item);
                }
            }
        }
        private void Start()
        {
            Load();
            foreach (var item in XmlHelper.XmlPool.Keys)
            {
                gridItems.AddItem(item);
            }
            //EntityAssembler.Spawn<ETCharacter>("SimplePlayer");
            rv = EntityAssembler.Spawn<ETRV>("RV");
            ETPart eTBuildable = EntityAssembler.Spawn<ETPart>("SimplePart2");
            eTBuildable.Transform.position = rv.Transform.position;
            rv.AddBuildable(eTBuildable, null);

            //eTBuildable = EntityAssembler.Spawn<ETPart>("ElecGtr");
            //eTBuildable.GameObject.transform.position = new UnityEngine.Vector3(3, 0, 0);
            //rv.AddBuildable(eTBuildable, null);
            //eTBuildable = EntityAssembler.Spawn<ETPart>("Producter");
            //eTBuildable.GameObject.transform.position = new UnityEngine.Vector3(-3, 0, 0);
            //rv.AddBuildable(eTBuildable, null);

            //rv = EntityAssembler.Spawn<ETRV>("RV");
            // eTBuildable = EntityAssembler.Spawn<ETPart>("SimplePart2");
            //eTBuildable.Transform.position = rv.Transform.position;
            //rv.AddBuildable(eTBuildable, null);
        }
        ETRV rv;
        private void Update()
        {
            text.text = $"{rv.ElecSys.info}";
        }
    }
}
