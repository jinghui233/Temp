﻿using ECFramework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RVITA
{
    public class Test
    {
        public static void Run()
        {
            Test1();
        }
        public static void Test1()
        {
            XmlHelper.InitTypes();
            XmlHelper.InitXmlSerializer();
            XmlHelper.Load(Path.Combine(@"E:\users\SuD02\source\repos\WindowsFormsApp1\ConsoleApp1\RVITA\DataXml", "block-parts.xml"));
            foreach (string item in XmlHelper.XmlPool.Keys)
            {
                EntityAssembler.Create(item);
            }
            ETRV rv = EntityAssembler.Spawn<ETRV>("RV");
            ETPart part1 = EntityAssembler.Spawn<ETPart>("SimplePart");
            part1.LocalPosition = new UnityEngine.Vector3(0, 0, 0);
            rv.AddBuildable(part1, null);
            ETPart part2 = EntityAssembler.Spawn<ETPart>("SimplePart");
            part2.LocalPosition = new UnityEngine.Vector3(1, 1, 1);
            rv.AddBuildable(part2, new List<ETPart>() { part1 });
            ETPart part3 = EntityAssembler.Spawn<ETPart>("SimplePart");
            part3.LocalPosition = new UnityEngine.Vector3(2, 2, 2);
            rv.AddBuildable(part3, new List<ETPart>() { part2 });
            ETPart part4 = EntityAssembler.Spawn<ETPart>("SimplePart");
            part4.LocalPosition = new UnityEngine.Vector3(3, 3, 3);
            rv.AddBuildable(part4, new List<ETPart>() { part3 });
            XmlHelper.SerializeToFile(new List<Entity>() { rv }, @"E:\users\SuD02\source\repos\WindowsFormsApp1\ConsoleApp1\RVITA\DataXml\test.xml");
            ETRV rv2 = EntityAssembler.FromXML<ETRV>(File.ReadAllText(@"E:\users\SuD02\source\repos\WindowsFormsApp1\ConsoleApp1\RVITA\DataXml\test.xml"));
        }
        public static void Test2()
        {

        }
    }
}
