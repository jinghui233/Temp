﻿using UnityUtils;
using ECFramework;

namespace RVITA
{
    public class TestMainProcess : MonoSingleton<TestMainProcess>
    {
        public string jsonDataPath = "Assets/Data/entities-blocks.json";
        protected override void Awake()
        {
            base.Awake();
        }
        void Load()
        {
            jsonDataPath = "Assets/Data/character.json";
            //EntityManager.Instance.Load("Assets/Data/character.json");
            //EntityManager.Instance.LoadAppend("Assets/Data/other.json");
            XmlHelper.Load("Assets/Data/entities-blocks.json");
        }
        private void Start()
        {
            Load();
            TestProcess();
            //MouseBuilder.Instance.buildCore = eTBuildCore;
            //ETCharacter character = PoolCmpt.Spawn<ETCharacter>("SimplePlayer");
            //character.SetCamp(Camp.Player);
            //character.GetComp<CPMove>().MoveTo(new UnityEngine.Vector3(-2, 0, 0));
            //character = PoolCmpt.Spawn<ETCharacter>("SimpleEnemy");
            //character.SetCamp(Camp.Enemy);
            //character.GetComp<CPMove>().MoveTo(new UnityEngine.Vector3(2, 0, 0));
        }
        void TestProcess()
        {
            foreach (var item in XmlHelper.XmlPool.Keys)
            {
                EntityAssembler.Create(item);
            }
        }
    }
}
