﻿using ECFramework;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityUtils;

namespace RVITA
{
    public class DeviceSysTest : MonoSingleton<DeviceSysTest>
    {
        public Text text;
        void Load()
        {
            XmlHelper.Load("Assets/Data/DeviceSystem.json");
        }
        CPElecSys cPElecSys;
        ProdSys prodSys;
        private void Start()
        {
            Load();
            TestProcess();
            ETNormal eTNormal;
            eTNormal = EntityAssembler.Spawn<ETNormal>("ElecSys");
            cPElecSys = eTNormal.GetComp<CPElecSys>();
            prodSys = new ProdSys();
            prodSys.StoreIn("wood", 10000);
            prodSys.StoreIn("fuel", 40000);
            AddBattery();
            AddGtr();
            AddProducter();
        }
        private void Update()
        {
            text.text = $"{cPElecSys.info}\n{prodSys.info}";
            if (Input.GetKeyDown(KeyCode.Y))
            {
                AddGtr();
            }
            if (Input.GetKeyDown(KeyCode.H))
            {
                RemoveGtr();
            }
            if (Input.GetKeyDown(KeyCode.U))
            {
                AddProducter();
            }
            if (Input.GetKeyDown(KeyCode.J))
            {
                RemoveProducter();
            }
            if (Input.GetKeyDown(KeyCode.I))
            {
                AddBattery();
            }
            if (Input.GetKeyDown(KeyCode.K))
            {
                RemoveBattery();
            }
        }
        List<ETNormal> gtrs = new List<ETNormal>();
        public void AddGtr()
        {
            ETNormal eTNormal = EntityAssembler.Spawn<ETNormal>("ElecGtr");
            eTNormal.GetComp<CPElecGtr>().ElecSys = cPElecSys;
            eTNormal.GetComp<CPElecGtr>().prodSys = prodSys;
            gtrs.Add(eTNormal);
        }
        public void RemoveGtr()
        {
            if (gtrs.Count > 0)
            {
                ETNormal eTNormal = gtrs[0];
                EntityAssembler.UnSpawn(eTNormal);
                gtrs.RemoveAt(0);
            }
        }
        List<ETNormal> batterys = new List<ETNormal>();
        public void AddBattery()
        {
            ETNormal eTNormal = EntityAssembler.Spawn<ETNormal>("Battery");
            eTNormal.GetComp<CPBattery>().ElecSys = cPElecSys;
            eTNormal.GetComp<CPBattery>().prodSys = prodSys;
            batterys.Add(eTNormal);
        }
        public void RemoveBattery()
        {
            if (batterys.Count > 0)
            {
                ETNormal eTNormal = batterys[0];
                EntityAssembler.UnSpawn(eTNormal);
                batterys.RemoveAt(0);
            }
        }
        List<ETNormal> producters = new List<ETNormal>();
        public void AddProducter()
        {
            ETNormal eTNormal = EntityAssembler.Spawn<ETNormal>("Producter");
            eTNormal.GetComp<CPProducter>().ElecSys = cPElecSys;
            eTNormal.GetComp<CPProducter>().prodSys = prodSys;
            eTNormal.GetComp<CPProducter>().Circulation = true;
            eTNormal.GetComp<CPProducter>().AddOrder(new Recipe() { ProdIn = new Product[] { new Product() { Count = 2, Name = "wood" } }, Prodout = new Product[] { new Product() { Count = 1, Name = "coal" } }, TimeUse = 3 });
            producters.Add(eTNormal);
        }
        public void RemoveProducter()
        {
            if (producters.Count > 0)
            {
                ETNormal eTNormal = producters[0];
                EntityAssembler.UnSpawn(eTNormal);
                producters.RemoveAt(0);
            }
        }
        void TestProcess()
        {
            foreach (string defName in XmlHelper.XmlPool.Keys)
            {
                EntityAssembler.Create(defName);
            }
        }
    }
}
