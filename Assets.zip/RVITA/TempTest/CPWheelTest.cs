﻿using System.Reflection;
using UnityEngine;
using UnityUtils;
using ECFramework;

namespace RVITA
{
    public class CPWheelTest : MonoSingleton<CPWheelTest>
    {
        void Load()
        {
            XmlHelper.InitTypes(Assembly.GetExecutingAssembly().GetTypes());
            XmlHelper.LoadEntitys("Assets/Data/wheels.json");
        }
        void TestProcess()
        {
            foreach (var item in XmlHelper.XmlPool.Keys)
            {
                EntityAssembler.Create(item);
            }
        }
        private void Start()
        {
            Load();
            TestProcess();
            ETPart body = EntityAssembler.Spawn<ETPart>("TestBody");
            body.GameObject.transform.position = new Vector3(0, 0, 0);

            //ETBuildable eTBuildable = PoolCmpt.Spawn<ETBuildable>("SimpleWheel");
            //eTBuildable.GameObject.transform.position = new Vector3(0, 2, 0);
            //eTBuildable.GameObject.GetComponent<FixedJoint2D>().connectedBody = body.GameObject.GetComponent<Rigidbody2D>();

            //eTBuildable = PoolCmpt.Spawn<ETBuildable>("SimpleWheel");
            //eTBuildable.GameObject.transform.position = new Vector3(2, 2, 0);
            //eTBuildable.GameObject.GetComponent<FixedJoint2D>().connectedBody = body.GameObject.GetComponent<Rigidbody2D>();

        }
    }
}
