using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
namespace SimpleUI
{
    public class SimpleWindow : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerClickHandler, IPointerDownHandler
    {
        private static List<SimpleWindow> instances = new List<SimpleWindow>();
        [SerializeField]
        private CanvasGroup canvasGroup;
        [SerializeField]
        private RectTransform WinBarRectTransform;
        public Text Title;
        public bool Closed { get; private set; }
        /// <summary>
        /// ��ȡ���ϲ������SimpleWindow�е���һ�����������ϲ�window�е�һ�����������ϲ�window�е���һ��
        /// </summary>
        /// <param name="simpleWindow">���ϲ�window�е�����һ��</param>
        /// <returns>���ϲ�window�е���һ��</returns>
        public static SimpleWindow GetSimpleWindow(SimpleWindow simpleWindow)
        {
            if (instances.Count > 1 && simpleWindow != null)
            {
                if (ReferenceEquals(simpleWindow, instances[0]))
                {
                    return instances[1];
                }
                return instances[0];
            }
            return null;
        }
        private void Start()
        {
            Title = gameObject.transform.GetChild(2).GetComponent<Text>();
            canvasGroup = GetComponent<CanvasGroup>();
            WinBarRectTransform = gameObject.transform.GetChild(1).GetComponent<RectTransform>();
            Button btnClose = gameObject.transform.GetChild(3).GetComponent<Button>();
            btnClose.onClick.AddListener(Close);
        }
        public virtual void Close()
        {
            canvasGroup.alpha = 0;
            canvasGroup.interactable = false;
            canvasGroup.blocksRaycasts = false;
            Closed = true;
            instances.Remove(this);
        }
        public virtual void Open()
        {
            canvasGroup.alpha = 1;
            canvasGroup.interactable = true;
            canvasGroup.blocksRaycasts = true;
            Closed = false;
            if (!instances.Contains(this))
            {
                instances.Add(this);
            }
        }
        public void OnBeginDrag(PointerEventData eventData)
        {
            transform.SetAsLastSibling();
            if (RectTransformUtility.RectangleContainsScreenPoint(WinBarRectTransform, Input.mousePosition))
            {
                _isDragging = true;
            }
            if (!Closed && instances.IndexOf(this) != 0)
            {
                instances.Remove(this);
                instances.Insert(0, this);
            }
        }
        bool _isDragging;
        public void OnDrag(PointerEventData eventData)
        {
            if (_isDragging)
            {
                transform.position += (Vector3)eventData.delta;
            }
        }
        public void OnEndDrag(PointerEventData eventData)
        {
            _isDragging = false;
        }
        public void OnPointerClick(PointerEventData eventData)
        {
            transform.SetAsLastSibling();
            if (!Closed && instances.IndexOf(this) != 0)
            {
                instances.Remove(this);
                instances.Insert(0, this);
            }
        }
        public void OnPointerDown(PointerEventData eventData)
        {
            if (!Closed && instances.IndexOf(this) != 0)
            {
                instances.Remove(this);
                instances.Insert(0, this);
            }
        }
    }
}