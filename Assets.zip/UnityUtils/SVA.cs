﻿using UnityEngine;
namespace UnityUtils
{
    public class SVA
    {

        //可以使用以下公式来计算减速到0时的末位置s_end：s_end = s + (v^2 / (2 * a)) 其中，v是当前速度，s是当前位置，a是减速用的加速度。
        public static bool NeedStop(float s, float v, float A, float target)
        {
            float t = v / A;
            float s_end = s + (A * (t * t)) / 2 * Mathf.Sign(v);
            if ((target - s) * (target - s_end) < 0)
            {
                return true;
            }
            return false;
        }

        public static bool NeedStopOld(float s, float v, float A, float target)
        {
            float IncreasedS = target - s;
            float time = v / A;
            float at2 = (A * time * time) / 2;
            if (at2 > Mathf.Abs(IncreasedS))
            {
                return true;
            }
            return false;
        }
    }

    public class SVAOld
    {
        public float TargetV { get { return IncreasedV + V; } set { value = Mathf.Sign(value) * Mathf.Clamp(Mathf.Abs(value), 0, MaxV); IncreasedV = value - V; TargetMode = false; } }
        private float IncreasedV = 0;
        public float TargetS { get { return IncreasedS + S; } set { IncreasedS = value - S; if (IncreasedS != 0) { IncreasedV = (Mathf.Sign(IncreasedS) * MaxV) - v; TargetMode = true; } } }
        private float IncreasedS = 0;
        public float V { get { return v; } set { v = Mathf.Sign(value) * Mathf.Clamp(Mathf.Abs(value), 0, MaxV); TargetMode = false; } }
        private float v;
        public bool TargetMode { get; private set; }
        public float S = 0;
        public float MaxV = int.MaxValue;
        public float A = 1;
        public float G = -10;
        public float MaxS = float.PositiveInfinity;
        public float MinS = float.NegativeInfinity;
        private float addVSign = 0;
        /// <summary>
        /// 加速或减速
        /// </summary>
        /// <param name="sign">1，-1</param>
        public void AddV(float sign = 1)
        {
            addVSign = sign;
        }
        public void Stop()
        {
            TargetMode = false;
            IncreasedV = 0;
            IncreasedS = 0;
            v = 0;
        }
        private void CheckIncreasedV()
        {
            if (IncreasedS * v > 0)
            {
                float time = v / A;
                float at2 = (A * time * time) / 2;
                if (at2 > Mathf.Abs(IncreasedS))
                {
                    IncreasedV = 0 - v;
                }
            }
        }
        public void LimitV(float maxV)
        {
            MaxV = maxV;
            if (Mathf.Abs(v) > MaxV)
            {
                float newV = Mathf.Sign(v) * MaxV;
                if (!onlyG)
                {
                    IncreasedV -= newV - v;
                }
                v = newV;
            }
        }
        private bool onlyG;
        public float UpdateV(float deltaTime)
        {
            if (TargetMode)
            {
                CheckIncreasedV();
            }
            if (addVSign != 0)
            {
                IncreasedV = addVSign * A * deltaTime;
                addVSign = 0;
            }
            float dv;
            if (IncreasedV != 0)
            {
                onlyG = false;
                dv = Mathf.Sign(IncreasedV) * deltaTime * A;
                dv = Mathf.Abs(dv) > Mathf.Abs(IncreasedV) ? IncreasedV : dv;
                IncreasedV -= dv;
                v += dv;
            }
            else if (G != 0)
            {
                onlyG = true;
                dv = deltaTime * G;
                v += dv;
            }
            return v;
        }
        public float UpdateS(float deltaTime, float s)
        {
            S = s;
            IncreasedS -= deltaTime * v;
            S += deltaTime * v;
            if (S > MaxS)
            {
                IncreasedS += S - MaxS;
                S = MaxS;
                v = 0;
            }
            if (S < MinS)
            {
                IncreasedS -= MinS - S;
                S = MinS;
                v = 0;
            }
            if (TargetMode)
            {
                if (-0.01 < IncreasedS && IncreasedS < 0.01)
                {
                    S += IncreasedS;
                    v = 0;
                    IncreasedV = 0;
                    IncreasedS = 0;
                    TargetMode = false;
                }
            }
            return S;
        }
        public float Update(float deltaTime, float s)
        {
            UpdateV(deltaTime);
            LimitV(MaxV);
            return UpdateS(deltaTime, s);
        }
    } 
}