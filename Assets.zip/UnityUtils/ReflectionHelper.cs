﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace UnityUtils
{
    public class ReflectionHelper
    {
        public static IEnumerable<Type> AllTypesIsAssignableFrom<T>(Type[] types = null)
        {
            types = types == null ? Assembly.GetExecutingAssembly().GetTypes() : types;
            return from t in types where t.IsClass && typeof(T).IsAssignableFrom(t) select t;
        }
        public static IEnumerable<Type> AllTypesIsSubclassOf<T>(Type[] types=null)
        {
            types = types == null ? Assembly.GetExecutingAssembly().GetTypes() : types;
            return from t in types where t.IsClass && t.IsSubclassOf(typeof(T)) select t;
        }
        public static Dictionary<string, Type> AllTypesIsAssignableFromToDic<T>(Type[] types = null)
        {
            return AllTypesIsAssignableFrom<T>(types).ToDictionary(kv => kv.Name, kv => kv);
        }
        public static Dictionary<string, Type> AllTypesIsSubclassOfToDic<T>(Type[] types = null)
        {
            return AllTypesIsSubclassOf<T>(types).ToDictionary(kv => kv.Name, kv => kv);
        }
    }
}
