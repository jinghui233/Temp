﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts
{
    public class CamCtrl3D : MonoBehaviour
    {
        public Camera cam;
        public Transform pX;
        public Transform ppY;
        public Vector3 moveTarget;
        public Vector3 zoomTarget;
        public Vector3 rotateTarget;
        public Vector3 curRotate;
        public float moveSmoothTime = 0.1f;
        public float zoomSmoothTime = 0.1f;
        public float rotateSmoothTime = 0.1f;
        public float moveSpeed = 0.25f;
        public float zoomSpeed = 10;
        public float rotateSpeed = 30;
        public Vector3 moveVelocity = Vector3.zero;
        public Vector3 zoomVelocity = Vector3.zero;
        public Vector3 rotateVelocity = Vector3.zero;
        private void Start()
        {
            moveTarget = ppY.position;
            curRotate.x = pX.localRotation.eulerAngles.x;
            curRotate.y = ppY.localRotation.eulerAngles.y;
            rotateTarget = curRotate;
            zoomTarget = cam.transform.localPosition;
        }
        private void Update()
        {
            HandleInput();
            ppY.position = Vector3.SmoothDamp(ppY.position, moveTarget, ref moveVelocity, moveSmoothTime);
            cam.transform.localPosition = Vector3.SmoothDamp(cam.transform.localPosition, zoomTarget, ref zoomVelocity, zoomSmoothTime);
            curRotate = Vector3.SmoothDamp(curRotate, rotateTarget, ref rotateVelocity, rotateSmoothTime);
            pX.localRotation = Quaternion.Euler(curRotate.x, 0, 0);
            ppY.localRotation = Quaternion.Euler(0, curRotate.y, 0);
            //ppY.localRotation = Quaternion.Euler(0, Mathf.SmoothDamp(ppY.localRotation.eulerAngles.y, rotateTarget.y, ref rotateSpeed, rotateSmoothTime), 0);
            //pX.localRotation = Quaternion.Euler(Mathf.SmoothDamp(pX.localRotation.eulerAngles.x, rotateTarget.x, ref rotateSpeed, rotateSmoothTime), 0, 0);
        }
        public void HandleInput()
        {
            if (Input.GetMouseButton(1))
            {
                //rotateTarget = pX.eulerAngles + new Vector3(-Input.GetAxis("Mouse Y") * rotateSpeed, Input.GetAxis("Mouse X") * rotateSpeed);
                rotateTarget.x -= Input.GetAxis("Mouse Y") * rotateSpeed;
                rotateTarget.y += Input.GetAxis("Mouse X") * rotateSpeed;
                print(rotateTarget);
            }
            float Horizontal = Input.GetAxis("Horizontal");
            if (Horizontal != 0)
            {
                moveTarget += ppY.TransformDirection(Vector3.right) * Horizontal * moveSpeed;
            }
            float Vertical = Input.GetAxis("Vertical");
            if (Vertical != 0)
            {
                moveTarget += ppY.TransformDirection(Vector3.forward) * Vertical * moveSpeed;
            }
            float mouseScrollWheel = Input.GetAxis("Mouse ScrollWheel");
            if (mouseScrollWheel != 0)
            {
                zoomTarget = cam.transform.localPosition + Vector3.forward * mouseScrollWheel * zoomSpeed;
            }
        }
    }
}
