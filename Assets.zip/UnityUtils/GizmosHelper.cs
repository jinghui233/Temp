﻿using UnityEngine;

namespace UnityUtils
{
    public class GizmosHelper
    {
        public static void DrawRotatedWireRect(Vector3 center, float width, float height, float angle)
        {
            // 将角度转换为弧度
            float radians = angle * Mathf.Deg2Rad;

            // 绘制旋转矩形的边界框
            Gizmos.matrix = Matrix4x4.TRS(center, Quaternion.Euler(0, 0, angle), new Vector3(1,1 , 1));
            Gizmos.DrawWireCube(Vector3.zero, new Vector3(width, height, 0));

            // 将Gizmos.matrix设置回初始矩阵
            Gizmos.matrix = Matrix4x4.identity;
        }
    }
}
