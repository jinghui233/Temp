﻿using System.Collections.Generic;
using UnityEngine;

namespace UnityUtils
{
    public class UnityUtils
    {
        public static Transform FindInChildren(Transform transform, string name, int depth = 1, int maxdepth = 4)
        {
            Transform finded;
            finded = transform.Find(name);
            if (finded != null)
            {
                return finded;
            }
            if (depth < maxdepth)
            {
                for (int i = 0; i < transform.childCount; i++)
                {
                    finded = FindInChildren(transform.GetChild(i), name, depth + 1);
                    if (finded != null)
                    {
                        return finded;
                    }
                }
            }
            return null;
        }
        private static List<string> FirstNames = new List<string> { "fwa", "fwea", "ibes", "oewa", "jogewano", "foew", "foewa", "foewamn", "fokewan", "ofewna", "ofwe", "ogenw", "opfvew" };
        private static List<string> MiddleNames = new List<string> { "654196", "94", "9496", "41", "8541", "6549", "6163", "946", "9649", "16419", "16549", "6146", "165496" };
        private static List<string> LastNames = new List<string> { "bres", "fewa", "ibefes", "ewag", "fewa", "foafeew", "foeaewa", "ebwa", "afve", "ofewana", "offewwe", "ogfwea", "aweew" };
        public static string GetRandomName()
        {
            return $@"{FirstNames[UnityEngine.Random.Range(0, FirstNames.Count)]}-{MiddleNames[UnityEngine.Random.Range(0, MiddleNames.Count)]}-{LastNames[UnityEngine.Random.Range(0, LastNames.Count)]}";
        }
        public static void SetLayerAndChild(GameObject gameObject, int layer)
        {
            var childrenTrans = gameObject.GetComponentsInChildren<Transform>();
            for (int i = 0; i < childrenTrans.Length; i++)
            {
                childrenTrans[i].gameObject.layer = layer;
            }
        }
    }
}
