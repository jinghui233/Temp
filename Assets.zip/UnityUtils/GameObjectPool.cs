﻿using System.Collections.Generic;
using UnityEngine;

namespace UnityUtils
{
    public class GameObjectPool
    {
        private Queue<GameObject> instanceQueue;
        public Transform transform;
        private GameObject pfInstance;
        public GameObjectPool(Transform transform, GameObject pfInstance)
        {
            instanceQueue = new Queue<GameObject>();
            this.pfInstance = pfInstance;
            this.transform = transform;
        }
        public GameObject GetInstance()
        {
            try
            {
                GameObject instance;
                if (instanceQueue.Count > 0)
                {
                    instance = instanceQueue.Dequeue();
                    instance.SetActive(true);
                    return instance;
                }
                else
                {
                    instance = Object.Instantiate(pfInstance);
                    instance.SetActive(true);
                    return instance;
                }
            }
            catch (System.Exception)
            {
                throw;
            }
        }
        public void ReturnInstance(GameObject instance)
        {
            instanceQueue.Enqueue(instance);
            instance.SetActive(false);
            instance.transform.SetParent(transform);
        }
    }
}
