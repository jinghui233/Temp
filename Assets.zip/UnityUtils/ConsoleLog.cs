﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnityUtils
{
    public class ConsoleLog
    {
        public static void Print(string content)
        {
            Console.WriteLine(content);
        }
    }
}
