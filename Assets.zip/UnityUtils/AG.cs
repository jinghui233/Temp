﻿using UnityEngine;

namespace UnityUtils
{
    public class AG
    {
        /// <summary>
        /// 将point绕pivot点旋转angle角度
        /// </summary>
        /// <returns></returns>
        public static Vector2 RotatePointAroundPivot(Vector2 point, Vector2 pivot, float angle)
        {
            return Quaternion.AngleAxis(angle, Vector3.forward) * (new Vector3(point.x, point.y, 0) - new Vector3(pivot.x, pivot.y, 0)) + new Vector3(pivot.x, pivot.y, 0);
        }
    }
}
