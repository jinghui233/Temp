﻿using System;
using UnityEngine;

namespace ECFramework
{
    public static class Extensions
    {
        public static bool TryGetComponent<T>(this MonoBehaviour monoBehaviour, out T component)
        {
            component = default(T);
            return true;
        }
        public static bool TryGetComponent<T>(this MonoBehaviour monoBehaviour, Type type, out T component)
        {
            component = default(T);
            return true;
        }
        public static bool TryGetComponent<T>(this GameObject gameObject, out T component)
        {
            component = default(T);
            return true;
        }
        public static bool TryGetComponent<T>(this GameObject gameObject, Type type, out T component)
        {
            component = default(T);
            return true;
        }
        public static GameObject FindInChildren(this GameObject gameObject, string name)
        {
            for (int i = 0; i < gameObject.transform.childCount; i++)
            {
                if (gameObject.transform.GetChild(i).name == name)
                {
                    return gameObject.transform.GetChild(i).gameObject;
                }
            }
            return null;
        }
        public static T GetOrCreate<T>(this MonoBehaviour monoBehaviour) where T : Component
        {
            if (monoBehaviour.TryGetComponent<T>(out T component))
            {
                return component;
            }
            else
            {
                return monoBehaviour.gameObject.AddComponent<T>();
            }
        }
        public static Component GetOrCreate(this GameObject gameObject, Type type)
        {
            if (gameObject.TryGetComponent(type, out Component component))
            {
                return component;
            }
            else
            {
                return gameObject.AddComponent(type);
            }
        }
        public static T GetOrCreate<T>(this GameObject gameObject) where T : Component
        {
            if (gameObject.TryGetComponent<T>(out T component))
            {
                return component;
            }
            else
            {
                return gameObject.gameObject.AddComponent<T>();
            }
        }
    }
}
