﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using UnityEngine;

namespace ECFramework
{
    public class Comp : IEC
    {
        [XmlIgnore]
        public Entity Entity { get; set; }
        [XmlIgnore]
        public GameObject GameObject { get { return Entity.GameObject; } }
        [XmlIgnore]
        public Transform Transform { get { return Entity.GameObject?.transform; } }
        public virtual void InitUnityComponent() { }
        public virtual void SetReferences() { }
        public virtual void OnSpawn() { }
        public virtual void OnUnSpawn() { }
    }
}
