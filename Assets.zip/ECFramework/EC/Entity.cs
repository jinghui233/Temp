﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;

namespace ECFramework
{
    public class Entity : IEC
    {
        [XmlIgnore]
        internal bool InitUnityComponentCalled;
        private GameObject gameObject;
        [XmlIgnore]
        public GameObject GameObject { get { return gameObject; } set { gameObject = value; GameObjectToEC.Add(this); } }
        [XmlIgnore]
        public Transform Transform { get { return gameObject?.transform; } }
        public string DefName { get; set; }
        public string PrefebPath { get; set; }
        public Vector3 LocalPosition { get; set; }
        public List<Comp> Comps { get; set; }
        public List<Entity> SubEntities { get; set; }
        public void AddComp(Comp comp)
        {
            Comps ??= new List<Comp>();
            Comps.Add(comp);
            comp.Entity = this;
        }
        public void AddSubEntity(Entity entity)
        {
            SubEntities ??= new List<Entity>();
            SubEntities.Add(entity);
        }
        public void RemoveSubEntity(Entity entity)
        {
            SubEntities?.Remove(entity);
        }
        public GameObject GetOrCreateGameObject()
        {
            if (GameObject == null)
            {
                GameObject = new GameObject();
                GameObject.SetActive(false);
            }
            return GameObject;
        }
        public virtual void InitUnityComponent() { }
        public virtual void SetReferences()
        {
            Comps?.ForEach(c => c.Entity = this);
        }
        public virtual void OnSpawn()
        {
            GameObject?.SetActive(true);
        }
        public virtual void OnUnSpawn()
        {
            GameObject?.SetActive(false);
        }
        public T GetSubEntity<T>() where T : class
        {
            if (!TryGetSubEntity(out T t))
                Debug.LogError($"在{DefName}中未找到类型{typeof(T).Name}的子实体");
            return t;
        }
        public bool TryGetSubEntity<T>(out T t) where T : class
        {
            t = null;
            foreach (var item in SubEntities)
            {
                t = item as T;
                if (t != null)
                    return true;
            }
            return false;
        }
        public T GetComp<T>() where T : class
        {
            if (!TryGetComp(out T t))
                Debug.LogError($"在{DefName}中未找到类型{typeof(T).Name}的子控件");
            return t;
        }
        public bool TryGetComp<T>(out T t) where T : class
        {
            t = default(T);
            if (Comps != null)
            {
                foreach (var item in Comps)
                {
                    t = item as T;
                    if (t != null) return true;
                }
            }
            return false;
        }
    }
}
