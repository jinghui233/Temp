﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityUtils;

namespace ECFramework
{
    public class Updater : MonoSingleton<Updater>
    {
        private static LinkedList<IUpdated> updatedECList = new();
        public static void Add(IUpdated updatedEC)
        {
            updatedEC.PrepareDel = false;
            updatedECList.AddLast(updatedEC);
        }
        public static void Remove(IUpdated updatedEC)
        {
            updatedECList.Remove(updatedEC);
        }
        private void OnDrawGizmos()
        {
            LinkedListNode<IUpdated> node = updatedECList.First;
            while (node != null)
            {//如果该节点是要删除的节点
                if (node.Value.PrepareDel)
                {   //如果节点没有下一个，直接移除节点并终止循环
                    if (node.Next == null)
                    {
                        updatedECList.Remove(node);
                        break;
                    }
                    //否则先将节点后移到下一个，然后删除该节点并跳到下一次循环
                    node = node.Next;
                    updatedECList.Remove(node.Previous);
                    continue;
                }
                if (node.Value.DrawGizmos)
                {
                    node.Value.OnDrawGizmos();
                }
                node = node.Next;
            }
        }
        private void Update()
        {
            LinkedListNode<IUpdated> node = updatedECList.First;
            while (node != null)
            {//如果该节点是要删除的节点
                if (node.Value.PrepareDel)
                {   //如果节点没有下一个，直接移除节点并终止循环
                    if (node.Next == null)
                    {
                        updatedECList.Remove(node);
                        break;
                    }
                    //否则先将节点后移到下一个，然后删除该节点并跳到下一次循环
                    node = node.Next;
                    updatedECList.Remove(node.Previous);
                    continue;
                }
                node.Value.Update();
                node = node.Next;
            }
        }
    }
}
