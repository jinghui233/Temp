﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ECFramework
{
    public interface IUpdated
    {
        public bool PrepareDel { get; set; }
        public bool DrawGizmos { get; set; }
        void Update();
        void OnDrawGizmos();
    }
    public class UpdatedEntity : Entity, IUpdated
    {
        [XmlIgnore]
        public bool PrepareDel { get; set; }
        [XmlIgnore]
        public bool DrawGizmos { get; set; }

        public override void OnSpawn()
        {
            base.OnSpawn();
            Updater.Add(this);
        }
        public override void OnUnSpawn()
        {
            base.OnUnSpawn();
            PrepareDel = true;
        }
        public virtual void OnDrawGizmos()
        {
            foreach (var item in Comps)
            {
                if (item is UpdatedComp)
                {
                    (item as UpdatedComp).OnDrawGizmos();
                }
            }
        }
        public virtual void Update()
        {
            foreach (var item in Comps)
            {
                if (item is UpdatedComp)
                {
                    (item as UpdatedComp).Update();
                }
            }
        }
    }
    public class UpdatedComp : Comp, IUpdated
    {
        [XmlIgnore]
        public bool PrepareDel { get; set; }
        [XmlIgnore]
        public bool DrawGizmos { get; set; }
        public virtual void OnDrawGizmos()
        {

        }
        public virtual void Update()
        {
        }
        public override void OnSpawn()
        {
            base.OnSpawn();
            if (Entity is not UpdatedEntity)
            {
                Updater.Add(this);
            }
        }
        public override void OnUnSpawn()
        {
            base.OnUnSpawn();
            if (Entity is not UpdatedEntity)
            {
                Updater.Remove(this);
            }
        }
    }
}
