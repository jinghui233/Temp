﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityUtils;

namespace ECFramework
{
    public partial class EntityAssembler : MonoSingleton<EntityAssembler>
    {
        public Pool Pool { get; set; }
        protected override void Awake()
        {
            base.Awake();
            Pool = new Pool(transform);
            Application.runInBackground = true;
        }
        //public EntityAssembler()
        //{
        //    Pool = new Pool(null);
        //}
        private Entity FromXMLInternal(string xml)
        {
            Entity entity = XmlHelper.Deserialize(xml).First();
            if (!entity.InitUnityComponentCalled)
            {
                CallInitUnityComponent(entity);
            }
            AssembleSubEntities(entity);
            CallSetRefenences(entity);
            CallOnSpawn(entity);
            return entity;
        }
        private Entity SpawnInternal(string defName)
        {
            Entity entity = Pool.Spawn(defName);
            if (!entity.InitUnityComponentCalled)
            {
                CallInitUnityComponent(entity);
            }
            AssembleSubEntities(entity);
            CallSetRefenences(entity);
            CallOnSpawn(entity);
            return entity;
        }
        private void UnSpawnInternal(Entity entity)
        {
            CallOnUnSpawn(entity);
            DisassembleSubEntities(entity);
            Pool.UnSpawn(entity);
        }
        private void CallOnUnSpawn(Entity entity)
        {
            entity.Comps?.ForEach(c => c.OnUnSpawn());
            entity.SubEntities?.ForEach(e => CallOnUnSpawn(e));
            entity.OnUnSpawn();
        }
        private void CallInitUnityComponent(Entity entity)
        {
            if (!string.IsNullOrWhiteSpace(entity.PrefebPath))
            {
                entity.GameObject = ResorceHelper.LoadResorce<GameObject>(entity.PrefebPath);
            }
            entity.Comps?.ForEach(c => { c.Entity = entity; c.InitUnityComponent(); });
            entity.InitUnityComponent();
            entity.InitUnityComponentCalled = true;
        }
        private void CallSetRefenences(Entity entity)
        {
            entity.Comps?.ForEach(c => c.SetReferences());
            entity.SubEntities?.ForEach(e => CallSetRefenences(e));
            entity.SetReferences();
        }
        private void CallOnSpawn(Entity entity)
        {
            entity.Comps?.ForEach(c => c.OnSpawn());
            entity.SubEntities?.ForEach(e => CallOnSpawn(e));
            entity.OnSpawn();
        }
        private void AssembleSubEntities(Entity entity)
        {
            if (entity.SubEntities != null)
            {
                for (int i = 0; i < entity.SubEntities.Count; i++)
                {
                    Entity subEntity;
                    if (Pool.Exist(entity.SubEntities[i].DefName))
                    {
                        subEntity = Pool.Spawn(entity.SubEntities[i].DefName);
                    }
                    else
                    {
                        subEntity = entity.SubEntities[i];
                    }
                    if (!subEntity.InitUnityComponentCalled)
                    {
                        CallInitUnityComponent(subEntity);
                    }
                    subEntity.Transform.parent = entity.Transform;
                    subEntity.LocalPosition = entity.SubEntities[i].LocalPosition;
                    entity.SubEntities[i] = subEntity;
                }
                for (int i = 0; i < entity.SubEntities.Count; i++)
                {
                    AssembleSubEntities(entity.SubEntities[i]);
                }
            }
        }
        private void DisassembleSubEntities(Entity entity)
        {
            if (entity.SubEntities != null)
            {
                for (int i = 0; i < entity.SubEntities.Count; i++)
                {
                    DisassembleSubEntities(entity.SubEntities[i]);
                }
                for (int i = 0; i < entity.SubEntities.Count; i++)
                {
                    if (Pool.Exist(entity.SubEntities[i].DefName))
                    {
                        Pool.UnSpawn(entity.SubEntities[i]);
                        entity.SubEntities[i] = new Entity() { DefName = entity.SubEntities[i].DefName, LocalPosition = entity.SubEntities[i].LocalPosition };
                    }
                }
            }
        }
    }
}
