﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECFramework
{
    public partial class EntityAssembler
    {
        public static void Create(string defName)
        {
            Instance.Pool.Create(defName);
        }
        public static T FromXML<T>(string xml) where T : Entity
        {
            return Instance.FromXMLInternal(xml) as T;
        }
        public static T Spawn<T>(string defName) where T : Entity
        {
            return Instance.SpawnInternal(defName) as T;
        }
        public static void UnSpawn(Entity entity)
        {
            Instance.UnSpawnInternal(entity);
        }
    }
}
