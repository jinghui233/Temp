﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using UnityEngine;

namespace ECFramework
{
    public class Test : MonoBehaviour
    {
        private void Start()
        {
            Test1();
        }
        void Test1()
        {

        }
    }
}
