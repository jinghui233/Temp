﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;

namespace ECFramework
{
    [XmlRoot("Root")]
    public struct XmlWrapper
    {
        public object Data { get; set; }
    }
    public class XmlHelper
    {
        public static Dictionary<string, string> XmlPool = new();
        public static XmlSerializer XmlSerializer { get; private set; }
        public static List<Type> Types { get; private set; } = new List<Type>();
        public static void InitTypes(Type[] types = null)
        {
            if (types == null || types.Length == 0)
                types = Assembly.GetExecutingAssembly().GetTypes();
            Type ECType = typeof(IEC);
            foreach (Type item in types)
            {
                if (!item.IsClass) continue;
                if (item.IsGenericType) continue;
                if (ECType.IsAssignableFrom(item))
                {
                    Types.Add(item);
                }
            }
        }
        public static void LoadEntitys(string path)
        {
            List<Entity> entities = DeserializeFromFile<List<Entity>>(path);
            foreach (Entity entity in entities)
            {
                XmlPool.Add(entity.DefName, Serialize(new List<Entity>() { entity }));
            }
        }
        public static Entity GetEntity(string defName)
        {
            return Deserialize<List<Entity>>(XmlPool[defName]).First();
        }
        public static void InitXmlSerializer()
        {
            XmlSerializer = new XmlSerializer(typeof(XmlWrapper), Types.ToArray());
        }
        public static void SerializeToFile<T>(T obj, string path)
        {
            XmlWrapper xmlWrapper = new() { Data = obj };
            using FileStream fileStream = new(path, FileMode.Create);
            XmlSerializer.Serialize(fileStream, xmlWrapper);
        }
        public static string Serialize<T>(T obj)
        {
            XmlWrapper xmlWrapper = new() { Data = obj };
            using StringWriter stringWriter = new();
            XmlSerializer.Serialize(stringWriter, xmlWrapper);
            return stringWriter.ToString();
        }
        public static T DeserializeFromFile<T>(string path)
        {
            using FileStream fileStream = new(path, FileMode.Open);
            XmlWrapper xmlWrapper = (XmlWrapper)XmlSerializer.Deserialize(fileStream);
            return (T)xmlWrapper.Data;
        }
        public static T Deserialize<T>(string xmlText)
        {
            using StringReader stringReader = new(xmlText);
            XmlWrapper xmlWrapper = (XmlWrapper)XmlSerializer.Deserialize(stringReader);
            return (T)xmlWrapper.Data;
        }
    }
}
